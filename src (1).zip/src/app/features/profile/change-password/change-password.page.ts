import { Component } from '@angular/core';
import { environment } from 'src/environments/environment';
import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  HttpClient,
  HttpHeaders
} from '@angular/common/http';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  shieldCheckmarkOutline
} from 'ionicons/icons';

import { PopupComponent } from '../../../shared/components/popup/popup.component';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon,
    PopupComponent
  ]
})

export class ChangePasswordPage {

  currentPassword = '';

  newPassword = '';

  confirmPassword = '';

  // SUCCESS
  showSuccessPopup = false;

  // ERROR
  showErrorPopup = false;

  errorMessage = '';

  constructor(
    private location: Location,
    private http: HttpClient
  ) {

    addIcons({
      arrowBackOutline,
      shieldCheckmarkOutline
    });

  }

  goBack() {

    this.location.back();

  }

  changePassword() {

    // VALIDASI
    if (
      !this.currentPassword ||
      !this.newPassword ||
      !this.confirmPassword
    ) {

      this.errorMessage =
        'Semua field wajib diisi';

      this.showErrorPopup = true;

      return;

    }

    // VALIDASI PASSWORD
    if (
      this.newPassword !==
      this.confirmPassword
    ) {

      this.errorMessage =
        'Konfirmasi password tidak cocok';

      this.showErrorPopup = true;

      return;

    }

    // TOKEN
    const token =
      localStorage.getItem(
        'token'
      );

    // REQUEST
    this.http.put(
      `${environment.apiUrl}/auth/change-password`,

      {

        old_password:
          this.currentPassword,

        new_password:
          this.newPassword

      },

      {

        headers: new HttpHeaders({

          Authorization:
            'Bearer ' + token

        })

      }

    ).subscribe({

      next: (res: any) => {

        console.log(
          'CHANGE PASSWORD:',
          res
        );

        // POPUP SUCCESS
        this.showSuccessPopup =
          true;

      },

      error: (err) => {

        console.log(
          'PASSWORD ERROR:',
          err
        );

        this.errorMessage =

          err.error.message ||

          'Gagal mengubah password';

        this.showErrorPopup =
          true;

      }

    });

  }

  // CLOSE ERROR
  closeErrorPopup() {

    this.showErrorPopup =
      false;

  }

  // FINISH
  finishChangePassword() {

    this.showSuccessPopup =
      false;

    this.location.back();

  }

}