import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  AfterViewChecked,
  NgZone                   // [FIX Bug #2] import NgZone
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  ActivatedRoute
} from '@angular/router';

import {
  HttpClient,
  HttpHeaders,
  HttpClientModule
} from '@angular/common/http';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  sendOutline,
  imageOutline,
  cameraOutline
} from 'ionicons/icons';

import {
  RealtimeService
} from '../../../core/services/realtime.service';

import {
  environment
} from 'src/environments/environment';

@Component({
  selector: 'app-chat-detail',
  templateUrl: './chat-detail.page.html',
  styleUrls: ['./chat-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    IonContent,
    IonIcon,
  ]
})

export class ChatDetailPage
implements OnInit, OnDestroy, AfterViewChecked {

  @ViewChild('messagesEnd')
  messagesEnd!: ElementRef;

  roomId!: number;

  /*
  FORMAT PESAN:
  {
    id:        number | null   ← ID dari DB, null kalau masih optimistic
    uploadId:  string | null   ← ID unik sementara untuk dedup gambar di realtime
    text:      string | null
    image:     string | null   ← base64 preview ATAU URL server
    sender:    'user'|'seller'
    time:      string          ← waktu format HH:MM (untuk bubble)
    time_raw:  string          ← ISO string asli (untuk day separator)
    pending:   boolean         ← true = belum dikonfirmasi server
    uploading: boolean         ← true = sedang upload gambar
  }
  */
  messages: any[] = [];

  newMessage = '';

  chatData: any = {};

  shopName = '';

  isLoading = true;

  // Guard mencegah double send teks (double tap / spam enter)
  isSending = false;

  isScrolling = false;
  private scrollTimeout: any;

  private currentUserId: number | null = null;

  private shouldScrollDown = false;

  constructor(
    private route:    ActivatedRoute,
    private location: Location,
    private http:     HttpClient,
    private realtime: RealtimeService,
    private ngZone:   NgZone           // [FIX Bug #2] inject NgZone
  ) {
    addIcons({
      arrowBackOutline,
      sendOutline,
      imageOutline,
      cameraOutline
    });
  }

  ngOnInit() {

    // Baca chatData dari navigation state (dari rincian pesanan / chat list)
    const nav = history.state;
    if (nav.chatData) {
      this.chatData = nav.chatData;
      this.shopName = nav.chatData.name || '';
    }

    // Baca currentUserId dari localStorage
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.currentUserId = Number(JSON.parse(userStr).id) || null;
    }

    // PENTING: loadMessages() dan connectRealtime() HARUS dipanggil setelah
    // roomId tersedia dari route params. Jika dipanggil di luar subscribe,
    // roomId masih NaN → request ke /chat-rooms/NaN/messages gagal →
    // messages kosong → timestamp tidak tampil (bug saat masuk dari rincian pesanan).
    this.route.params.subscribe(params => {
      this.roomId = Number(params['id']);

      // Reset state agar tidak tercampur jika pindah room
      this.messages  = [];
      this.isLoading = true;

      this.loadRoomDetails();
      this.loadMessages();
      this.connectRealtime();
    });

  }

  // Fetch detail info chat room (nama toko/pembeli & avatar) langsung dari API
  loadRoomDetails() {
    const token = localStorage.getItem('token');
    if (!token) return;

    this.http.get(
      `${environment.apiUrl}/chat-rooms`,
      { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) }
    ).subscribe({
      next: (res: any) => {
        const rooms = res.data || [];
        const room = rooms.find((r: any) => Number(r.id) === Number(this.roomId));
        if (room) {
          const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
          const isMe = Number(room.buyer_id) === Number(currentUser.id);

          const partnerName = isMe
            ? room.seller?.store?.store_name || room.seller?.name || 'Penjual'
            : room.buyer?.name || 'Pembeli';

          const partnerAvatar = isMe
            ? room.seller?.store?.store_logo
              ? `${environment.baseUrl}/` + room.seller.store.store_logo
              : 'https://cdn-icons-png.flaticon.com/512/1077/1077114.png'
            : room.buyer?.profile_photo_path
              ? `${environment.baseUrl}/` + room.buyer.profile_photo_path
              : 'https://cdn-icons-png.flaticon.com/512/149/149071.png';

          this.chatData = {
            ...this.chatData,
            name: partnerName,
            avatar: partnerAvatar
          };
          this.shopName = partnerName;
        }
      },
      error: (err) => {
        console.error('Error loading room details:', err);
      }
    });
  }

  ngAfterViewChecked() {
    if (this.shouldScrollDown) {
      this.scrollToBottom();
      this.shouldScrollDown = false;
    }
  }

  ngOnDestroy() {
    if (this.realtime.echo && this.roomId) {
      this.realtime.echo.leave(`chat.${this.roomId}`);
    }
  }

  // ─────────────────────────────────────────────
  // LOAD RIWAYAT PESAN
  // ─────────────────────────────────────────────

  loadMessages() {

    const token = localStorage.getItem('token');

    this.http.get(
      `${environment.apiUrl}/chat-rooms/${this.roomId}/messages`,
      { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) }
    ).subscribe({

      next: (res: any) => {
        const rawMessages = (res.data || []).slice().reverse();

        this.messages = rawMessages.map((msg: any) => ({
          id:        msg.id,
          uploadId:  null,
          text:      msg.message || null,
          sender:    Number(msg.sender_id) === Number(this.currentUserId) ? 'user' : 'seller',
          time:      this.formatTime(msg.created_at),
          time_raw:  msg.created_at,           // [FIX Bug #6] simpan raw ISO string
          image:     msg.image_url || null,
          pending:   false,
          uploading: false
        }));

        this.isLoading        = false;
        this.shouldScrollDown = true;
      },

      error: () => { this.isLoading = false; }

    });

  }

  // ─────────────────────────────────────────────
  // REALTIME — Laravel Echo + Pusher
  // ─────────────────────────────────────────────

  connectRealtime() {

    const token = localStorage.getItem('token');
    if (!token) return;

    // Tinggalkan channel lama terlebih dahulu untuk mencegah double listener
    if (this.realtime.echo && this.roomId) {
      this.realtime.echo.leave(`chat.${this.roomId}`);
    }

    this.realtime.connect(token);

    this.realtime.listenChat(this.roomId, (event: any) => {

      const msg = event.message;

      const senderLabel = Number(msg.sender_id) === Number(this.currentUserId)
        ? 'user'
        : 'seller';

      // Helper buat objek pesan dari data realtime
      const buildMsg = (overrides: any = {}) => ({
        id:        msg.id,
        uploadId:  null,
        text:      msg.message || null,
        sender:    senderLabel,
        time:      this.formatTime(msg.created_at || new Date().toISOString()),
        time_raw:  msg.created_at || new Date().toISOString(),  // [FIX Bug #6]
        image:     msg.image_url || null,
        pending:   false,
        uploading: false,
        ...overrides
      });

      // Layer 1: dedup by DB ID
      const alreadyById = this.messages.some(m => m.id === msg.id && msg.id != null);
      if (alreadyById) return;

      if (senderLabel === 'user') {

        // Layer 2A: replace optimistic teks
        if (!msg.image_url) {
          const pendingTeksIdx = this.messages.findIndex(
            m => m.pending === true && m.text === msg.message && !m.image
          );
          if (pendingTeksIdx !== -1) {
            this.messages[pendingTeksIdx] = buildMsg();
            this.shouldScrollDown = true;
            return;
          }
        }

        // Layer 2B: replace optimistic GAMBAR berdasarkan uploadId
        if (msg.upload_id) {
          const pendingImgIdx = this.messages.findIndex(
            m => m.uploadId === msg.upload_id && m.uploading === true
          );
          if (pendingImgIdx !== -1) {
            this.messages[pendingImgIdx] = buildMsg({
              image: msg.image_url || this.messages[pendingImgIdx].image
            });
            this.shouldScrollDown = true;
            return;
          }
        }

        // Fallback Layer 2B: kalau backend belum kirim upload_id
        if (msg.image_url) {
          const pendingImgFallbackIdx = this.messages.findIndex(
            m => m.pending === true && m.uploading === true && m.image
          );
          if (pendingImgFallbackIdx !== -1) {
            this.messages[pendingImgFallbackIdx] = buildMsg({ image: msg.image_url });
            this.shouldScrollDown = true;
            return;
          }
        }

      }

      // Layer 3: pesan dari seller atau pesan baru
      this.messages.push(buildMsg());
      this.shouldScrollDown = true;

      // Simpan last message ke localStorage agar chat list update
      const preview = msg.message ? msg.message : (msg.image_url ? '📷 Foto' : '');
      if (preview) this.saveLastMessageToStorage(preview, msg.image_url ? 'image' : 'text');

    });

  }

  // ─────────────────────────────────────────────
  // KIRIM PESAN TEKS
  // ─────────────────────────────────────────────

  sendMessage() {

    const text = this.newMessage.trim();
    if (!text) return;
    if (this.isSending) return;

    this.isSending = true;

    const token = localStorage.getItem('token');
    const now   = new Date().toISOString();

    const optimisticMsg = {
      id:        null,
      uploadId:  null,
      text,
      sender:    'user',
      time:      this.formatTime(now),
      time_raw:  now,                   // [FIX Bug #6]
      image:     null,
      pending:   true,
      uploading: false
    };

    this.messages.push(optimisticMsg);
    this.newMessage       = '';
    this.shouldScrollDown = true;

    this.http.post(
      `${environment.apiUrl}/chat-rooms/${this.roomId}/messages`,
      { message: text },
      { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) }
    ).subscribe({

      next: (res: any) => {
        const savedMsg = res?.data;
        if (savedMsg?.id) {
          const idx = this.messages.findIndex(
            m => m.pending === true && m.text === text && !m.image
          );
          if (idx !== -1) {
            this.messages[idx].id      = savedMsg.id;
            this.messages[idx].pending = false;
          }
        }
        // Simpan last message ke localStorage agar chat list bisa tampilkan pesan terbaru
        this.saveLastMessageToStorage(text, 'text');
        this.isSending       = false;
      },

      error: () => {
        const idx = this.messages.findIndex(
          m => m.pending === true && m.text === text && !m.image
        );
        if (idx !== -1) this.messages.splice(idx, 1);
        this.isSending = false;
      }

    });

  }

  // ─────────────────────────────────────────────
  // KIRIM GAMBAR
  // ─────────────────────────────────────────────

  private sendImage(file: File) {

    const token = localStorage.getItem('token');

    const reader = new FileReader();
    reader.onload = (ev: any) => {

      const localPreview = ev.target.result as string;
      const uploadId     = `img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const now          = new Date().toISOString();

      const optimisticImg = {
        id:        null,
        uploadId,
        text:      null,
        sender:    'user',
        time:      this.formatTime(now),
        time_raw:  now,               // [FIX Bug #6]
        image:     localPreview,
        pending:   true,
        uploading: true
      };

      this.messages.push(optimisticImg);
      this.shouldScrollDown = true;

      const formData = new FormData();
      formData.append('image', file, file.name);
      formData.append('upload_id', uploadId);

      this.http.post(
        `${environment.apiUrl}/chat-rooms/${this.roomId}/messages`,
        formData,
        {
          headers: new HttpHeaders({
            Authorization: `Bearer ${token}`
          })
        }
      ).subscribe({

        next: (res: any) => {
          const savedMsg = res?.data;
          const idx = this.messages.findIndex(m => m.uploadId === uploadId);
          if (idx !== -1) {
            this.messages[idx] = {
              id:        savedMsg?.id || null,
              uploadId:  null,
              text:      null,
              sender:    'user',
              time:      this.messages[idx].time,
              time_raw:  this.messages[idx].time_raw,
              image:     savedMsg?.image_url || localPreview,
              pending:   false,
              uploading: false
            };
          }
        },

        error: () => {
          const idx = this.messages.findIndex(m => m.uploadId === uploadId);
          if (idx !== -1) this.messages.splice(idx, 1);
        }

      });

    };

    reader.readAsDataURL(file);

  }

  // ─────────────────────────────────────────────
  // PICK IMAGE (galeri) — [FIX Bug #2] NgZone + append to body
  // ─────────────────────────────────────────────

  async pickImage() {
    const input         = document.createElement('input');
    input.type          = 'file';
    input.accept        = 'image/*';
    input.style.display = 'none';
    document.body.appendChild(input);

    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      // NgZone.run() memastikan Angular zone aktif kembali setelah
      // kamera/galeri menutup dan app kembali ke foreground
      if (file) this.ngZone.run(() => this.sendImage(file));
      document.body.removeChild(input);
    };

    input.click();
  }

  // ─────────────────────────────────────────────
  // OPEN CAMERA — [FIX Bug #2] NgZone + append to body
  // ─────────────────────────────────────────────

  async openCamera() {
    const input         = document.createElement('input');
    input.type          = 'file';
    input.accept        = 'image/*';
    input.setAttribute('capture', 'environment');
    input.style.display = 'none';
    document.body.appendChild(input);

    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      // NgZone.run() mencegah app kembali ke home setelah kamera ditutup
      if (file) this.ngZone.run(() => this.sendImage(file));
      document.body.removeChild(input);
    };

    input.click();
  }

  // ─────────────────────────────────────────────
  // QUICK MESSAGE
  // ─────────────────────────────────────────────

  sendQuickMessage(text: string) {
    this.newMessage = text;
    this.sendMessage();
  }



  // ─────────────────────────────────────────────
  // IMAGE ERROR FALLBACK
  // ─────────────────────────────────────────────

  onImageError(event: any) {
    event.target.style.display = 'none';
  }

  get groupedMessages() {
    const groups: { dayLabel: string; timeRaw: string; messages: any[] }[] = [];
    let currentGroup: { dayLabel: string; timeRaw: string; messages: any[] } | null = null;

    this.messages.forEach((msg, index) => {
      const dayLabel = this.formatDayLabel(msg.time_raw);
      if (!currentGroup || currentGroup.dayLabel !== dayLabel) {
        currentGroup = {
          dayLabel,
          timeRaw: msg.time_raw,
          messages: []
        };
        groups.push(currentGroup);
      }
      currentGroup.messages.push({ ...msg, originalIndex: index });
    });

    return groups;
  }

  // ─────────────────────────────────────────────
  // FORMAT WAKTU BUBBLE — [FIX Bug #5]
  // Selalu return HH:MM saja.
  // Konteks tanggal ditangani oleh day separator (Bug #6).
  // ─────────────────────────────────────────────

  formatTime(datetime: string): string {
    if (!datetime) return '';
    const date = new Date(datetime);
    return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  }

  // ─────────────────────────────────────────────
  // LABEL HARI UNTUK SEPARATOR — [FIX Bug #6]
  // ─────────────────────────────────────────────

  formatDayLabel(datetime: string): string {
    if (!datetime) return '';
    const date = new Date(datetime);
    const now  = new Date();

    const sameDay = (a: Date, b: Date) =>
      a.getDate()     === b.getDate()     &&
      a.getMonth()    === b.getMonth()    &&
      a.getFullYear() === b.getFullYear();

    if (sameDay(date, now)) return 'Hari ini';

    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (sameDay(date, yesterday)) return 'Kemarin';

    return date.toLocaleDateString('id-ID', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  }

  // Cek apakah pesan ke-index adalah hari yang berbeda dari pesan sebelumnya
  isDifferentDay(index: number): boolean {
    if (index === 0) return true; // Pesan pertama selalu tampilkan separator

    const prev = this.messages[index - 1];
    const curr = this.messages[index];

    if (!prev?.time_raw || !curr?.time_raw) return false;

    const prevDate = new Date(prev.time_raw);
    const currDate = new Date(curr.time_raw);

    return prevDate.toDateString() !== currDate.toDateString();
  }

  // ─────────────────────────────────────────────
  // SCROLL KE BAWAH
  // ─────────────────────────────────────────────

  scrollToBottom() {
    try {
      this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
    } catch (e) {}
  }

  // ─────────────────────────────────────────────
  // SIMPAN LAST MESSAGE KE LOCALSTORAGE
  // Dipakai oleh chat list sebagai fallback jika API tidak return last_message
  // ─────────────────────────────────────────────

  saveLastMessageToStorage(text: string, type: 'text' | 'image') {
    const preview = type === 'image' ? '📷 Foto' : text;
    localStorage.setItem(
      `last_msg_${this.roomId}`,
      JSON.stringify({ text: preview, time: new Date().toISOString() })
    );
  }

  onScroll(event: any) {
    this.isScrolling = true;
    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }
    this.scrollTimeout = setTimeout(() => {
      this.isScrolling = false;
    }, 1200); // 1.2 detik setelah berhenti scroll, tanggal memudar/menghilang
  }

  goBack() {
    this.location.back();
  }

}