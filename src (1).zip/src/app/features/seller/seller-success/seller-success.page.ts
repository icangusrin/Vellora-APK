import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonIcon } from '@ionic/angular/standalone';
import { RouterModule, Router } from '@angular/router';
import { addIcons } from 'ionicons';
import { chevronBackOutline, checkmarkOutline, mailOutline, checkmarkCircle } from 'ionicons/icons';

// FIX #4: Import AuthService untuk refreshUser
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-seller-success',
  templateUrl: './seller-success.page.html',
  styleUrls: ['./seller-success.page.scss'],
  standalone: true,
  imports: [IonContent, IonIcon, CommonModule, FormsModule, RouterModule]
})
export class SellerSuccessPage implements OnInit {

  showPopup = false;

  constructor(
    private router: Router,
    private authService: AuthService  // FIX #4: Inject AuthService
  ) {
    addIcons({
      'chevron-back-outline': chevronBackOutline,
      'checkmark-outline': checkmarkOutline,
      'mail-outline': mailOutline,
      'checkmark-circle': checkmarkCircle
    });
  }

  ngOnInit() {}

  goBack() { this.router.navigate(['/seller-store']); }

  finishRegister() {

    // FIX #4: Refresh data user dari API agar role 'seller' langsung aktif
    // di profile page tanpa perlu logout-login.
    // Sebelumnya hanya update localStorage secara manual (tidak trigger BehaviorSubject),
    // sehingga profile page tidak tahu ada perubahan role.
    this.authService.refreshUser().subscribe({
      next: () => {
        // User sudah diupdate di AuthService (BehaviorSubject + localStorage)
        this.showPopup = true;
        setTimeout(() => {
          this.router.navigate(['/tabs/profile']);
        }, 1800);
      },
      error: () => {
        // Jika API gagal, fallback: update manual seperti sebelumnya
        try {
          const savedUser = JSON.parse(localStorage.getItem('user') || '{}');
          if (savedUser && savedUser.role !== 'seller') {
            savedUser.role = 'seller';
            this.authService.saveUser(savedUser); // pakai saveUser agar BehaviorSubject ikut update
          }
        } catch (e) {}

        this.showPopup = true;
        setTimeout(() => {
          this.router.navigate(['/tabs/profile']);
        }, 1800);
      }
    });

  }

}