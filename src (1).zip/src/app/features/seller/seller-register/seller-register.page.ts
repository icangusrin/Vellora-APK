import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  HttpClient,
  HttpClientModule
} from '@angular/common/http';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import {
  RouterModule,
  Router
} from '@angular/router';

import {
  addIcons
} from 'ionicons';

import {
  chevronBackOutline,
  shieldCheckmarkOutline,
  eyeOutline,
  eyeOffOutline
} from 'ionicons/icons';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-seller-register',
  templateUrl: './seller-register.page.html',
  styleUrls: ['./seller-register.page.scss'],
  standalone: true,

  imports: [
    IonContent,
    IonIcon,
    CommonModule,
    FormsModule,
    RouterModule,
    HttpClientModule
  ]
})

export class SellerRegisterPage
implements OnInit {

  // USER
  email = '';

  // INPUT
  password = '';

  confirmPassword = '';

  showPassword = false;

  showConfirmPassword = false;

  // POPUP
  showPopup = false;

  popupMessage = '';

  // SUCCESS
  isSuccess = false;

  apiUrl =
    environment.apiUrl;

  constructor(
    private router: Router,
    private http: HttpClient
  ) {

    addIcons({

      'chevron-back-outline':
        chevronBackOutline,

      'shield-checkmark-outline':
        shieldCheckmarkOutline,

      'eye-outline':
        eyeOutline,

      'eye-off-outline':
        eyeOffOutline

    });

  }

  ngOnInit() {

    const profile =
      localStorage.getItem(
        'user'
      );

    if (profile) {

      const user =
        JSON.parse(profile);

      this.email =
        user.email || '';

    }

  }
  

  // BACK
  goBack() {

    this.router.navigate([
      '/join-seller'
    ]);

  }

  // CONTINUE
  continueRegister() {

    // VALIDASI
    if (
      !this.password ||
      !this.confirmPassword
    ) {

      this.popupMessage =
        'Password wajib diisi';

      this.showPopup = true;

      return;

    }

    // PASSWORD TIDAK SAMA
    if (
      this.password !==
      this.confirmPassword
    ) {

      this.popupMessage =
        'Konfirmasi password tidak cocok';

      this.showPopup = true;

      return;

    }

    const token =
      localStorage.getItem(
        'token'
      );

    // CEK PASSWORD KE API LOGIN
    this.http.post(

      `${this.apiUrl}/auth/login`,

      {

        email:
          this.email,

        password:
          this.password

      }

    )
    .subscribe({

      next: (res: any) => {

        // SIMPAN MODE SELLER
        localStorage.setItem(
          'sellerRegisterVerified',
          'true'
        );

        this.isSuccess = true;

        this.popupMessage =
          'Verifikasi berhasil';

        this.showPopup = true;

      },

      error: (err) => {

        this.popupMessage =
          'Password akun salah';

        this.showPopup = true;

      }

    });

  }

  // CLOSE POPUP
  closePopup() {

    this.showPopup = false;

    // JIKA BERHASIL
    if (this.isSuccess) {

      this.router.navigate([
        '/seller-store'
      ]);

    }

  }

}