import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  Router
} from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import { environment } from 'src/environments/environment';

import {
  arrowBackOutline,
  shareSocialOutline,
  cartOutline,
  chevronForwardOutline,
  chatbubbleOutline,
  closeOutline,
  starOutline,
  star,
  cubeOutline
} from 'ionicons/icons';

import {
  ChatService
} from '../../../core/services/chat.service';

// [TAMBAH] Import ReviewService
import {
  ReviewService
} from '../../../core/services/review.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.page.html',
  styleUrls: ['./product-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon
  ]
})

export class ProductDetailPage
implements OnInit {

  product: any;

  shop: any;

  productDescription = '';

  selectedVariant = 'Default';

  showVariants = false;

  variants: string[] = [];

  category = 'Produk';

  showFullDescription = false;

  productName = '';

  // ─────────────────────────────────────────────
  // [TAMBAH] REVIEW SECTION — property baru
  // ─────────────────────────────────────────────

  /** Daftar review dari API */
  reviews: any[] = [];

  /** Status loading saat fetch review */
  isLoadingReviews = false;

  /**
   * Rating rata-rata produk.
   * Dibaca dari kolom rating_avg yang sudah di-cache di tabel products.
   */
  ratingAvg: number | null = null;

  /** Total jumlah review produk (dari kolom rating_count) */
  ratingCount = 0;

  /** Distribusi jumlah per bintang, dihitung dari data reviews */
  ratingDist: { [key: number]: number } = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };

  /** Array [1,2,3,4,5] untuk ngFor bintang di template */
  readonly stars = [1, 2, 3, 4, 5];

  // Toast notifikasi
  toastVisible = false;
  toastMessage = '';
  private toastTimer: any;

  constructor(
    private location: Location,
    private router: Router,
    private chatService: ChatService,
    // [TAMBAH] inject ReviewService
    private reviewService: ReviewService
  ) {

    addIcons({
      arrowBackOutline,
      shareSocialOutline,
      cartOutline,
      chevronForwardOutline,
      chatbubbleOutline,
      closeOutline,
      starOutline,
      star,
      cubeOutline
    });

  }

  ngOnInit() {

    const nav = history.state;

    if (!nav.product) return;

    const data = nav.product;

    this.product = {

      ...data,

      image:
        data.image
          ? data.image
          : data.images?.length > 0
            ? `${environment.baseUrl}/product_images/` +
              data.images[0].image
            : 'https://picsum.photos/300',

      name:
        data.product_name ||
        data.name ||
        'Produk',

      rawPrice: Number(data.rawPrice || data.price),

      price:
        data.price_format ||
        ('Rp' +
          Number(data.rawPrice || data.price)
            .toLocaleString('id-ID')),

      // Stok — coba berbagai field nama yang mungkin dikirim API
      stock:
        data.stock ??
        data.quantity ??
        data.stock_qty ??
        null

    };

    this.shop = data.store
      ? {
          id: data.store.id,
          store_id: data.store.id,
          user_id: data.store.user_id,
          name: data.store.store_name,
          store_name: data.store.store_name,
          phone_number: data.store.phone_number || '',
          avatar: data.store.store_logo
          ? `${environment.baseUrl}/` + data.store.store_logo
            : 'https://cdn-icons-png.flaticon.com/512/1077/1077114.png'
        }
      : data.shop || {
          id: null,
          name: 'Toko',
          avatar: 'https://cdn-icons-png.flaticon.com/512/1077/1077114.png'
        };

    this.category =
      data.category?.category_name ||
      data.category ||
      'Produk';

    this.productDescription =
      data.description || 'Tidak ada deskripsi';

    this.variants = [];

    if (Array.isArray(data.variants) && data.variants.length > 0) {

      for (const v of data.variants) {

        this.variants.push(
          typeof v === 'string' ? v : String(v.variant_name)
        );

      }

    } else {

      this.variants.push('Default');

    }

    this.selectedVariant = this.variants[0];

    this.productName = this.product?.name || 'Produk';

    // [TAMBAH] Baca rating dari kolom yang sudah di-cache di produk
    this.ratingAvg   = data.rating_avg   ? parseFloat(data.rating_avg)  : null;
    this.ratingCount = data.rating_count  ? parseInt(data.rating_count)  : 0;

    // [TAMBAH] Load reviews dari API
    if (this.product?.id) {
      this.loadReviews();
    }

  }

  // ─────────────────────────────────────────────
  // [TAMBAH] METHOD REVIEW
  // ─────────────────────────────────────────────

  /**
   * Fetch semua review untuk produk ini.
   * Endpoint: GET /products/{id}/reviews  (public, tidak perlu auth)
   * Response field per review: user_name, user_photo, rating, review, created_at
   */
  loadReviews() {

    this.isLoadingReviews = true;

    this.reviewService.getProductReviews(this.product.id).subscribe({

      next: (res: any) => {

        this.reviews = res.data ?? [];

        // Hitung distribusi bintang dari data yang sudah dimuat
        this.ratingDist = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };

        for (const rv of this.reviews) {
          if (this.ratingDist[rv.rating] !== undefined) {
            this.ratingDist[rv.rating]++;
          }
        }

        this.isLoadingReviews = false;

      },

      error: () => {
        this.isLoadingReviews = false;
      }

    });

  }

  /**
   * Hitung persentase bar distribusi bintang untuk UI.
   * Contoh: bintang 5 ada 8 dari 10 review → 80%
   */
  getBarPct(starValue: number): number {

    if (!this.reviews.length) return 0;

    return Math.round(
      (this.ratingDist[starValue] / this.reviews.length) * 100
    );

  }

  /*
  =========================
  DIPAKAI HTML — variantTitle
  =========================
  */

  get variantTitle(): string {

    return this.selectedVariant || 'Pilih Varian';

  }

  /*
  =========================
  DIPAKAI HTML — openChat()
  Alias untuk startChat()
  =========================
  */

  openChat() {

    this.startChat();

  }

  /*
  =========================
  DIPAKAI HTML — confirmAddToCart()
  Alias untuk addToCart()
  =========================
  */

  confirmAddToCart() {

    this.addToCart();
    this.showVariants = false; // tutup popup setelah tambah ke keranjang

  }

  /*
  =========================
  MULAI CHAT KE PENJUAL
  =========================
  */

  startChat() {

    if (!this.product?.store?.user_id) {

      console.log('USER ID TOKO TIDAK ADA');

      return;

    }

    this.chatService.createRoom({

      seller_id: this.product.store.user_id,

      product_id: this.product.id

    }).subscribe({

      next: (res: any) => {

        const roomId = res.data.id;

        this.router.navigate(
          ['/chat-detail', roomId],
          {
            state: {
              chatData: {
                name: this.shop?.store_name || this.shop?.name,
                avatar: this.shop?.avatar
              }
            }
          }
        );

      },

      error: (err) => {

        console.log('CREATE ROOM ERROR', err);

      }

    });

  }

  /*
  =========================
  ADD TO CART
  =========================
  */

  addToCart() {
  
    const productCart = {
      id:           this.product.id + '-' + this.selectedVariant,
      product_id:   this.product.id,
      store_id:     this.shop?.id,
      name:         this.product.name,
      price:        this.product.rawPrice,
      price_format: this.product.price,
      image:        this.product.image,
      category:     this.category,
      variant:      this.selectedVariant,
      qty:          1,
      checked:      false,
      shop:         this.shop
    };
  
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
  
    const index = cart.findIndex((item: any) => item.id === productCart.id);
  
    if (index !== -1) {
      cart[index].qty += 1;
    } else {
      cart.push(productCart);
    }
  
    localStorage.setItem('cart', JSON.stringify(cart));

    this.showToast('Produk berhasil ditambahkan ke keranjang 🛒');
  }

  /*
  =========================
  TOAST NOTIFIKASI
  =========================
  */

  showToast(msg: string) {
    this.toastMessage = msg;
    this.toastVisible = true;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => {
      this.toastVisible = false;
    }, 2000);
  }

  /*
  =========================
  BELI SEKARANG
  =========================
  */

  buyNow() {

    const item = {

      id: this.product.id + '-' + this.selectedVariant,

      product_id: this.product.id,

      store_id: this.shop?.id,

      name: this.product.name,

      price: this.product.rawPrice,

      price_format: this.product.price,

      image: this.product.image,

      category: this.category,

      variant: this.selectedVariant,

      qty: 1,

      checked: true,

      shop: this.shop

    };

    localStorage.setItem(
      'checkoutItems',
      JSON.stringify([item])
    );

    localStorage.setItem(
      'checkoutTotal',
      this.product.rawPrice.toString()
    );

    this.router.navigate(['/checkout']);

  }

  /*
  =========================
  TOGGLE VARIANT MODAL
  =========================
  */

  toggleVariants() {

    this.showVariants = !this.showVariants;

  }

  selectVariant(variant: string) {

    this.selectedVariant = variant;

    this.showVariants = false;

  }

  /*
  =========================
  TOGGLE DESKRIPSI
  =========================
  */

  toggleDescription() {

    this.showFullDescription = !this.showFullDescription;

  }

  /*
  =========================
  GO BACK
  =========================
  */

  goBack() {

    this.location.back();

  }

  goToCart() {

    this.router.navigate(['/cart']);

  }

  goToShop() {

    this.router.navigate(['/shop-profile'], {
      state: { shop: this.shop }
    });

  }

  /*
  =========================
  SHARE
  =========================
  */

  async shareProduct() {

    if (navigator.share) {

      await navigator.share({
        title: this.productName,
        text: 'Lihat produk ini!',
        url: window.location.href
      });

    } else {

      await navigator.clipboard.writeText(
        window.location.href
      );

    }

  }

}