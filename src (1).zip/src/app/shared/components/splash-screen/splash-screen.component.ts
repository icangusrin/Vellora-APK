import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-splash-screen',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './splash-screen.component.html',
  styleUrls: ['./splash-screen.component.scss']
})
export class SplashScreenComponent implements OnInit {
  // Dipanggil app.component setelah animasi selesai, untuk pindah ke halaman utama
  @Output() finished = new EventEmitter<void>();

  ngOnInit(): void {
    // Total durasi animasi ~3.8s, samakan dengan animation di SCSS
    setTimeout(() => this.finished.emit(), 3800);
  }
}