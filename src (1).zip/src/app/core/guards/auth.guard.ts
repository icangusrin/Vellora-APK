import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const AuthGuard: CanActivateFn = (route, state) => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) {
    return true;
  }

  // Redirect ke login + simpan halaman tujuan sebagai query param
  router.navigate(['/auth/login'], {
    queryParams: { redirectTo: state.url }
  });
  return false;
};