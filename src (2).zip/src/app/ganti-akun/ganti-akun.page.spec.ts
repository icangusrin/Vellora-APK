import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GantiAkunPage } from './ganti-akun.page';

describe('GantiAkunPage', () => {
  let component: GantiAkunPage;
  let fixture: ComponentFixture<GantiAkunPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(GantiAkunPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
