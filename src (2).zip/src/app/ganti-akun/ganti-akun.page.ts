import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  Router
} from '@angular/router';

import {
  IonContent,
  IonIcon,
  AlertController
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  addOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-ganti-akun',
  templateUrl: './ganti-akun.page.html',
  styleUrls: ['./ganti-akun.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon
  ]
})

export class GantiAkunPage {

  totalAccount = 1;

  constructor(
    private location: Location,
    private alertController: AlertController,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline,
      addOutline
    });

  }

  // BACK
goBack() {

  this.router.navigate([
    '/account-settings'
  ]);

}

  // LOGOUT
  async logout() {

    const alert = await this.alertController.create({

      header: 'Keluar',

      message: 'Keluar dari LayananApp?',

      buttons: [
        {
          text: 'Batal',
          role: 'cancel'
        },
        {
          text: 'Keluar',
          handler: () => {

            console.log('User keluar');

            // nanti arahkan ke login
            // this.router.navigate(['/login']);

          }
        }
      ]

    });

    await alert.present();

  }

  // ADD ACCOUNT
  async addAccount() {

    if (this.totalAccount >= 2) {

      const alert =
        await this.alertController.create({

        header: 'Peringatan',

        message:
          'Maksimal hanya 2 akun yang dapat ditambahkan.',

        buttons: ['OK']

      });

      await alert.present();

      return;

    }

    this.router.navigate([
      '/login'
    ]);

  }

}