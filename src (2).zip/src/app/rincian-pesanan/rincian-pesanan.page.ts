import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chatbubbleOutline,
  locationOutline,
  chevronForwardOutline,
  copyOutline,
  walletOutline,
  cubeOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-rincian-pesanan',
  templateUrl: './rincian-pesanan.page.html',
  styleUrls: ['./rincian-pesanan.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon
  ]
})

export class RincianPesananPage
implements OnInit {

  order: any;

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline,
      chatbubbleOutline,
      locationOutline,
      chevronForwardOutline,
      copyOutline,
      walletOutline,
      cubeOutline
    });

  }

  ngOnInit() {

    // AMBIL ID
    const id = Number(
      this.route.snapshot.paramMap.get('id')
    );

    // STORAGE
    const savedOrders =
      localStorage.getItem('orders');

    if (savedOrders) {

      const orders = JSON.parse(savedOrders);

      // CARI ORDER
      const foundOrder = orders.find(
        (item: any) => Number(item.id) === id
      );

      if (foundOrder) {

        this.order = {

          // ID
          id:
            foundOrder.id,

          // STATUS
          status:
            foundOrder.status || 'dikemas',

          // NAMA PRODUK
          productName:
            foundOrder.productName ||
            foundOrder.name ||
            'Produk',

          // VARIAN
          variant:
            foundOrder.variant || 'Default',

          // GAMBAR
          image:
            foundOrder.image ||
            'assets/no-image.png',

          // HARGA SATUAN
          price:
            foundOrder.price || 0,

          // JUMLAH
          qty:
            foundOrder.qty ||
            foundOrder.quantity ||
            1,

          // SUBTOTAL (harga × qty)
          subtotal:
            (foundOrder.price || 0) *
            (foundOrder.qty || foundOrder.quantity || 1),

          // TOKO
          store:
            foundOrder.store || 'Glow Beauty',

          // BERAT
          weight:
            foundOrder.weight || 1,

          // ONGKIR
          shipping:
            foundOrder.shipping || 10000,

          // DISKON
          discount:
            foundOrder.discount || 0,

          // GRATIS ONGKIR
          freeShipping:
            foundOrder.freeShipping || false,

          // VOUCHER
          voucher:
            foundOrder.voucher || '',

          // TOTAL AKHIR
          finalTotal:
            foundOrder.finalTotal || 0,

          // ALAMAT
          address:
            foundOrder.address ||
            'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373',

          // PENERIMA
          receiver:
            foundOrder.receiver ||
            'Vina (08735627811)',

          // NO. RESI
          receiptNumber:
            foundOrder.receiptNumber ||
            'JX3483920',

          // KURIR
          courier:
            foundOrder.courier ||
            'Ninja Xpress',

          // TANGGAL PEMBELIAN
          purchaseDate:
            foundOrder.purchaseDate ||
            '08 Mei 2026 10:15 WIB',

          // ESTIMASI TIBA
          estimateDate:
            foundOrder.estimateDate ||
            foundOrder.estimate ||
            '10 Mei 2026',

          // METODE PEMBAYARAN
          paymentMethod:
            foundOrder.paymentMethod ||
            'COD (Bayar di Tempat)'

        };

      }

    }

  }

  // STATUS TEXT
  getStatusText(status: string) {

    switch (status) {

      case 'belum-dibayar':
        return 'Belum Dibayar';

      case 'dikemas':
        return 'Pesanan Dikemas';

      case 'dikirim':
        return 'Pesanan Dikirim';

      case 'selesai':
        return 'Pesanan Selesai';

      case 'dibatalkan':
        return 'Pesanan Dibatalkan';

      default:
        return 'Pesanan';

    }

  }

  // BUKA TOKO
  openShop() {

    let shopData: any = {

      name:
        this.order.store ||
        'Shop'

    };

    // GLOW BEAUTY
    if (
      this.order.store ===
      'Glow Beauty'
    ) {

      shopData.avatar =
        'assets/shop/skincare.jpg';

    }

    // VOLT ELECTRONICS
    else if (
      this.order.store ===
      'Volt Electronics'
    ) {

      shopData.avatar =
        'assets/shop/electronic.jpg';

    }

    // ZOYA FASHION
    else if (
      this.order.store ===
      'Zoya Fashion'
    ) {

      shopData.avatar =
        'assets/shop/fashion.jpg';

    }

    // CEMILKU STORE
    else if (
      this.order.store ===
      'Cemilku Store'
    ) {

      shopData.avatar =
        'assets/shop/snack.jpg';

    }

    this.router.navigate(
      ['/shop-profile'],
      {
        state: {
          shop: shopData
        }
      }
    );

  }

  // BACK
  trackOrder() {

    this.router.navigate([
      '/lacak-pesanan',
      this.order.id
    ]);

  }

  goBack() {

    this.location.back();

  }

}