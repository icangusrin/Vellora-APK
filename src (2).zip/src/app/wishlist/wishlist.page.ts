import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  heartDislikeOutline,
  heart,
  bagAddOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.page.html',
  styleUrls: ['./wishlist.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})

export class WishlistPage {

  products: any[] = [];

  toastMsg = '';
  showToast = false;

  isEditMode = false;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline,
      heartDislikeOutline,
      heart,
      bagAddOutline
    });

  }

  ionViewWillEnter() {

    this.products = JSON.parse(
      localStorage.getItem('wishlist') || '[]'
    );

  }

  toggleEditMode() {
    this.isEditMode = !this.isEditMode;
  }

  // HAPUS MULTIPLE
  deleteSelected() {

    const updated = this.products.filter(
      item => !item.selected
    );

    localStorage.setItem(
      'wishlist',
      JSON.stringify(updated)
    );

    this.products = updated;

    this.toast('Produk berhasil dihapus');

  }

  // HAPUS SINGLE
  remove(product: any) {

    const wishlist = JSON.parse(
      localStorage.getItem('wishlist') || '[]'
    );

    const updated = wishlist.filter(
      (p: any) => p.id !== product.id
    );

    localStorage.setItem(
      'wishlist',
      JSON.stringify(updated)
    );

    this.products = updated;

    this.toast('Dihapus dari Wishlist');

  }

  openDetail(product: any) {

    if (this.isEditMode) return;

    this.router.navigate(
      ['/product-detail'],
      { state: { product } }
    );

  }

  addToCart(product: any, event: Event) {

    event.stopPropagation();

    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    const existing = cart.find(
      (c: any) => c.id === product.id
    );

    if (existing) {
      existing.qty = (existing.qty || 1) + 1;
    } else {
      cart.push({ ...product, qty: 1 });
    }

    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

    this.toast('Ditambahkan ke Keranjang!');

  }

  toast(msg: string) {

    this.toastMsg = msg;

    this.showToast = true;

    setTimeout(() => {
      this.showToast = false;
    }, 2000);

  }

  goBack() {
    this.location.back();
  }

}