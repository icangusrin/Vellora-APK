import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonicModule
} from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  checkmarkCircle,
  ellipseOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-my-address',
  templateUrl: './my-address.page.html',
  styleUrls: ['./my-address.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class MyAddressPage {

  // TAMPIL FORM / LIST
  showForm = true;

  // DATA ALAMAT
  addresses: any[] = [];

  // FORM INPUT
  addressData = {

    fullName: '',

    phone: '',

    address: '',

    detail: '',

    isPrimary: false

  };

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline,

      'checkmark-circle':
        checkmarkCircle,

      'ellipse-outline':
        ellipseOutline

    });

  }

  // LOAD DATA
  ionViewWillEnter() {

    // LOAD LIST ALAMAT
    const savedAddresses =
      localStorage.getItem(
        'myAddresses'
      );

    if (savedAddresses) {

      this.addresses =
        JSON.parse(savedAddresses);

    }

    // LOAD HASIL ADDRESS PICKER
    const selectedAddress =
      localStorage.getItem(
        'selectedAddress'
      );

    // JIKA BARU PILIH ALAMAT
    if (selectedAddress) {

      this.addressData.address =
        selectedAddress;

      // TETAP TAMPIL FORM
      this.showForm = true;

    } else {

      // JIKA SUDAH ADA ALAMAT
      if (this.addresses.length > 0) {

        this.showForm = false;

      }

    }

  }

  // BACK
  goBack() {

    this.location.back();

  }

  // BUKA ADDRESS PICKER
  openAddressPicker() {

    this.router.navigate([
      '/address-picker'
    ]);

  }

  // SIMPAN ALAMAT
  saveAddress() {

    // VALIDASI
    if (
      !this.addressData.fullName ||
      !this.addressData.phone ||
      !this.addressData.address
    ) {
      return;
    }

    // JIKA ALAMAT UTAMA
    if (this.addressData.isPrimary) {

      this.addresses.forEach(item => {

        item.isPrimary = false;

      });

    }

    // JIKA BELUM ADA ALAMAT
    if (this.addresses.length === 0) {

      this.addressData.isPrimary = true;

    }

    // SIMPAN KE ARRAY
    this.addresses.push({

      ...this.addressData

    });

    // SIMPAN LOCAL STORAGE
    localStorage.setItem(

      'myAddresses',

      JSON.stringify(
        this.addresses
      )

    );

    // SIMPAN ALAMAT TERPILIH
    localStorage.setItem(

      'selectedCheckoutAddress',

      JSON.stringify(
        this.addresses[
          this.addresses.length - 1
        ]
      )

    );

    // HAPUS TEMP ADDRESS
    localStorage.removeItem(
      'selectedAddress'
    );

    // RESET FORM
    this.addressData = {

      fullName: '',

      phone: '',

      address: '',

      detail: '',

      isPrimary: false

    };

    // TAMPILKAN LIST
    this.showForm = false;

  }

  // TAMBAH ALAMAT BARU
  addNewAddress() {

    // HAPUS TEMP ADDRESS
    localStorage.removeItem(
      'selectedAddress'
    );

    // RESET FORM
    this.addressData = {

      fullName: '',

      phone: '',

      address: '',

      detail: '',

      isPrimary: false

    };

    // TAMPIL FORM
    this.showForm = true;

  }

  // HAPUS ALAMAT
  deleteAddress(index: number) {

    this.addresses.splice(
      index,
      1
    );

    // JIKA TIDAK ADA ALAMAT UTAMA
    const hasPrimary =
      this.addresses.some(
        item => item.isPrimary
      );

    // AUTO PILIH PERTAMA
    if (
      !hasPrimary &&
      this.addresses.length > 0
    ) {

      this.addresses[0].isPrimary =
        true;

    }

    // UPDATE STORAGE
    localStorage.setItem(

      'myAddresses',

      JSON.stringify(
        this.addresses
      )

    );

    // JIKA KOSONG
    if (this.addresses.length === 0) {

      this.showForm = true;

    }

  }

  // PILIH ALAMAT UTAMA
  setPrimaryAddress(index: number) {

    this.addresses.forEach(item => {

      item.isPrimary = false;

    });

    this.addresses[index].isPrimary =
      true;

    // UPDATE STORAGE
    localStorage.setItem(

      'myAddresses',

      JSON.stringify(
        this.addresses
      )

    );

    // SIMPAN KE CHECKOUT
    localStorage.setItem(

      'selectedCheckoutAddress',

      JSON.stringify(
        this.addresses[index]
      )

    );

  }

}