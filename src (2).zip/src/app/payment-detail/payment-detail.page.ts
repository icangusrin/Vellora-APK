import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  IonicModule
} from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  copyOutline,
  checkmarkCircleOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-payment-detail',
  templateUrl: './payment-detail.page.html',
  styleUrls: ['./payment-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class PaymentDetailPage {

  selectedBank = '';

  virtualAccount =
    '7209054362332';

  bankLogo = '';

  total = 'Rp.0';

  // COUNTDOWN
  countdown = '00:01:00';

  expiredAt = 0;

  timer: any;

  // POPUP COPY
  showCopyPopup = false;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'copy-outline': copyOutline,
      'checkmark-circle-outline': checkmarkCircleOutline
    });

  }

  ionViewWillEnter() {

    // AMBIL BANK
    this.selectedBank =
      localStorage.getItem(
        'selectedBank'
      ) || '';

    // AMBIL TOTAL
    const savedTotal =
      localStorage.getItem(
        'checkoutTotal'
      );

    if (savedTotal) {

      this.total = savedTotal;

    }

    // LOGO BANK
    if (this.selectedBank === 'BRI') {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/2/2e/BRI_2020.svg';

    }

    else if (this.selectedBank === 'BCA') {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/5/5c/Bank_Central_Asia.svg';

    }

    else {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/a/ad/Bank_Mandiri_logo_2016.svg';

    }

    // TIMER 1 MENIT
    this.expiredAt =
      Date.now() + (1 * 60 * 1000);

    this.startCountdown();

  }

  // COUNTDOWN
  startCountdown() {

    this.timer = setInterval(() => {

      const distance =
        this.expiredAt - Date.now();

      // HABIS
      if (distance <= 0) {

        clearInterval(this.timer);

        this.countdown =
          '00:00:00';

        return;

      }

      const minutes = Math.floor(
        (distance % (1000 * 60 * 60))
        / (1000 * 60)
      );

      const seconds = Math.floor(
        (distance % (1000 * 60))
        / 1000
      );

      this.countdown =
        `00:${minutes
          .toString()
          .padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`;

    }, 1000);

  }

  // COPY VA
  async copyVa() {

    await navigator.clipboard.writeText(
      this.virtualAccount
    );

    this.showCopyPopup = true;

    setTimeout(() => {

      this.showCopyPopup = false;

    }, 1500);

  }

  // KONFIRMASI PEMBAYARAN BANK
  confirmPayment() {

    clearInterval(this.timer);

    // AMBIL ORDERS
    const orders = JSON.parse(
      localStorage.getItem('orders') || '[]'
    );

    // UPDATE STATUS ORDER TERBARU KE DIKEMAS
    if (orders.length > 0) {

      orders[0].status = 'dikemas';

    }

    // SIMPAN ORDERS
    localStorage.setItem(
      'orders',
      JSON.stringify(orders)
    );

    // HAPUS DATA CHECKOUT
    localStorage.removeItem('checkoutItems');

    localStorage.removeItem('checkoutTotal');

    // SUCCESS
    this.router.navigate([
      '/success-order'
    ]);

  }

  goBack() {

    clearInterval(this.timer);

    this.location.back();

  }

}