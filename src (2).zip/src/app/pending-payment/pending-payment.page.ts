import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {
  CommonModule,
  Location
} from '@angular/common';

import { IonicModule } from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-pending-payment',
  templateUrl: './pending-payment.page.html',
  styleUrls: ['./pending-payment.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class PendingPaymentPage {

  // TOTAL PEMBAYARAN
  total = 'Rp.0';

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline
    });

  }

  ionViewWillEnter() {

    // AMBIL TOTAL DARI CHECKOUT
    const savedTotal = localStorage.getItem(
      'checkoutTotal'
    );

    if (savedTotal) {

      // FORMAT TETAP SAMA
      this.total = savedTotal;

    }

  }

goBack() {
  this.location.back();
}

goHome() {

  window.location.href = '/tabs/home';

}

goToPesanan() {

  this.router.navigate([
    '/pesanan'
  ]);

}

}