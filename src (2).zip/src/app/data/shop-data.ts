export const SHOPS = {
  fashion: {
    id: 1,
    name: 'Zoya Fashion',
    avatar: 'assets/shop/fashion.jpg'
  },

  snack: {
    id: 2,
    name: 'Cemilku Store',
    avatar: 'assets/shop/snack.jpg'
  },

  elektronik: {
    id: 3,
    name: 'Volt Electronics',
    avatar: 'assets/shop/electronic.jpg'
  },

  skincare: {
    id: 4,
    name: 'Glow Beauty',
    avatar: 'assets/shop/skincare.jpg'
  }
};