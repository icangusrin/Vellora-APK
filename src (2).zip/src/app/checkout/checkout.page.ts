import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chevronForwardOutline,
  locationOutline,
  receiptOutline,
  businessOutline,
  ticketOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.page.html',
  styleUrls: ['./checkout.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class CheckoutPage {

  // DATA CHECKOUT
  checkoutItems: any[] = [];

  total = 'Rp.0';

  // DATA ALAMAT
  selectedAddress: any = null;

  // VOUCHER
  selectedVoucher: any = null;

  // METODE PEMBAYARAN
  selectedPayment = 'Transfer Bank';

  // DETAIL BANK
  selectedBank = '';

  // COD CHECK
  isCodSelected = false;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'chevron-forward-outline': chevronForwardOutline,
      'location-outline': locationOutline,
      'receipt-outline': receiptOutline,
      'business-outline': businessOutline,
      'ticket-outline': ticketOutline
    });

  }

  ionViewWillEnter() {

    const items = localStorage.getItem(
      'checkoutItems'
    );

    const total = localStorage.getItem(
      'checkoutTotal'
    );

    const payment = localStorage.getItem(
      'selectedPayment'
    );

    // AMBIL VOUCHER
    const voucher = localStorage.getItem(
      'selectedVoucher'
    );

    // AMBIL ALAMAT
    const address = localStorage.getItem(
      'selectedCheckoutAddress'
    );

    if (items) {

      this.checkoutItems = JSON.parse(
        items
      ).map((item: any) => {

        return {

          id: item.id,

          name: item.name,

          price: item.price,

          image: item.image,

          qty: item.qty,

          variant: item.variant,

          category: item.category,

          // BERAT
          weight:
            item.weight || 1,

          // SHOP
          shop: item.shop || {
            name: 'Toko'
          }

        };

      });

    }

    if (total) {

      this.total = total;

    }

    if (payment) {

      // JIKA COD
      if (payment === 'COD') {

        this.selectedPayment = 'COD';

        this.isCodSelected = true;

      }

      // JIKA TRANSFER / BANK
      else {

        this.selectedPayment = 'Transfer Bank';

        this.selectedBank = payment;

        this.isCodSelected = false;

      }

    }

    // SET VOUCHER
    if (voucher) {

      this.selectedVoucher =
        JSON.parse(voucher);

    }

    else {

      this.selectedVoucher = null;

    }

    // SET ALAMAT
    if (address) {

      this.selectedAddress =
        JSON.parse(address);

    }

    // CHECK COD
    this.isCodSelected =
      this.selectedPayment === 'COD';

  }

  // PILIH COD
  selectCod() {

    this.isCodSelected = true;

    this.selectedPayment = 'COD';

    // RESET BANK
    this.selectedBank = '';

    localStorage.setItem(
      'selectedPayment',
      'COD'
    );

  }

  // GO TO VOUCHER
  goToVoucher() {

    this.router.navigate([
      '/voucher'
    ]);

  }

  // GO TO ADDRESS
  goToAddress() {

    this.router.navigate([
      '/my-address'
    ]);

  }

  // BUAT PESANAN
  createOrder() {

    // =========================
    // AMBIL CART
    // =========================

    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // AMBIL ITEM CHECKOUT
    const checkoutItems = JSON.parse(
      localStorage.getItem('checkoutItems') || '[]'
    );

    // HAPUS ITEM YANG SUDAH DI CHECKOUT
    const updatedCart = cart.filter(
      (cartItem: any) => {

        return !checkoutItems.some(
          (checkoutItem: any) =>

            checkoutItem.id === cartItem.id
        );

      }
    );

    // UPDATE CART
    localStorage.setItem(
      'cart',
      JSON.stringify(updatedCart)
    );

    // SIMPAN TOTAL FINAL
    localStorage.setItem(
      'checkoutTotal',
      this.getFinalTotal()
    );

    // =========================
    // SIMPAN ORDER
    // =========================

    const orders = JSON.parse(
      localStorage.getItem('orders') || '[]'
    );

    this.checkoutItems.forEach(item => {

      // ONGKIR
      const shippingCost =

        item.weight > 5
          ? 20000
          : 10000;

      // GRATIS ONGKIR
      const isFreeShipping =

        this.selectedVoucher &&

        this.selectedVoucher.title.includes(
          'Gratis Ongkir'
        );

      // PRICE NUMBER
      const itemPrice = Number(
        item.price
          .toString()
          .replace('Rp.', '')
          .replace(/\./g, '')
      );

      // TOTAL
      let finalTotal =

        itemPrice +

        (
          isFreeShipping
            ? 0
            : shippingCost
        );

      // DISKON
      finalTotal -=
        this.getDiscountAmount();

      if (finalTotal < 0) {

        finalTotal = 0;

      }

      orders.unshift({

        // ID
        id:
          Date.now() +
          Math.random(),

        // STATUS
        status:
          this.isCodSelected
            ? 'dikemas'
            : 'belum-dibayar',

        // PRODUK
        productName:
          item.name,

        // VARIAN
        variant:
          item.variant ||
          'Default',

        // FOTO
        image:
          item.image,

        // HARGA
        price:
          itemPrice,

        // JUMLAH
        qty:
          item.qty,

        // TOKO
        store:
          item.shop?.name ||
          'Glow Beauty',

        // BERAT
        weight:
          item.weight || 1,

        // ONGKIR
        shipping:
          shippingCost,

        // GRATIS ONGKIR
        freeShipping:
          isFreeShipping,

        // TOTAL
        finalTotal,

        // DISKON
        discount:
          this.getDiscountAmount(),

        // VOUCHER
        voucher:
          this.selectedVoucher?.title ||
          null,

        // ESTIMASI
        estimate:
          '10 Mei 2026',

        // KURIR
        courier:
          'Ninja Xpress',

        // RESI
        receiptNumber:
          'JX' +
          Math.floor(
            Math.random() * 99999999
          ),

        // TANGGAL
        purchaseDate:
          new Date()
            .toLocaleString('id-ID'),

        // ALAMAT
        address:

          this.selectedAddress?.fullAddress ||

          'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373 dekat pohon anggur',

        // PENERIMA
        receiver:

          (
            this.selectedAddress?.name ||
            'Vina'
          ) +

          ' (' +

          (
            this.selectedAddress?.phone ||
            '08735627811'
          ) +

          ')',

        // PAYMENT
        paymentMethod:
          this.isCodSelected
            ? 'COD (Bayar di Tempat)'
            : (
                this.selectedBank ||
                'Transfer Bank'
              )

      });

    });

    localStorage.setItem(
      'orders',
      JSON.stringify(orders)
    );

    // HAPUS CHECKOUT
    localStorage.removeItem(
      'checkoutItems'
    );

    // =========================
    // COD
    // =========================

    if (this.isCodSelected) {

      this.router.navigate([
        '/success-order'
      ]);

      return;

    }

    // =========================
    // BANK / QRIS
    // =========================

    this.router.navigate([
      '/checkout/payment-method'
    ]);

  }

  // KE PAYMENT METHOD
  goToPaymentMethod() {

    this.selectedPayment = 'Transfer Bank';

    this.isCodSelected = false;

    this.router.navigate([
      '/checkout/payment-method'
    ]);

  }

  // ONGKIR NUMBER
  getShippingCostNumber(): number {

    let totalWeight = 0;

    this.checkoutItems.forEach(item => {

      totalWeight +=
        (item.weight || 1) *
        item.qty;

    });

    if (
      this.selectedVoucher &&
      this.selectedVoucher.title.includes(
        'Gratis Ongkir'
      )
    ) {

      return 0;

    }

    return totalWeight <= 5
      ? 10000
      : 20000;

  }

  // ONGKIR FORMAT
  getShippingCost() {

    return 'Rp.' +
      this.getShippingCostNumber()
        .toLocaleString('id-ID');

  }

  // TOTAL HARGA BARANG
  getProductTotal(): number {

    let total = 0;

    this.checkoutItems.forEach(item => {

      const price = Number(
        item.price
          .toString()
          .replace('Rp.', '')
          .replace(/\./g, '')
      );

      total += price * item.qty;

    });

    return total;

  }

  // HARGA BARANG ASLI
getOriginalProductPrice(): string {

  return 'Rp.' +
    this.getProductTotal()
      .toLocaleString('id-ID');

}

  // DISKON
  getDiscountAmount(): number {

    if (!this.selectedVoucher) {

      return 0;

    }

    const title =
      this.selectedVoucher.title;

    // DISKON RP
    if (title.includes('Diskon Rp')) {

      return Number(
        title
          .replace('Diskon Rp', '')
          .replace(/\./g, '')
      );

    }

    // CASHBACK %
    else if (
      title.includes('Cashback')
    ) {

      const percent = Number(
        title
          .replace('Cashback', '')
          .replace('%', '')
      );

      return Math.floor(
        (
          this.getProductTotal() +
          this.getShippingCostNumber()
        ) *
        (percent / 100)
      );

    }

    // GRATIS ONGKIR
    else if (
      title.includes('Gratis Ongkir')
    ) {

      return this.getShippingCostNumber();

    }

    return 0;

  }

  // TOTAL SETELAH DISKON
  getFinalTotal() {

    let finalTotal =

      this.getProductTotal() +

      this.getShippingCostNumber() -

      this.getDiscountAmount();

    if (finalTotal < 0) {

      finalTotal = 0;

    }

    return 'Rp.' +
      finalTotal.toLocaleString('id-ID');

  }

  goBack() {

    this.location.back();

  }

}