import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import {
  Router,
  RouterLink
} from '@angular/router';

import { addIcons } from 'ionicons';

import {
  logoGoogle,
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon,
    RouterLink
  ]
})

export class RegisterPage {

  constructor(
    private router: Router
  ) {

    addIcons({
      logoGoogle,
      arrowBackOutline
    });

  }

  register() {

    console.log('Register berhasil');

  }

}