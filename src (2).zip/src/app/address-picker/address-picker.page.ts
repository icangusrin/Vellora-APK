import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonicModule
} from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  locationOutline,
  ellipseOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-address-picker',
  templateUrl: './address-picker.page.html',
  styleUrls: ['./address-picker.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class AddressPickerPage {

  // STEP
  currentStep = 'province';

  // SEARCH
  searchText = '';

  // SELECTED
  selectedProvince = '';

  selectedCity = '';

  selectedDistrict = '';

  selectedPostal = '';

  // LIST
  displayedList: string[] = [];

  // DATA DUMMY
  provinces = [

    'BALI',
    'BANTEN',
    'DKI JAKARTA',
    'JAWA BARAT',
    'JAWA TENGAH',
    'JAWA TIMUR'

  ];

  cities: any = {

    'JAWA BARAT': [

      'KAB. BANDUNG',
      'KAB. BEKASI',
      'KAB. KARAWANG'

    ]

  };

  districts: any = {

    'KAB. KARAWANG': [

      'BATUJAYA',
      'CIKAMPEK',
      'KLARI'

    ]

  };

  postals: any = {

    'BATUJAYA': [
      '41354',
      '43178'
    ],

    'CIKAMPEK': [
      '41373'
    ],

    'KLARI': [
      '41371'
    ]

  };

  constructor(
    private location: Location
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline,

      'search-outline':
        searchOutline,

      'location-outline':
        locationOutline,

      'ellipse-outline':
        ellipseOutline

    });

    // DEFAULT LIST
    this.displayedList =
      this.provinces;

  }

  // BACK
  goBack() {

    this.location.back();

  }

  // SEARCH
  onSearchChange() {

    const keyword =
      this.searchText.toLowerCase();

    // LIST SAAT INI
    let currentList: string[] = [];

    // PROVINSI
    if (this.currentStep === 'province') {

      currentList =
        this.provinces;

    }

    // KOTA
    else if (this.currentStep === 'city') {

      currentList =
        this.cities[
          this.selectedProvince
        ] || [];

    }

    // KECAMATAN
    else if (this.currentStep === 'district') {

      currentList =
        this.districts[
          this.selectedCity
        ] || [];

    }

    // KODE POS
    else if (this.currentStep === 'postal') {

      currentList =
        this.postals[
          this.selectedDistrict
        ] || [];

    }

    // FILTER
    this.displayedList =
      currentList.filter(item =>

        item.toLowerCase().includes(
          keyword
        )

      );

  }

  // PILIH ITEM
  selectItem(item: string) {

    // RESET SEARCH
    this.searchText = '';

    // PROVINSI
    if (this.currentStep === 'province') {

      this.selectedProvince = item;

      this.currentStep = 'city';

      this.displayedList =
        this.cities[item] || [];

      return;

    }

    // KOTA
    if (this.currentStep === 'city') {

      this.selectedCity = item;

      this.currentStep = 'district';

      this.displayedList =
        this.districts[item] || [];

      return;

    }

    // KECAMATAN
    if (this.currentStep === 'district') {

      this.selectedDistrict = item;

      this.currentStep = 'postal';

      this.displayedList =
        this.postals[item] || [];

      return;

    }

    // KODE POS
    if (this.currentStep === 'postal') {

      this.selectedPostal = item;

      // FORMAT ALAMAT
      const fullAddress =

`${this.selectedProvince}
${this.selectedCity}
${this.selectedDistrict}
${this.selectedPostal}`;

      // SIMPAN SEMENTARA
      localStorage.setItem(
        'selectedAddress',
        fullAddress
      );

      // BALIK KE PAGE SEBELUMNYA
      this.location.back();

      return;

    }

  }

}