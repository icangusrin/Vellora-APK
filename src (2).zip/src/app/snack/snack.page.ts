import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  bagHandleOutline,
  star
} from 'ionicons/icons';

@Component({
  selector: 'app-snack',
  templateUrl: './snack.page.html',
  styleUrls: ['./snack.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class SnackPage {

  // SEARCH
  searchText = '';

  constructor(private router: Router) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      bagHandleOutline,
      star
    });

  }

  // BACK
  goBack() {

    this.router.navigate(['/tabs/home']);

  }

  // DETAIL PRODUCT
  openDetail(product: any) {

    this.router.navigate(['/product-detail'], {
      state: {
        product: {

          name: product.name,

          image: product.image,

          price: product.price,

          sold: product.sold,

          category: product.category,

          variants: product.variants,

          // BERAT
          weight: product.weight,

          // SHOP
          shop: {
            id: 4,
            name: 'Cemilku Store',
            avatar: 'assets/shop/snack.jpg'
          }

        }
      }
    });

  }

  // ADD TO CART
  addToCart(product: any, event: Event) {

    // BIAR TIDAK IKUT KLIK CARD
    event.stopPropagation();

    // AMBIL CART
    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // VARIANT DEFAULT
    const defaultVariant =
      product.variants?.[0] || 'Default';

    // CEK PRODUK SUDAH ADA / BELUM
    const existingProduct = cart.find(
      (item: any) =>

        item.name === product.name &&

        item.variant === defaultVariant
    );

    // JIKA SUDAH ADA
    if (existingProduct) {

      existingProduct.qty++;

    }

    // JIKA BELUM ADA
    else {

      cart.push({

        category: product.category,

        name: product.name,

        variant: defaultVariant,

        variants: product.variants,

        price: product.price,

        qty: 1,

        checked: false,

        storeChecked: false,

        image: product.image,

        // BERAT
        weight: product.weight || 1,

        // SHOP
        shop: {
          id: 4,
          name: 'Cemilku Store',
          avatar: 'assets/shop/snack.jpg'
        }

      });

    }

    // SIMPAN CART
    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  // ALL PRODUCTS
  allProducts = [

    {
      name: 'Keripik Kentang',

      image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=500',

      price: 'Rp.15.000',

      sold: '5RB+ terjual',

      category: 'Snack',

      weight: 1,

      variants: [
        'Balado',
        'BBQ',
        'Jagung Bakar',
        'Keju'
      ]
    },

    {
      name: 'Donat Coklat',

      image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500',

      price: 'Rp.20.000',

      sold: '2RB+ terjual',

      category: 'Snack',

      weight: 1,

      variants: [
        'Coklat',
        'Matcha',
        'Strawberry',
        'Tiramisu'
      ]
    },

    {
      name: 'Burger',

      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500',

      price: 'Rp.25.000',

      sold: '4RB+ terjual',

      category: 'Snack',

      weight: 2,

      variants: [
        'Beef',
        'Chicken',
        'Double Cheese'
      ]
    },

    {
      name: 'Pizza',

      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500',

      price: 'Rp.45.000',

      sold: '1RB+ terjual',

      category: 'Snack',

      weight: 3,

      variants: [
        'Pepperoni',
        'Cheese',
        'BBQ',
        'Sosis'
      ]
    }

  ];

  // PRODUCTS
  products = [...this.allProducts];

  // SEARCH PRODUCT
  searchProduct() {

    const keyword = this.searchText
      .toLowerCase()
      .trim();

    // JIKA INPUT KOSONG
    if (!keyword) {

      this.products = [...this.allProducts];
      return;

    }

    // FILTER PRODUK
    this.products = this.allProducts.filter(product =>
      product.name.toLowerCase().includes(keyword)
    );

  }

}