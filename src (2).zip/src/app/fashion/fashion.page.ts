import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  bagHandleOutline,
  star
} from 'ionicons/icons';

@Component({
  selector: 'app-fashion',
  templateUrl: './fashion.page.html',
  styleUrls: ['./fashion.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class FashionPage {

  /* SEARCH */
  searchText = '';

  constructor(private router: Router) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      bagHandleOutline,
      star
    });

  }

  /* BACK */
  goBack() {

    this.router.navigate(['/tabs/home']);

  }

  /* DETAIL PRODUCT */
  openDetail(product: any) {

    // VARIANT OTOMATIS SESUAI PRODUK
    let variants: string[] = [];

    // SEPATU / SNEAKERS
    if (
      product.name.toLowerCase().includes('sepatu') ||
      product.name.toLowerCase().includes('sneakers')
    ) {

      variants = [
        '39',
        '40',
        '41',
        '42'
      ];

    }

    // SMART WATCH
    else if (
      product.name.toLowerCase().includes('watch')
    ) {

      variants = [
        'Hitam',
        'Pink',
        'Putih',
        'Cream'
      ];

    }

    // JEANS
    else if (
      product.name.toLowerCase().includes('jeans')
    ) {

      variants = [
        '28',
        '30',
        '32',
        '34'
      ];

    }

    // SWEATER
    else if (
      product.name.toLowerCase().includes('sweater')
    ) {

      variants = [
        'M',
        'L',
        'XL'
      ];

    }

    // TAS
    else if (
      product.name.toLowerCase().includes('tas')
    ) {

      variants = [
        'Black',
        'Cream',
        'Pink'
      ];

    }

    // DEFAULT
    else {

      variants = ['Default'];

    }

    // KIRIM KE DETAIL
    this.router.navigate(['/product-detail'], {
      state: {
        product: {

          ...product,

          variants,

          // SHOP
          shop: {
            id: 1,
            name: 'Zoya Fashion',
            avatar: 'assets/shop/fashion.jpg'
          }

        }
      }
    });

  }

  /* ADD TO CART */
  addToCart(product: any, event: Event) {

    // BIAR TIDAK IKUT KLIK CARD
    event.stopPropagation();

    // DEFAULT VARIANT
    let defaultVariant = 'Default';

    // SEPATU / SNEAKERS
    if (
      product.name.toLowerCase().includes('sepatu') ||
      product.name.toLowerCase().includes('sneakers')
    ) {

      defaultVariant = '39';

    }

    // SMART WATCH
    else if (
      product.name.toLowerCase().includes('watch')
    ) {

      defaultVariant = 'Hitam';

    }

    // JEANS
    else if (
      product.name.toLowerCase().includes('jeans')
    ) {

      defaultVariant = '28';

    }

    // SWEATER
    else if (
      product.name.toLowerCase().includes('sweater')
    ) {

      defaultVariant = 'M';

    }

    // TAS
    else if (
      product.name.toLowerCase().includes('tas')
    ) {

      defaultVariant = 'Black';

    }

    // AMBIL CART
    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // ID UNIK
    const itemId =
      product.name + '-' + defaultVariant;

    // CEK PRODUK
    const existingProduct = cart.find(
      (item: any) => item.id === itemId
    );

    // JIKA SUDAH ADA
    if (existingProduct) {

      existingProduct.qty++;

    }

    // JIKA BELUM ADA
    else {

      cart.push({

        id: itemId,

        category: 'Fashion',

        name: product.name,

        variant: defaultVariant,

        price: product.price,

        qty: 1,

        checked: false,

        image: product.image,

        // BERAT
        weight: product.weight || 1,

        // SHOP
        shop: {
          id: 1,
          name: 'Zoya Fashion',
          avatar: 'assets/shop/fashion.jpg'
        }

      });

    }

    // SIMPAN CART
    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  /* ALL PRODUCTS */
  allProducts = [

    {
      name: 'Sepatu Wanita',

      image: 'assets/products/shoe4.jpg',

      price: 'Rp.50.000',

      sold: '1,5RB+ terjual',

      weight: 3
    },

    {
      name: 'Smart Watch',

      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500',

      price: 'Rp.200.000',

      sold: '500 terjual',

      weight: 2
    },

    {
      name: 'Jeans',

      image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500',

      price: 'Rp.150.000',

      sold: '2RB+ terjual',

      weight: 2
    },

    {
      name: 'Sweater',

      image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=500',

      price: 'Rp.120.000',

      sold: '2,7RB+ terjual',

      weight: 2
    },

    {
      name: 'Sneakers',

      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',

      price: 'Rp.300.000',

      sold: '77 terjual',

      weight: 4
    },

    {
      name: 'Tas',

      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500',

      price: 'Rp.700.000',

      sold: '183 terjual',

      weight: 3
    }

  ];

  /* PRODUCTS */
  products = [...this.allProducts];

  /* SEARCH PRODUCT */
  searchProduct() {

    const keyword = this.searchText
      .toLowerCase()
      .trim();

    // JIKA KOSONG
    if (!keyword) {

      this.products = [...this.allProducts];
      return;

    }

    // FILTER PRODUK
    this.products = this.allProducts.filter(product =>
      product.name.toLowerCase().includes(keyword)
    );

  }

}