import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { IonicModule } from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  ticketOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-voucher',
  templateUrl: './voucher.page.html',
  styleUrls: ['./voucher.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class VoucherPage {

  // VOUCHER YANG DIPAKAI
  selectedVoucher: any = null;

vouchers = [

  {
    id: 1,
    title: 'Diskon Rp10.000',
    minimum: 'Min. Belanja Rp30.000',
    expired: 'Hingga 31-05-2026'
  },

  {
    id: 2,
    title: 'Diskon Rp15.000',
    minimum: 'Min. Belanja Rp50.000',
    expired: 'Hingga 31-05-2026'
  },

  {
    id: 3,
    title: 'Diskon Rp20.000',
    minimum: 'Min. Belanja Rp80.000',
    expired: 'Hingga 31-05-2026'
  },

  {
    id: 4,
    title: 'Gratis Ongkir',
    minimum: 'Min. Belanja Rp25.000',
    expired: 'Hingga 31-05-2026'
  },

  {
    id: 5,
    title: 'Cashback 10%',
    minimum: 'Min. Belanja Rp100.000',
    expired: 'Hingga 31-05-2026'
  }

];

  constructor(private location: Location) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'ticket-outline': ticketOutline
    });

  }

  ionViewWillEnter() {

    const voucher = localStorage.getItem(
      'selectedVoucher'
    );

    if (voucher) {

      this.selectedVoucher = JSON.parse(
        voucher
      );

    }

  }

  goBack() {
    this.location.back();
  }

  pakaiVoucher(item: any) {

    localStorage.setItem(
      'selectedVoucher',
      JSON.stringify(item)
    );

    this.selectedVoucher = item;

    this.location.back();

  }

}