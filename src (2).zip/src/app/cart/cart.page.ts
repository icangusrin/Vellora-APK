import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chevronForwardOutline,
  chevronDownOutline,
  ticketOutline,
  closeOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class CartPage {

  // CHECKBOX SEMUA
  selectAll = false;

  // VOUCHER
  selectedVoucher: any = null;

  cartItems: any[] = [];
  groupedCart: any[] = [];

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'chevron-forward-outline': chevronForwardOutline,
      'chevron-down-outline': chevronDownOutline,
      'ticket-outline': ticketOutline,
      'close-outline': closeOutline
    });

  }

  ionViewWillEnter() {

    // AMBIL VOUCHER
    const voucher = localStorage.getItem(
      'selectedVoucher'
    );

    if (voucher) {

      this.selectedVoucher = JSON.parse(
        voucher
      );

    }

    // AMBIL CART
    const savedCart = localStorage.getItem(
      'cart'
    );

    if (savedCart) {

      const parsedCart = JSON.parse(
        savedCart
      );

      // ITEM TERAKHIR JADI PALING ATAS
      this.cartItems = parsedCart
        .reverse()
        .map((item: any) => {

          return {

            id:
              item.id ||
              (
                item.name + '-' +
                (item.variant || 'Default')
              ),

            category:
              item.category || 'Produk',

            name: item.name,

            variant:
              item.variant || 'Default',

            // AMBIL VARIANT
            variants:
              item.variants || ['Default'],

            // HARGA VARIANT
            variantPrices:
              item.variantPrices || {},

            // BERAT VARIANT
            weightByVariant:
              item.weightByVariant || {},

            price: item.price,

            qty: item.qty || 1,

            // BERAT
            weight: item.weight || 1,

            // CHECKBOX
            checked: item.checked || false,

            image: item.image,

            // SHOP
            shop: item.shop || {
              name: 'Toko'
            }

          };

        });

      // GROUP BY TOKO
      this.groupCartItems();

      // UPDATE CHECKBOX
      this.checkIfAllSelected();

    }

    else {

      this.cartItems = [];
      this.groupedCart = [];

    }

  }

  goToVoucher() {

    this.router.navigate([
      '/voucher'
    ]);

  }

  // GO TO CHECKOUT
  goToCheckout() {

    // ITEM YANG DICENTANG
    const selectedItems = this.cartItems.filter(
      item => item.checked
    );

    // JIKA TIDAK ADA ITEM DIPILIH
    if (selectedItems.length === 0) {
      return;
    }

    // SIMPAN ITEM CHECKOUT
    localStorage.setItem(
      'checkoutItems',
      JSON.stringify(selectedItems)
    );

    // SIMPAN TOTAL
    localStorage.setItem(
      'checkoutTotal',
      this.getSelectedTotal()
    );

    // PINDAH PAGE
    this.router.navigate([
      '/checkout'
    ]);

  }

  goBack() {

    this.location.back();

  }

  removeVoucher(event: Event) {

    event.stopPropagation();

    localStorage.removeItem(
      'selectedVoucher'
    );

    this.selectedVoucher = null;

  }

  // GROUP ITEM BERDASARKAN TOKO
  groupCartItems() {

    const grouped: any = {};

    this.cartItems.forEach(item => {

      const shopName =
        item.shop?.name || 'Toko';

      if (!grouped[shopName]) {

        grouped[shopName] = {

          shop: item.shop,

          storeChecked: false,

          items: []

        };

      }

      grouped[shopName].items.push(item);

    });

    this.groupedCart = Object.values(grouped);

  }

  // SIMPAN STATUS CART
  saveCartState() {

    localStorage.setItem(
      'cart',
      JSON.stringify(
        [...this.cartItems].reverse()
      )
    );

  }

  // AMBIL VARIANT
  getVariants(item: any) {

    return item.variants || ['Default'];

  }

  // GANTI VARIANT
  changeVariant(item: any, event: any) {

    const newVariant = event.target.value;

    const newId =
      item.name + '-' + newVariant;

    // CEK DUPLIKAT
    const duplicate = this.cartItems.find(
      cartItem =>

        cartItem !== item &&

        cartItem.id === newId
    );

    // KALAU ADA DUPLIKAT
    if (duplicate) {

      duplicate.qty += item.qty;

      // HAPUS ITEM LAMA
      this.cartItems = this.cartItems.filter(
        cartItem => cartItem !== item
      );

    }

    // KALAU TIDAK ADA
    else {

      item.variant = newVariant;

      item.id = newId;

      // UPDATE HARGA
      if (
        item.variantPrices &&
        item.variantPrices[newVariant]
      ) {

        item.price =
          item.variantPrices[newVariant];

      }

      // UPDATE BERAT
      if (
        item.weightByVariant &&
        item.weightByVariant[newVariant]
      ) {

        item.weight =
          item.weightByVariant[newVariant];

      }

    }

    // UPDATE GROUP
    this.groupCartItems();

    // SIMPAN
    this.saveCartState();

  }

  // CHECK / UNCHECK SEMUA
  toggleSelectAll() {

    this.groupedCart.forEach((group: any) => {

      // CHECK TOKO
      group.storeChecked = this.selectAll;

      // CHECK PRODUK
      group.items.forEach((item: any) => {

        item.checked = this.selectAll;

      });

    });

    // SIMPAN
    this.saveCartState();

  }

  // CHECK TOKO
  toggleStore(group: any) {

    // CHECK PRODUK DALAM TOKO
    group.items.forEach((item: any) => {

      item.checked = group.storeChecked;

    });

    // UPDATE CHECKBOX SEMUA
    this.selectAll = this.groupedCart.every(
      (g: any) => g.storeChecked
    );

    // SIMPAN
    this.saveCartState();

  }

  // CEK APAKAH SEMUA ITEM SUDAH DICENTANG
  checkIfAllSelected() {

    // KALAU CART KOSONG
    if (this.cartItems.length === 0) {

      this.selectAll = false;
      return;

    }

    // UPDATE CHECKBOX TOKO
    this.groupedCart.forEach((group: any) => {

      group.storeChecked = group.items.every(
        (item: any) => item.checked
      );

    });

    // UPDATE CHECKBOX SEMUA
    this.selectAll = this.groupedCart.every(
      (group: any) => group.storeChecked
    );

    // SIMPAN
    this.saveCartState();

  }

  // TAMBAH QTY
  increaseQty(item: any) {

    item.qty++;

    this.saveCartState();

  }

  // KURANG QTY
  decreaseQty(item: any) {

    if (item.qty > 1) {

      item.qty--;

      this.saveCartState();

    }

  }

  // HAPUS ITEM
  removeGroupedItem(item: any) {

    this.cartItems = this.cartItems.filter(
      cartItem =>
        cartItem.id !== item.id
    );

    // UPDATE GROUP
    this.groupCartItems();

    // RESET CHECKBOX
    this.checkIfAllSelected();

    // SIMPAN
    this.saveCartState();

  }

  // TOTAL HARGA
  getSelectedTotal() {

    let total = 0;

    this.cartItems.forEach(item => {

      if (item.checked) {

        const price = Number(
          item.price
            .toString()
            .replace('Rp.', '')
            .replace(/\./g, '')
        );

        total += price * item.qty;

      }

    });

    // VOUCHER
    if (this.selectedVoucher && total > 0) {

      const title = this.selectedVoucher.title;

      // DISKON RP
      if (title.includes('Diskon Rp')) {

        const discount = Number(
          title
            .replace('Diskon Rp', '')
            .replace(/\./g, '')
        );

        total -= discount;

      }

      // CASHBACK %
      else if (title.includes('Cashback')) {

        const percent = Number(
          title
            .replace('Cashback', '')
            .replace('%', '')
        );

        total -= total * (percent / 100);

      }

    }

    // BIAR GA MINUS
    if (total < 0) {

      total = 0;

    }

    return 'Rp.' + Math.floor(total)
      .toLocaleString('id-ID');

  }

  // TOTAL ITEM DICENTANG
  getSelectedCount() {

    return this.cartItems.filter(
      item => item.checked
    ).length;

  }

}