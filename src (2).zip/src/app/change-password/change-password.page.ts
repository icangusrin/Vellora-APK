import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  shieldCheckmarkOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})
export class ChangePasswordPage {

  currentPassword = '';
  newPassword = '';
  confirmPassword = '';

  showSuccessPopup = false;

  constructor(
    private location: Location
  ) {

    addIcons({
      arrowBackOutline,
      shieldCheckmarkOutline
    });

  }

  goBack() {
    this.location.back();
  }

  changePassword() {

    if (
      !this.currentPassword ||
      !this.newPassword ||
      !this.confirmPassword
    ) {
      alert('Semua field wajib diisi');
      return;
    }

    if (this.newPassword !== this.confirmPassword) {
      alert('Konfirmasi password tidak cocok');
      return;
    }

    // tampilkan popup sukses
    this.showSuccessPopup = true;

  }

  finishChangePassword() {

    this.showSuccessPopup = false;

    // kembali ke halaman sebelumnya
    this.location.back();

  }
}