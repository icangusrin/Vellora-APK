import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonContent,
  IonIcon,
  IonToggle
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-privacy-settings',
  templateUrl: './privacy-settings.page.html',
  styleUrls: ['./privacy-settings.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon,
    IonToggle
  ]
})

export class PrivacySettingsPage {

  hideContact = false;

  locationNotification = false;

  constructor(
    private location: Location
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline

    });

  }

  // BACK
  goBack() {

    this.location.back();

  }

}