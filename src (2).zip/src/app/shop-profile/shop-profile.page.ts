import { Component, OnInit } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { ChatService }
from '../service/chat.service';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  ellipsisVerticalOutline,
  chevronForwardOutline,
  chevronDownOutline,
  chevronUpOutline,
  chatbubbleOutline,
  bagHandleOutline,
  personCircleOutline,
  shareSocialOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-shop-profile',
  templateUrl: './shop-profile.page.html',
  styleUrls: ['./shop-profile.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class ShopProfilePage
implements OnInit {

  // SHOP DATA
  shop: any;

  // ACTIVE FILTER
  activeFilter = 'Populer';

  // ACTIVE TAB
  activeTab = 'Produk';

  // ACTIVE REVIEW FILTER
  activeReviewFilter = 'Semua';

  // FOLLOW SHOP
  isFollowing = false;

  // SEARCH
  searchText = '';

  // MENU
  showMenu = false;

  // OUT OF STOCK
  showOutOfStock = false;

  // PRODUCT LIST
  products: any[] = [];

  // PRODUCT HABIS
  outOfStockProducts: any[] = [];

  // REVIEW LIST
  reviews: any[] = [];

  constructor(
    private location: Location,
    private router: Router,
    private chatService: ChatService
  ) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      ellipsisVerticalOutline,
      chevronForwardOutline,
      chevronDownOutline,
      chevronUpOutline,
      chatbubbleOutline,
      bagHandleOutline,
      personCircleOutline,
      shareSocialOutline
    });

  }

  ngOnInit() {

    const nav = history.state;

    // AMBIL DATA TOKO
    if (nav.shop) {

      this.shop = {

        ...nav.shop

      };

    }

    // DEFAULT SHOP
    if (!this.shop) {

      this.shop = {

        name: 'Glow Beauty'

      };

    }

    // FIX AVATAR TOKO

    // GLOW BEAUTY
    if (
      this.shop.name ===
      'Glow Beauty'
    ) {

      this.shop.avatar =
        'assets/shop/skincare.jpg';

    }

    // VOLT ELECTRONICS
    else if (
      this.shop.name ===
      'Volt Electronics'
    ) {

      this.shop.avatar =
        'assets/shop/electronic.jpg';

    }

    // ZOYA FASHION
    else if (
      this.shop.name ===
      'Zoya Fashion'
    ) {

      this.shop.avatar =
        'assets/shop/fashion.jpg';

    }

    // CEMILKU STORE
    else if (
      this.shop.name ===
      'Cemilku Store'
    ) {

      this.shop.avatar =
        'assets/shop/snack.jpg';

    }

    // FOLLOWERS DEFAULT
    if (!this.shop.followers) {

      this.shop.followers =
        '1342';

    }

    // PRODUK BERDASARKAN TOKO
    this.loadProducts();

    // REVIEW BERDASARKAN TOKO
    this.loadReviews();

  }

  // LOAD PRODUCT TOKO
  loadProducts() {

    // BEAUTY
    if (
      this.shop?.name === 'Glow Beauty'
    ) {

      this.products = [

        {
          name: 'Bedak',
          price: 'Rp.55.000',
          image:
            'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9',
          sold: '10RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Lipstik',
          price: 'Rp.45.000',
          image:
            'https://images.unsplash.com/photo-1596462502278-27bfdc403348',
          sold: '8RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Serum Wajah',
          price: 'Rp.75.000',
          image:
            'https://images.unsplash.com/photo-1620916566398-39f1143ab7be',
          sold: '6RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Parfum',
          price: 'Rp.120.000',
          image:
            'https://images.unsplash.com/photo-1541643600914-78b084683601',
          sold: '3RB+ terjual',
          shop: this.shop
        }

      ];

      this.outOfStockProducts = [

        {
          name: 'Cushion Glow',
          price: 'Rp.89.000',
          image:
            'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9'
        },

        {
          name: 'Mascara',
          price: 'Rp.49.000',
          image:
            'https://images.unsplash.com/photo-1596462502278-27bfdc403348'
        }

      ];

    }

    // ELEKTRONIK
    else if (
      this.shop?.name === 'Volt Electronics'
    ) {

      this.products = [

        {
          name: 'Smart Watch',
          price: 'Rp.200.000',
          image:
            'https://images.unsplash.com/photo-1546868871-7041f2a55e12',
          sold: '12RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Laptop',
          price: 'Rp.5.500.000',
          image:
            'https://images.unsplash.com/photo-1496181133206-80ce9b88a853',
          sold: '2RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Keyboard',
          price: 'Rp.250.000',
          image:
            'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae',
          sold: '4RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Headphone',
          price: 'Rp.180.000',
          image:
            'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
          sold: '5RB+ terjual',
          shop: this.shop
        }

      ];

      this.outOfStockProducts = [

        {
          name: 'Gaming Mouse',
          price: 'Rp.175.000',
          image:
            'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46'
        },

        {
          name: 'Speaker Mini',
          price: 'Rp.210.000',
          image:
            'https://images.unsplash.com/photo-1589003077984-894e133dabab'
        }

      ];

    }

    // FASHION
    else if (
      this.shop?.name === 'Zoya Fashion'
    ) {

      this.products = [

        {
          name: 'Sepatu Olah Raga',
          price: 'Rp.100.000',
          image:
            'https://images.unsplash.com/photo-1542291026-7eec264c27ff',
          sold: '10RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Tas Dior',
          price: 'Rp.150.000',
          image:
            'https://images.unsplash.com/photo-1584917865442-de89df76afd3',
          sold: '5RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Baju Wanita',
          price: 'Rp.99.000',
          image:
            'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab',
          sold: '2RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Celana Jeans',
          price: 'Rp.120.000',
          image:
            'https://images.unsplash.com/photo-1541099649105-f69ad21f3246',
          sold: '1RB+ terjual',
          shop: this.shop
        }

      ];

      this.outOfStockProducts = [

        {
          name: 'Jaket Denim',
          price: 'Rp.180.000',
          image:
            'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab'
        },

        {
          name: 'Heels Wanita',
          price: 'Rp.220.000',
          image:
            'https://images.unsplash.com/photo-1543163521-1bf539c55dd2'
        }

      ];

    }

    // SNACK
    else if (
      this.shop?.name === 'Cemilku Store'
    ) {

      this.products = [

        {
          name: 'Keripik',
          price: 'Rp.20.000',
          image:
            'https://images.unsplash.com/photo-1566478989037-eec170784d0b',
          sold: '20RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Donat',
          price: 'Rp.15.000',
          image:
            'https://images.unsplash.com/photo-1509440159596-0249088772ff',
          sold: '10RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Pizza',
          price: 'Rp.80.000',
          image:
            'https://images.unsplash.com/photo-1513104890138-7c749659a591',
          sold: '5RB+ terjual',
          shop: this.shop
        },

        {
          name: 'Burger',
          price: 'Rp.35.000',
          image:
            'https://images.unsplash.com/photo-1568901346375-23c9450c58cd',
          sold: '7RB+ terjual',
          shop: this.shop
        }

      ];

      this.outOfStockProducts = [

        {
          name: 'Cookies',
          price: 'Rp.25.000',
          image:
            'https://images.unsplash.com/photo-1499636136210-6f4ee915583e'
        },

        {
          name: 'Croissant',
          price: 'Rp.30.000',
          image:
            'https://images.unsplash.com/photo-1509440159596-0249088772ff'
        }

      ];

    }

    // DEFAULT
    else {

      this.products = [];
      this.outOfStockProducts = [];

    }

  }

  // LOAD REVIEW TOKO
  loadReviews() {

    // BEAUTY
    if (
      this.shop?.name === 'Glow Beauty'
    ) {

      this.reviews = [

        {
          user: 'use*',
          text:
            'Bedaknya ringan banget dipake sehari-hari 😍 hasilnya natural dan tahan lamaa',
          date: '07-05-2026',
          image:
            'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9'
        },

        {
          user: 'use*',
          text:
            'Lipstiknya cantik banget warnanya, lembap juga di bibir ✨',
          date: '07-05-2026',
          image:
            'https://images.unsplash.com/photo-1596462502278-27bfdc403348'
        }

      ];

    }

    // DEFAULT
    else {

      this.reviews = [];

    }

  }

  goBack() {

    this.location.back();

  }

  // CHANGE FILTER
  changeFilter(filter: string) {

    this.activeFilter = filter;

  }

  // CHANGE TAB
  changeTab(tab: string) {

    this.activeTab = tab;

  }

  // CHANGE REVIEW FILTER
  changeReviewFilter(filter: string) {

    this.activeReviewFilter = filter;

  }

  // FOLLOW SHOP
  toggleFollow() {

    this.isFollowing =
      !this.isFollowing;

  }

  // TOGGLE MENU
  toggleMenu() {

    this.showMenu =
      !this.showMenu;

  }

  // TOGGLE OUT OF STOCK
  toggleOutOfStock() {

    this.showOutOfStock =
      !this.showOutOfStock;

  }

  // HOME
  goHome() {

    this.showMenu = false;

    this.router.navigateByUrl(
      '/tabs/home'
    );

  }

  // SHARE
  shareShop() {

    this.showMenu = false;

    if (navigator.share) {

      navigator.share({

        title:
          this.shop?.name,

        text:
          `Kunjungi toko ${this.shop?.name}`,

        url:
          window.location.href

      });

    }

  }

  // OPEN CHAT
  openChat() {

    const shopChat = {

      id: this.shop?.id || 1,

      name:
        this.shop?.name || 'Shop',

      avatar:
        this.shop?.avatar ||
        'https://i.pravatar.cc/150?img=12',

      message: 'Halo kak 👋',

      time: 'Now',

      unread: 1

    };

    this.chatService.addChat(
      shopChat
    );

    this.router.navigate(
      ['/chat-detail', shopChat.id],
      {
        state: {
          chatData: shopChat
        }
      }
    );

  }

  // FILTER PRODUCT
  get filteredProducts() {

    return this.products.filter(
      product =>
        product.name
          .toLowerCase()
          .includes(
            this.searchText.toLowerCase()
          )
    );

  }

  // REVIEW FOTO
  get photoReviews() {

    return this.reviews.filter(
      review => review.image
    );

  }

  // OPEN PRODUCT DETAIL
  openProduct(product: any) {

    this.router.navigate(
      ['/product-detail'],
      {
        state: {
          product
        }
      }
    );

  }

}