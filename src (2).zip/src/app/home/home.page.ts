import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';

import {
  searchOutline,
  cartOutline,
  ticketOutline,
  shirtOutline,
  sparklesOutline,
  desktopOutline,
  fastFoodOutline,
  bagAddOutline,
  heart,
  heartOutline,
} from 'ionicons/icons';

import { addIcons } from 'ionicons';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,

  imports: [
    IonicModule,
    CommonModule,
    RouterLink
  ],
})

export class HomePage {

  selectedTab = 'recommended';

  constructor(private router: Router) {

    addIcons({
      searchOutline,
      cartOutline,
      ticketOutline,
      shirtOutline,
      sparklesOutline,
      desktopOutline,
      fastFoodOutline,
      bagAddOutline,
      heart,
      heartOutline,
    });

  }

  // GO TO CART
  goToCart() {
    this.router.navigate(['/cart']);
  }

  // GO TO CATEGORY
  goToCategory(category: string) {
    const route = category.toLowerCase();
    this.router.navigate([`/${route}`]);
  }

  // GO TO VOUCHER
  goToVoucher() {
    this.router.navigate(['/voucher']);
  }

  // ===== WISHLIST (pakai localStorage langsung) =====

  // TOGGLE WISHLIST
  toggleWishlist(product: any, event: Event) {

    event.stopPropagation();

    const wishlist = JSON.parse(
      localStorage.getItem('wishlist') || '[]'
    );

    const index = wishlist.findIndex(
      (p: any) => p.id === product.id
    );

    if (index === -1) {
      // BELUM ADA → TAMBAH
      wishlist.unshift(product);
    } else {
      // SUDAH ADA → HAPUS
      wishlist.splice(index, 1);
    }

    localStorage.setItem(
      'wishlist',
      JSON.stringify(wishlist)
    );

  }

  // CEK WISHLIST
  isWishlisted(productId: string): boolean {

    const wishlist = JSON.parse(
      localStorage.getItem('wishlist') || '[]'
    );

    return wishlist.some(
      (p: any) => p.id === productId
    );

  }

  // DETAIL PRODUCT
  openDetail(product: any) {

    let variants: string[] = [];

    const productName = product.name.toLowerCase();

    if (productName.includes('bedak')) {
      variants = ['Ivory', 'Natural', 'Beige', 'Mocha'];
    } else if (productName.includes('watch')) {
      variants = ['Hitam', 'Pink', 'Putih', 'Cream'];
    } else if (productName.includes('snack') || productName.includes('cookies')) {
      variants = ['Balado', 'BBQ', 'Keju', 'Jagung Bakar'];
    } else if (productName.includes('bracelet')) {
      variants = ['Gold', 'Silver', 'Rose Gold'];
    } else if (productName.includes('jeans')) {
      variants = ['28', '30', '32', '34'];
    } else if (productName.includes('kaos')) {
      variants = ['S', 'M', 'L', 'XL'];
    } else if (productName.includes('handphone')) {
      variants = ['128GB', '256GB', '512GB'];
    } else {
      variants = ['Default'];
    }

    this.router.navigate(['/product-detail'], {
      state: {
        product: {
          ...product,
          variants
        }
      }
    });

  }

  // ADD TO CART
  addToCart(product: any, event: Event) {

    event.stopPropagation();

    const productName = product.name.toLowerCase();

    let defaultVariant = 'Default';

    if (productName.includes('bedak')) {
      defaultVariant = 'Ivory';
    } else if (productName.includes('watch')) {
      defaultVariant = 'Hitam';
    } else if (productName.includes('snack') || productName.includes('cookies')) {
      defaultVariant = 'Balado';
    } else if (productName.includes('bracelet')) {
      defaultVariant = 'Gold';
    } else if (productName.includes('jeans')) {
      defaultVariant = '28';
    } else if (productName.includes('kaos')) {
      defaultVariant = 'M';
    } else if (productName.includes('handphone')) {
      defaultVariant = '128GB';
    }

    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    const itemId = product.id;

    const existingProduct = cart.find(
      (item: any) => item.id === itemId
    );

    if (existingProduct) {
      existingProduct.qty++;
    } else {
      cart.push({
        id: itemId,
        category: 'Produk',
        name: product.name,
        variant: defaultVariant,
        price: product.price,
        qty: 1,
        checked: false,
        image: product.image
      });
    }

    localStorage.setItem('cart', JSON.stringify(cart));

  }

  // CATEGORY
  categories = [
    { name: 'Voucher', icon: 'ticket-outline' },
    { name: 'Fashion', icon: 'shirt-outline' },
    { name: 'Beauty', icon: 'sparkles-outline' },
    { name: 'Elektronik', icon: 'desktop-outline' },
    { name: 'Snack', icon: 'fast-food-outline' },
  ];

  // RECOMMENDED — tambah id di setiap produk
  recommendedProducts = [
    {
      id: 'bedak-1',
      name: 'Bedak',
      image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9',
      price: 'Rp.55.000',
      sold: '5RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },
    {
      id: 'smartwatch-1',
      name: 'Smart Watch',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
      price: 'Rp.200.000',
      sold: '500 terjual',
      rating: '⭐⭐⭐⭐☆',
    },
    {
      id: 'snack-1',
      name: 'Snack',
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff',
      price: 'Rp.25.000',
      sold: '2RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },
    {
      id: 'bracelet-1',
      name: 'Bracelet',
      image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638',
      price: 'Rp.75.000',
      sold: '800 terjual',
      rating: '⭐⭐⭐⭐☆',
    },
  ];

  // HOT
  hotProducts = [
    {
      id: 'jeans-1',
      name: 'Jeans',
      image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246',
      price: 'Rp.175.000',
      sold: '2RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },
    {
      id: 'kaos-1',
      name: 'Kaos',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab',
      price: 'Rp.120.000',
      sold: '1RB+ terjual',
      rating: '⭐⭐⭐⭐☆',
    },
  ];

  // TOP
  topProducts = [
    {
      id: 'handphone-1',
      name: 'Handphone',
      image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9',
      price: 'Rp.2.500.000',
      sold: '10RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },
    {
      id: 'cookies-1',
      name: 'Cookies',
      image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e',
      price: 'Rp.35.000',
      sold: '4RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },
  ];

  // PRODUCT LIST
  get products() {
    if (this.selectedTab === 'hot') return this.hotProducts;
    if (this.selectedTab === 'top') return this.topProducts;
    return this.recommendedProducts;
  }

}