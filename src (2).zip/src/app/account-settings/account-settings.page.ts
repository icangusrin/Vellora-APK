import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  IonicModule
} from '@ionic/angular';

import {
  Router,
  RouterLink
} from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chevronForwardOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.page.html',
  styleUrls: ['./account-settings.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    RouterLink
  ]
})

export class AccountSettingsPage {

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline,

      'chevron-forward-outline':
        chevronForwardOutline

    });

  }

  // BACK
goBack() {

  this.router.navigate([
    '/tabs/profile'
  ]);

}

  // GO TO SECURITY
  goToSecurity() {

    this.router.navigate([
      '/security-account'
    ]);

  }

  // GO TO ADDRESS
  goToAddress() {

    this.router.navigate([
      '/my-address'
    ]);

  }

  // GO TO PRIVACY
  goToPrivacySettings() {

    this.router.navigate([
      '/privacy-settings'
    ]);

  }

  // GO TO SWITCH ACCOUNT
  goToSwitchAccount() {

    this.router.navigate([
      '/ganti-akun'
    ]);

  }

}