import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  IonicModule
} from '@ionic/angular';

import {
  FormsModule
} from '@angular/forms';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  personOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.page.html',
  styleUrls: ['./edit-profile.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})

export class EditProfilePage {

  // DATA PROFILE
  userData = {

    name:
      localStorage.getItem('userName') ||
      'User',

    gender:
      localStorage.getItem('userGender') ||
      'Perempuan',

    birthDate:
      localStorage.getItem('userBirthDate') ||
      '2006-08-08',

    phone:
      localStorage.getItem('userPhone') ||
      '08835467325',

    email:
      localStorage.getItem('userEmail') ||
      'layananapp@gmail.com'

  };

  // FOTO PROFILE
  profileImage:
    string | ArrayBuffer | null =
      localStorage.getItem('profileImage');

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline,

      'person-outline':
        personOutline

    });

  }

  // PILIH FOTO
  onSelectImage(event: any) {

    const file =
      event.target.files[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {

      this.profileImage =
        reader.result;

      localStorage.setItem(
        'profileImage',
        String(reader.result)
      );

    };

    reader.readAsDataURL(file);

  }

  // SAVE PROFILE
  saveProfile() {

    // SIMPAN SATUAN
    localStorage.setItem(
      'userName',
      this.userData.name
    );

    localStorage.setItem(
      'userGender',
      this.userData.gender
    );

    localStorage.setItem(
      'userBirthDate',
      this.userData.birthDate
    );

    localStorage.setItem(
      'userPhone',
      this.userData.phone
    );

    localStorage.setItem(
      'userEmail',
      this.userData.email
    );

    // FOTO PROFILE
    if (this.profileImage) {

      localStorage.setItem(
        'profileImage',
        String(this.profileImage)
      );

    }

    // SIMPAN OBJECT PROFILE
    const profileData = {

      name:
        this.userData.name,

      gender:
        this.userData.gender,

      birthDate:
        this.userData.birthDate,

      phone:
        this.userData.phone,

      email:
        this.userData.email,

      image:
        this.profileImage

    };

    localStorage.setItem(
      'userProfile',
      JSON.stringify(profileData)
    );

    // KEMBALI KE PROFILE
    this.router.navigate([
      '/tabs/profile'
    ]);

  }

  // GO BACK
  goBack() {

    this.location.back();

  }

}