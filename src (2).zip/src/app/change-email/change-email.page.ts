import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonicModule
} from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-change-email',
  templateUrl: './change-email.page.html',
  styleUrls: ['./change-email.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class ChangeEmailPage {

  oldEmail = '';

  newEmail = '';

  // POPUP
  showErrorPopup = false;

  errorMessage = '';

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline

    });

  }

  // SAVE EMAIL
  saveEmail() {

    const currentEmail =
      localStorage.getItem(
        'userEmail'
      );

    // VALIDASI EMAIL LAMA
    if (
      this.oldEmail !== currentEmail
    ) {

      this.errorMessage =
        'Email lama tidak sesuai';

      this.showErrorPopup =
        true;

      return;

    }

    // VALIDASI EMAIL BARU
    if (!this.newEmail) {

      this.errorMessage =
        'Email baru wajib diisi';

      this.showErrorPopup =
        true;

      return;

    }

    // SIMPAN SEMENTARA
    localStorage.setItem(
      'newEmail',
      this.newEmail
    );

    // PINDAH KE HALAMAN OTP
    this.router.navigate([
      '/email-otp'
    ]);

  }

  // TUTUP POPUP
  closePopup() {

    this.showErrorPopup =
      false;

  }

  // BACK
  goBack() {

    this.location.back();

  }

}