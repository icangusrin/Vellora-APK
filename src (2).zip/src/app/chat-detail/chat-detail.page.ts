import { Component, OnInit } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import { IonicModule } from '@ionic/angular';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import { FormsModule } from '@angular/forms';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  imageOutline,
  cameraOutline,
  sendOutline
} from 'ionicons/icons';

import {
  Camera,
  CameraResultType,
  CameraSource
} from '@capacitor/camera';

import { ChatService }
from '../service/chat.service';

@Component({
  selector: 'app-chat-detail',
  templateUrl: './chat-detail.page.html',
  styleUrls: ['./chat-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})

export class ChatDetailPage implements OnInit {

  chatId: any;

  chatData: any = {};

  newMessage = '';

  messages: any[] = [];

  // SHOP NAME
  shopName = 'Shop';

  // POPUP DELETE
  selectedMessage:
    number | null = null;

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private chatService: ChatService
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'image-outline': imageOutline,
      'camera-outline': cameraOutline,
      'send-outline': sendOutline
    });

  }

  ngOnInit() {

    this.chatId =
      this.route.snapshot.paramMap.get('id');

    const nav =
      this.router.getCurrentNavigation();

    this.chatData =
      nav?.extras?.state?.['chatData'] || {};

    // SHOP NAME DINAMIS
    this.shopName =
      this.chatData?.name || 'Shop';

    // GET SAVED MESSAGE
    const savedMessages =
      this.chatService.getMessages(
        this.chatId
      );

    if (savedMessages) {

      this.messages =
        JSON.parse(savedMessages);

    }

    else {

      // AUTO CHAT
      this.messages = [

        {
          type: 'question-box',
          sender: 'seller',
          questions: [

            'Apakah produk masih ready?',

            'Ada ukuran lain kak?',

            'Kapan pesanan dikirim?',

            'Apakah bisa COD?',

            'Boleh minta detail produknya?',

            'Apakah warna sesuai foto?'

          ],
          time: '15:09'
        }

      ];

      // SAVE FIRST MESSAGE
      this.chatService.saveMessages(
        this.chatId,
        this.messages
      );

    }

  }

  goBack() {

    this.location.back();

  }

  async pickImage() {

    const image = await Camera.getPhoto({

      quality: 90,

      allowEditing: false,

      resultType: CameraResultType.DataUrl,

      source: CameraSource.Photos

    });

    this.messages.push({

      image: image.dataUrl,

      time: 'Now',

      sender: 'user'

    });

    // SAVE MESSAGE
    this.chatService.saveMessages(
      this.chatId,
      this.messages
    );

    // UPDATE LAST CHAT
    this.chatService.updateLastMessage(
      this.chatId,
      '📷 Foto'
    );

  }

  async openCamera() {

    const image = await Camera.getPhoto({

      quality: 90,

      allowEditing: false,

      resultType: CameraResultType.DataUrl,

      source: CameraSource.Camera

    });

    this.messages.push({

      image: image.dataUrl,

      time: 'Now',

      sender: 'user'

    });

    // SAVE MESSAGE
    this.chatService.saveMessages(
      this.chatId,
      this.messages
    );

    // UPDATE LAST CHAT
    this.chatService.updateLastMessage(
      this.chatId,
      '📷 Foto'
    );

  }

  sendMessage() {

    if (!this.newMessage.trim()) return;

    const messageText =
      this.newMessage;

    this.messages.push({

      text: messageText,

      time: 'Now',

      sender: 'user'

    });

    // SAVE MESSAGE
    this.chatService.saveMessages(
      this.chatId,
      this.messages
    );

    // UPDATE CHAT LIST
    this.chatService.updateLastMessage(
      this.chatId,
      messageText
    );

    this.newMessage = '';

  }

  // QUICK MESSAGE
  sendQuickMessage(text: string) {

    this.messages.push({

      text: text,

      time: 'Now',

      sender: 'user'

    });

    // SAVE MESSAGE
    this.chatService.saveMessages(
      this.chatId,
      this.messages
    );

    // UPDATE CHAT LIST
    this.chatService.updateLastMessage(
      this.chatId,
      text
    );

  }

  // OPEN POPUP
  openDeletePopup(index: number) {

    // HANYA USER CHAT
    if (
      this.messages[index]?.sender
      !== 'user'
    ) {

      return;

    }

    this.selectedMessage = index;

  }

  // CLOSE POPUP
  closePopup() {

    this.selectedMessage = null;

  }

  deleteMessage(index: number) {

  // JANGAN HAPUS AUTO CHAT
  if (
    this.messages[index]?.type
    === 'question-box'
  ) {

    this.selectedMessage = null;

    return;

  }

  // HAPUS PESAN
  this.messages.splice(index, 1);

  // CEK APAKAH MASIH ADA PESAN USER
  const userMessages =
    this.messages.filter(
      item =>
        item.sender === 'user'
    );

  // JIKA TIDAK ADA PESAN USER
  if (userMessages.length === 0) {

    // RESET KE AUTO CHAT
    this.messages = [

      {
        type: 'question-box',
        sender: 'seller',
        questions: [

          'Apakah produk masih ready?',

          'Ada ukuran lain kak?',

          'Kapan pesanan dikirim?',

          'Apakah bisa COD?',

          'Boleh minta detail produknya?',

          'Apakah warna sesuai foto?'

        ],
        time: '15:09'
      }

    ];

    // HAPUS CHAT DARI LIST UTAMA
    this.chatService.deleteChat(
      Number(this.chatId)
    );

  }

  else {

    // AMBIL PESAN USER TERAKHIR
    const lastMessage =
      userMessages[
        userMessages.length - 1
      ];

    let lastText = '';

    // TEXT
    if (lastMessage.text) {

      lastText =
        lastMessage.text;

    }

    // IMAGE
    else if (lastMessage.image) {

      lastText = '📷 Foto';

    }

    // UPDATE LAST CHAT
    this.chatService.updateLastMessage(
      Number(this.chatId),
      lastText
    );

  }

  // SAVE STORAGE
  this.chatService.saveMessages(
    Number(this.chatId),
    this.messages
  );

  this.selectedMessage = null;

}

}