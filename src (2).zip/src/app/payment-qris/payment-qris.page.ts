import {
  Component,
  ElementRef,
  ViewChild
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import { IonicModule } from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-payment-qris',
  templateUrl: './payment-qris.page.html',
  styleUrls: ['./payment-qris.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class PaymentQrisPage {

  @ViewChild('qrImage')
  qrImage!: ElementRef;

  total = 'Rp.0';

  // TIMER
  countdown = '00:01:00';

  expiredAt = 0;

  timer: any;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline
    });

    // AMBIL TOTAL DARI CHECKOUT
    const savedTotal =
      localStorage.getItem(
        'checkoutTotal'
      );

    if (savedTotal) {

      this.total = savedTotal;

    }

  }

  ionViewWillEnter() {

    // TIMER 1 MENIT
    this.expiredAt =
      Date.now() + (1 * 60 * 1000);

    this.startCountdown();

  }

  // COUNTDOWN
  startCountdown() {

    this.timer = setInterval(() => {

      const distance =
        this.expiredAt - Date.now();

      // HABIS
      if (distance <= 0) {

        clearInterval(this.timer);

        this.countdown =
          '00:00:00';

        // POPUP
        alert(
          'Waktu pembayaran QRIS telah habis'
        );

        // KEMBALI KE CHECKOUT
        this.router.navigate([
          '/checkout'
        ]);

        return;

      }

      const minutes = Math.floor(
        (distance / 1000 / 60) % 60
      );

      const seconds = Math.floor(
        (distance / 1000) % 60
      );

      this.countdown =
        `00:${minutes
          .toString()
          .padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`;

    }, 1000);

  }

  // KONFIRMASI PEMBAYARAN QRIS
  confirmQrisPayment() {

    clearInterval(this.timer);

    // AMBIL ORDERS
    const orders = JSON.parse(
      localStorage.getItem('orders') || '[]'
    );

    // UPDATE STATUS ORDER TERBARU KE DIKEMAS
    if (orders.length > 0) {

      orders[0].status = 'dikemas';

    }

    // SIMPAN ORDERS
    localStorage.setItem(
      'orders',
      JSON.stringify(orders)
    );

    // HAPUS CHECKOUT
    localStorage.removeItem('checkoutItems');

    localStorage.removeItem('checkoutTotal');

    // SUCCESS
    this.router.navigate([
      '/success-order'
    ]);

  }

  async saveQr() {

    // CANVAS
    const canvas =
      document.createElement('canvas');

    canvas.width = 500;
    canvas.height = 620;

    const ctx =
      canvas.getContext('2d');

    if (!ctx) return;

    // BACKGROUND
    ctx.fillStyle = '#f3f3f3';

    ctx.fillRect(
      0,
      0,
      500,
      620
    );

    // QR CARD
    ctx.fillStyle = '#ffffff';

    this.roundRect(
      ctx,
      55,
      120,
      390,
      360,
      35
    );

    ctx.fill();

    // BORDER
    ctx.strokeStyle = '#bfbfbf';

    ctx.lineWidth = 4;

    this.roundRect(
      ctx,
      55,
      120,
      390,
      360,
      35
    );

    ctx.stroke();

    // QRIS TEXT
    ctx.fillStyle = '#111';

    ctx.font =
      'bold 42px Arial';

    ctx.textAlign = 'center';

    ctx.fillText(
      'QRIS',
      250,
      70
    );

    // SCAN TEXT
    ctx.fillStyle = '#222';

    ctx.font =
      '28px Arial';

    ctx.fillText(
      'Scan untuk bayar',
      250,
      180
    );

    // QR IMAGE
    const image =
      this.qrImage.nativeElement;

    const response =
      await fetch(image.src);

    const blob =
      await response.blob();

    const bitmap =
      await createImageBitmap(blob);

    ctx.drawImage(
      bitmap,
      145,
      220,
      210,
      210
    );

    // NMID
    ctx.fillStyle = '#555';

    ctx.font =
      '16px Arial';

    ctx.fillText(
      'NMID: ID75765788979',
      250,
      455
    );

    // TOTAL
    ctx.fillStyle = '#222';

    ctx.font =
      'bold 20px Arial';

    ctx.fillText(
      `Total ${this.total}`,
      250,
      520
    );

    // DOWNLOAD
    const link =
      document.createElement('a');

    link.href =
      canvas.toDataURL(
        'image/png'
      );

    link.download =
      'kode-qris.png';

    document.body.appendChild(
      link
    );

    link.click();

    document.body.removeChild(
      link
    );

  }

  roundRect(
    ctx: any,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number
  ) {

    ctx.beginPath();

    ctx.moveTo(
      x + radius,
      y
    );

    ctx.lineTo(
      x + width - radius,
      y
    );

    ctx.quadraticCurveTo(
      x + width,
      y,
      x + width,
      y + radius
    );

    ctx.lineTo(
      x + width,
      y + height - radius
    );

    ctx.quadraticCurveTo(
      x + width,
      y + height,
      x + width - radius,
      y + height
    );

    ctx.lineTo(
      x + radius,
      y + height
    );

    ctx.quadraticCurveTo(
      x,
      y + height,
      x,
      y + height - radius
    );

    ctx.lineTo(
      x,
      y + radius
    );

    ctx.quadraticCurveTo(
      x,
      y,
      x + radius,
      y
    );

    ctx.closePath();

  }

  goBack() {

    clearInterval(this.timer);

    this.location.back();

  }

}