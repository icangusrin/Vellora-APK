import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  receiptOutline,
  qrCodeOutline,
  businessOutline,
  chevronDownOutline,
  chevronUpOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-payment-method',
  templateUrl: './payment-method.page.html',
  styleUrls: ['./payment-method.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})

export class PaymentMethodPage {

  showBank = false;

  selectedBank = '';

  selectedPayment = '';

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'receipt-outline': receiptOutline,
      'qr-code-outline': qrCodeOutline,
      'business-outline': businessOutline,
      'chevron-down-outline': chevronDownOutline,
      'chevron-up-outline': chevronUpOutline
    });

  }

  toggleBank() {

    this.showBank = !this.showBank;

  }

  // PILIH COD
  selectCod() {

    this.selectedPayment = 'COD';

    // RESET BANK
    this.selectedBank = '';

    localStorage.setItem(
      'selectedPayment',
      'COD'
    );

  }

  // PILIH QRIS
  selectQris() {

    this.selectedPayment = 'QRIS';

    // RESET BANK
    this.selectedBank = '';

    localStorage.setItem(
      'selectedPayment',
      'QRIS'
    );

  }

  // PILIH BANK
  selectBank(bank: string) {

    // RESET COD & QRIS
    this.selectedPayment =
      'Transfer Bank';

    this.selectedBank = bank;

    localStorage.setItem(
      'selectedPayment',
      'Transfer Bank'
    );

    localStorage.setItem(
      'selectedBank',
      bank
    );

  }

  confirmPayment() {

    const checkoutItems = JSON.parse(
      localStorage.getItem(
        'checkoutItems'
      ) || '[]'
    );

    const orders = JSON.parse(
      localStorage.getItem(
        'orders'
      ) || '[]'
    );

    // AMBIL ALAMAT
    const selectedAddress =
      JSON.parse(
        localStorage.getItem(
          'selectedCheckoutAddress'
        ) || 'null'
      );

    // AMBIL VOUCHER
    const selectedVoucher =
      JSON.parse(
        localStorage.getItem(
          'selectedVoucher'
        ) || 'null'
      );

    // =========================
    // COD
    // =========================

    if (this.selectedPayment === 'COD') {

      checkoutItems.forEach((item: any) => {

        // ONGKIR
        const shippingCost =

          item.weight > 5
            ? 20000
            : 10000;

        // PRICE
        const itemPrice = Number(
          item.price
            .toString()
            .replace('Rp.', '')
            .replace(/\./g, '')
        );

        // TOTAL
        let finalTotal =
          itemPrice + shippingCost;

        // DISKON
        let discount = 0;

        if (selectedVoucher) {

          // DISKON RP
          if (
            selectedVoucher.title.includes(
              'Diskon Rp'
            )
          ) {

            discount = Number(
              selectedVoucher.title
                .replace(
                  'Diskon Rp',
                  ''
                )
                .replace(/\./g, '')
            );

          }

          // GRATIS ONGKIR
          else if (
            selectedVoucher.title.includes(
              'Gratis Ongkir'
            )
          ) {

            discount = shippingCost;

          }

        }

        finalTotal -= discount;

        if (finalTotal < 0) {

          finalTotal = 0;

        }

        orders.unshift({

          // ID
          id:
            Date.now() +
            Math.random(),

          // STATUS
          status:
            'dikemas',

          // PRODUK
          productName:
            item.name,

          // VARIAN
          variant:
            item.variant ||
            'Default',

          // FOTO
          image:
            item.image,

          // HARGA
          price:
            itemPrice,

          // JUMLAH
          qty:
            item.qty,

          // TOKO
          store:
            item.shop?.name ||
            'Glow Beauty',

          // BERAT
          weight:
            item.weight || 1,

          // ONGKIR
          shipping:
            shippingCost,

          // TOTAL
          finalTotal,

          // DISKON
          discount,

          // VOUCHER
          voucher:
            selectedVoucher?.title ||
            null,

          // ESTIMASI
          estimate:
            '10 Mei 2026',

          // KURIR
          courier:
            'Ninja Xpress',

          // RESI
          receiptNumber:
            'JX' +
            Math.floor(
              Math.random() * 99999999
            ),

          // TANGGAL
          purchaseDate:
            new Date()
              .toLocaleString('id-ID'),

          // ALAMAT
          address:

            selectedAddress?.fullAddress ||

            'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373 dekat pohon anggur',

          // PENERIMA
          receiver:

            (
              selectedAddress?.name ||
              'Vina'
            ) +

            ' (' +

            (
              selectedAddress?.phone ||
              '08735627811'
            ) +

            ')',

          // PAYMENT
          paymentMethod:
            'COD (Bayar di Tempat)'

        });

      });

      localStorage.setItem(
        'orders',
        JSON.stringify(orders)
      );

      localStorage.removeItem(
        'checkoutItems'
      );

      this.router.navigate([
        '/success-order'
      ]);

      return;

    }

    // =========================
    // QRIS
    // =========================

    if (this.selectedPayment === 'QRIS') {

      checkoutItems.forEach((item: any) => {

        // ONGKIR
        const shippingCost =

          item.weight > 5
            ? 20000
            : 10000;

        // PRICE
        const itemPrice = Number(
          item.price
            .toString()
            .replace('Rp.', '')
            .replace(/\./g, '')
        );

        // TOTAL
        let finalTotal =
          itemPrice + shippingCost;

        // DISKON
        let discount = 0;

        if (selectedVoucher) {

          // DISKON RP
          if (
            selectedVoucher.title.includes(
              'Diskon Rp'
            )
          ) {

            discount = Number(
              selectedVoucher.title
                .replace(
                  'Diskon Rp',
                  ''
                )
                .replace(/\./g, '')
            );

          }

          // GRATIS ONGKIR
          else if (
            selectedVoucher.title.includes(
              'Gratis Ongkir'
            )
          ) {

            discount = shippingCost;

          }

        }

        finalTotal -= discount;

        if (finalTotal < 0) {

          finalTotal = 0;

        }

        orders.unshift({

          // ID
          id:
            Date.now() +
            Math.random(),

          // STATUS
          status:
            'belum-dibayar',

          // PRODUK
          productName:
            item.name,

          // VARIAN
          variant:
            item.variant ||
            'Default',

          // FOTO
          image:
            item.image,

          // HARGA
          price:
            itemPrice,

          // JUMLAH
          qty:
            item.qty,

          // TOKO
          store:
            item.shop?.name ||
            'Glow Beauty',

          // BERAT
          weight:
            item.weight || 1,

          // ONGKIR
          shipping:
            shippingCost,

          // TOTAL
          finalTotal,

          // DISKON
          discount,

          // VOUCHER
          voucher:
            selectedVoucher?.title ||
            null,

          // ESTIMASI
          estimate:
            '10 Mei 2026',

          // KURIR
          courier:
            'Ninja Xpress',

          // RESI
          receiptNumber:
            'JX' +
            Math.floor(
              Math.random() * 99999999
            ),

          // TANGGAL
          purchaseDate:
            new Date()
              .toLocaleString('id-ID'),

          // ALAMAT
          address:

            selectedAddress?.fullAddress ||

            'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373 dekat pohon anggur',

          // PENERIMA
          receiver:

            (
              selectedAddress?.name ||
              'Vina'
            ) +

            ' (' +

            (
              selectedAddress?.phone ||
              '08735627811'
            ) +

            ')',

          // PAYMENT
          paymentMethod:
            'QRIS'

        });

      });

      localStorage.setItem(
        'orders',
        JSON.stringify(orders)
      );

      this.router.navigate([
        '/payment-qris'
      ]);

      return;

    }

    // =========================
    // BANK
    // =========================

    if (
      this.selectedPayment ===
      'Transfer Bank'
    ) {

      if (!this.selectedBank) return;

      checkoutItems.forEach((item: any) => {

        // ONGKIR
        const shippingCost =

          item.weight > 5
            ? 20000
            : 10000;

        // PRICE
        const itemPrice = Number(
          item.price
            .toString()
            .replace('Rp.', '')
            .replace(/\./g, '')
        );

        // TOTAL
        let finalTotal =
          itemPrice + shippingCost;

        // DISKON
        let discount = 0;

        if (selectedVoucher) {

          // DISKON RP
          if (
            selectedVoucher.title.includes(
              'Diskon Rp'
            )
          ) {

            discount = Number(
              selectedVoucher.title
                .replace(
                  'Diskon Rp',
                  ''
                )
                .replace(/\./g, '')
            );

          }

          // GRATIS ONGKIR
          else if (
            selectedVoucher.title.includes(
              'Gratis Ongkir'
            )
          ) {

            discount = shippingCost;

          }

        }

        finalTotal -= discount;

        if (finalTotal < 0) {

          finalTotal = 0;

        }

        orders.unshift({

          // ID
          id:
            Date.now() +
            Math.random(),

          // STATUS
          status:
            'belum-dibayar',

          // PRODUK
          productName:
            item.name,

          // VARIAN
          variant:
            item.variant ||
            'Default',

          // FOTO
          image:
            item.image,

          // HARGA
          price:
            itemPrice,

          // JUMLAH
          qty:
            item.qty,

          // TOKO
          store:
            item.shop?.name ||
            'Glow Beauty',

          // BERAT
          weight:
            item.weight || 1,

          // ONGKIR
          shipping:
            shippingCost,

          // TOTAL
          finalTotal,

          // DISKON
          discount,

          // VOUCHER
          voucher:
            selectedVoucher?.title ||
            null,

          // ESTIMASI
          estimate:
            '10 Mei 2026',

          // KURIR
          courier:
            'Ninja Xpress',

          // RESI
          receiptNumber:
            'JX' +
            Math.floor(
              Math.random() * 99999999
            ),

          // TANGGAL
          purchaseDate:
            new Date()
              .toLocaleString('id-ID'),

          // ALAMAT
          address:

            selectedAddress?.fullAddress ||

            'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373 dekat pohon anggur',

          // PENERIMA
          receiver:

            (
              selectedAddress?.name ||
              'Vina'
            ) +

            ' (' +

            (
              selectedAddress?.phone ||
              '08735627811'
            ) +

            ')',

          // PAYMENT
          paymentMethod:
            this.selectedBank

        });

      });

      localStorage.setItem(
        'orders',
        JSON.stringify(orders)
      );

      this.router.navigate([
        '/payment-detail'
      ]);

    }

  }

  goBack() {

    this.location.back();

  }

}