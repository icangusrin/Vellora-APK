import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-pesanan',
  templateUrl: './pesanan.page.html',
  styleUrls: ['./pesanan.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon
  ]
})

export class PesananPage
implements OnInit, OnDestroy {

  selectedStatus = 'semua';

  // DATA PESANAN
  orders: any[] = [];

  // TIMER
  refreshTimer: any;

  constructor(
    private location: Location,
    private route: ActivatedRoute,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline
    });

  }

  ngOnInit() {

    // STATUS TAB
    this.route.queryParams.subscribe(params => {

      if (params['status']) {

        this.selectedStatus =
          params['status'];

      }

    });

    // LOAD DATA
    this.loadOrders();

    // AUTO REFRESH
    this.refreshTimer = setInterval(() => {

      this.checkExpiredOrders();

    }, 1000);

  }

  ngOnDestroy() {

    // CLEAR TIMER
    if (this.refreshTimer) {

      clearInterval(
        this.refreshTimer
      );

    }

  }

  // FORMAT HARGA
  formatPrice(value: any): number {

    // JIKA KOSONG
    if (
      value === null ||
      value === undefined
    ) {

      return 0;

    }

    // JIKA NUMBER
    if (
      typeof value === 'number'
    ) {

      return value;

    }

    // HAPUS FORMAT RP
    const cleanedValue =
      value
        .toString()
        .replace(/Rp/gi, '')
        .replace(/\./g, '')
        .replace(/,/g, '')
        .replace(/\s/g, '');

    return Number(
      cleanedValue
    ) || 0;

  }

  // LOAD ORDERS
  loadOrders() {

    const savedOrders =
      localStorage.getItem(
        'orders'
      );

    if (savedOrders) {

      const parsedOrders =
        JSON.parse(savedOrders);

      this.orders =
        parsedOrders.map(
          (
            order: any,
            index: number
          ) => {

            return {

              ...order,

              // ID
              id:
                order.id ||
                index + 1,

              // NAMA
              name:
                order.name ||
                order.productName ||
                order.title ||
                'Produk',

              // HARGA
              price:
                this.formatPrice(

                  order.price ||

                  order.total ||

                  order.subtotal ||

                  order.amount ||

                  order.productPrice

                ),

              // QTY
              qty:
                order.qty ||
                order.quantity ||
                1,

              // ESTIMASI
              estimate:
                order.estimate ||
                '10 Mei'

            };

          }
        );

      // CHECK EXPIRED
      this.checkExpiredOrders();

    }

  }

  // CHECK EXPIRED
  checkExpiredOrders() {

    let changed = false;

    this.orders.forEach(order => {

      if (

        order.status ===
        'belum-dibayar'

        &&

        order.expiredAt

        &&

        Date.now() >
        order.expiredAt

      ) {

        order.status =
          'dibatalkan';

        changed = true;

      }

    });

    // UPDATE STORAGE
    if (changed) {

      localStorage.setItem(
        'orders',
        JSON.stringify(
          this.orders
        )
      );

    }

  }

  // TIMER
  getRemainingTime(
    expiredAt: number
  ) {

    // BELUM ADA TIMER
    if (!expiredAt) {

      return '00:00';

    }

    const distance =
      expiredAt - Date.now();

    // HABIS
    if (distance <= 0) {

      return '00:00';

    }

    const minutes = Math.floor(
      (
        distance %
        (1000 * 60 * 60)
      ) / (1000 * 60)
    );

    const seconds = Math.floor(
      (
        distance %
        (1000 * 60)
      ) / 1000
    );

    return `${minutes
      .toString()
      .padStart(2, '0')}:${seconds
      .toString()
      .padStart(2, '0')}`;

  }

  // BACK
  goBack() {

    this.location.back();

  }

  // PILIH STATUS
  selectStatus(
    status: string
  ) {

    this.selectedStatus =
      status;

  }

  // DETAIL PESANAN
  openDetail(order: any) {

    this.router.navigate([
      '/rincian-pesanan',
      order.id
    ]);

  }

  // FILTER
  get filteredOrders() {

    // SEMUA
    if (
      this.selectedStatus ===
      'semua'
    ) {

      return this.orders;

    }

    // FILTER STATUS
    return this.orders.filter(
      order =>

        order.status ===
        this.selectedStatus
    );

  }

}