import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import { IonicModule } from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-success-order',
  templateUrl: './success-order.page.html',
  styleUrls: ['./success-order.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class SuccessOrderPage {

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline
    });

  }

  // KE HOME
  goHome() {

    this.router.navigate([
      '/tabs/home'
    ]);

  }

  goBack() {
    this.location.back();
  }

  goToPesanan() {

  this.router.navigate([
    '/pesanan'
  ]);

}

}