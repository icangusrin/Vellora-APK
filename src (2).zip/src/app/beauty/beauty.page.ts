import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  bagHandleOutline,
  star
} from 'ionicons/icons';

@Component({
  selector: 'app-beauty',
  templateUrl: './beauty.page.html',
  styleUrls: ['./beauty.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class BeautyPage {

  /* SEARCH */
  searchText = '';

  constructor(private router: Router) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      bagHandleOutline,
      star
    });

  }

  /* BACK */
  goBack() {

    this.router.navigate(['/tabs/home']);

  }

  /* DETAIL PRODUCT */
  openDetail(product: any) {

    this.router.navigate(['/product-detail'], {
      state: {
        product: {

          name: product.name,

          image: product.image,

          price: product.price,

          sold: product.sold,

          category: product.category,

          variants: product.variants,

          // BERAT
          weight: product.weight,

          // SHOP
          shop: {
            id: 2,
            name: 'Glow Beauty',
            avatar: 'assets/shop/skincare.jpg'
          }

        }
      }
    });

  }

  /* ADD TO CART */
  addToCart(product: any, event: Event) {

    // BIAR TIDAK IKUT KLIK CARD
    event.stopPropagation();

    // AMBIL CART
    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // VARIANT DEFAULT
    const defaultVariant =
      product.variants?.[0] || 'Default';

    // CEK PRODUK SUDAH ADA / BELUM
    const existingProduct = cart.find(
      (item: any) =>

        item.name === product.name &&

        item.variant === defaultVariant
    );

    // JIKA SUDAH ADA
    if (existingProduct) {

      existingProduct.qty++;

    }

    // JIKA BELUM ADA
    else {

      cart.push({

        category: product.category,

        name: product.name,

        variant: defaultVariant,

        variants: product.variants,

        price: product.price,

        qty: 1,

        checked: false,

        storeChecked: false,

        image: product.image,

        // BERAT
        weight: product.weight || 1,

        // SHOP
        shop: {
          id: 2,
          name: 'Glow Beauty',
          avatar: 'assets/shop/skincare.jpg'
        }

      });

    }

    // SIMPAN CART
    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  /* ALL PRODUCTS */
  allProducts = [

    {
      name: 'Lipstik',

      image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=500',

      price: 'Rp.35.000',

      sold: '3RB+ terjual',

      category: 'Beauty',

      weight: 1,

      variants: [
        'Cherry Red',
        'Soft Pink',
        'Mocha',
        'Nude'
      ]
    },

    {
      name: 'Face Wash',

      image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500',

      price: 'Rp.45.000',

      sold: '1RB+ terjual',

      category: 'Beauty',

      weight: 2,

      variants: [
        'Acne Care',
        'Brightening',
        'Sensitive Skin',
        'Oil Control'
      ]
    },

    {
      name: 'Skincare',

      image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500',

      price: 'Rp.120.000',

      sold: '5RB+ terjual',

      category: 'Beauty',

      weight: 3,

      variants: [
        'Glow Set',
        'Acne Set',
        'Hydrating Set',
        'Whitening Set'
      ]
    },

    {
      name: 'Perfume',

      image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=500',

      price: 'Rp.150.000',

      sold: '900+ terjual',

      category: 'Beauty',

      weight: 2,

      variants: [
        'Vanilla',
        'Rose',
        'Ocean Fresh',
        'Sweet Floral'
      ]
    }

  ];

  /* PRODUCTS */
  products = [...this.allProducts];

  /* SEARCH PRODUCT */
  searchProduct() {

    const keyword = this.searchText
      .toLowerCase()
      .trim();

    // JIKA KOSONG
    if (!keyword) {

      this.products = [...this.allProducts];
      return;

    }

    // FILTER PRODUK
    this.products = this.allProducts.filter(product =>
      product.name.toLowerCase().includes(keyword)
    );

  }

}