import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonicModule
} from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chevronForwardOutline,
  personOutline,
  atOutline,
  callOutline,
  mailOutline,
  lockClosedOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-security-account',
  templateUrl: './security-account.page.html',
  styleUrls: ['./security-account.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class SecurityAccountPage {

  userData = {

    name: 'Userqueen',

    phone: '08********',

    email: 'u******@gmail.com',

    gender: '',

    birthDate: ''

  };

  // FOTO PROFILE
  profileImage:
    string | null = null;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline,

      'chevron-forward-outline':
        chevronForwardOutline,

      'person-outline':
        personOutline,

      'at-outline':
        atOutline,

      'call-outline':
        callOutline,

      'mail-outline':
        mailOutline,

      'lock-closed-outline':
        lockClosedOutline

    });

  }

  // LOAD DATA
  ionViewWillEnter() {

    const savedData =
      localStorage.getItem(
        'userProfile'
      );

    const savedImage =
      localStorage.getItem(
        'profileImage'
      );

    // AMBIL DATA PROFILE
    if (savedData) {

      this.userData =
        JSON.parse(savedData);

    } else {

      // DEFAULT DATA
      this.userData = {

        name:
          localStorage.getItem('userName') ||
          'Userqueen',

        phone:
          localStorage.getItem('userPhone') ||
          '08********',

        email:
          localStorage.getItem('userEmail') ||
          'u******@gmail.com',

        gender:
          localStorage.getItem('userGender') ||
          '',

        birthDate:
          localStorage.getItem('userBirthDate') ||
          ''

      };

    }

    // UPDATE DATA TERBARU
    const updatedPhone =
      localStorage.getItem(
        'userPhone'
      );

    const updatedEmail =
      localStorage.getItem(
        'userEmail'
      );

    if (updatedPhone) {

      this.userData.phone =
        updatedPhone;

    }

    if (updatedEmail) {

      this.userData.email =
        updatedEmail;

    }

    // AMBIL FOTO PROFILE
    if (savedImage) {

      this.profileImage =
        savedImage;

    }

  }

  // BACK
  goBack() {

    this.router.navigate([
      '/account-settings'
    ]);

  }

  // GO TO EDIT PROFILE
  goToEditProfile() {

    this.router.navigate([
      '/edit-profile'
    ]);

  }

  // GO TO CHANGE PHONE
  goToChangePhone() {

    this.router.navigate([
      '/change-phone'
    ]);

  }

  // GO TO CHANGE EMAIL
  goToChangeEmail() {

    this.router.navigate([
      '/change-email'
    ]);

  }

  // GO TO CHANGE PASSWORD
  goToChangePassword() {

    this.router.navigate([
      '/change-password'
    ]);

  }

}