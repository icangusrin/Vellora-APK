import { Component, OnInit } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  shareSocialOutline,
  cartOutline,
  chevronForwardOutline,
  chatbubbleOutline,
  closeOutline
} from 'ionicons/icons';

import { ChatService }
from '../service/chat.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.page.html',
  styleUrls: ['./product-detail.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    IonContent,
    IonIcon
  ]
})

export class ProductDetailPage implements OnInit {

  product: any;

  // SHOP DATA
  shop: any;

  // DESKRIPSI PRODUK
  productDescription = '';

  // VARIANT TITLE
  variantTitle = 'Varian';

  // VARIANT TERPILIH
  selectedVariant = 'Default';

  // SHOW / HIDE VARIANT MODAL
  showVariants = false;

  // LIST VARIANT
  variants: string[] = [];

  // CATEGORY PRODUK
  category = 'Produk';

  // STATUS DESKRIPSI
  showFullDescription = false;

  // SHARE PRODUCT
  productName = '';

  constructor(
    private location: Location,
    private router: Router,
    private chatService: ChatService
  ) {

    addIcons({
      arrowBackOutline,
      shareSocialOutline,
      cartOutline,
      chevronForwardOutline,
      chatbubbleOutline,
      closeOutline
    });

  }

  ngOnInit() {

    const nav = history.state;

    if (nav.product) {

      this.product = nav.product;

      // SHOP DARI PRODUCT
      this.shop = this.product.shop;

      // AUTO SHOP JIKA BELUM ADA
      if (!this.shop) {

        const name =
          this.product?.name
            ?.toLowerCase() || '';

        /* BEAUTY */
        if (

          name.includes('bedak') ||
          name.includes('lip') ||
          name.includes('serum') ||
          name.includes('parfum') ||
          name.includes('face wash') ||
          name.includes('sunscreen')

        ) {

          this.shop = {

            id: 2,

            name: 'Glow Beauty',

            avatar:
              'assets/shop/skincare.jpg'

          };

        }

        /* ELEKTRONIK */
        else if (

          name.includes('watch') ||
          name.includes('laptop') ||
          name.includes('tv') ||
          name.includes('keyboard') ||
          name.includes('headphone') ||
          name.includes('handphone')

        ) {

          this.shop = {

            id: 3,

            name: 'Volt Electronics',

            avatar:
              'assets/shop/electronic.jpg'

          };

        }

        /* SNACK */
        else if (

          name.includes('snack') ||
          name.includes('keripik') ||
          name.includes('pizza') ||
          name.includes('burger') ||
          name.includes('cookies') ||
          name.includes('donat')

        ) {

          this.shop = {

            id: 4,

            name: 'Cemilku Store',

            avatar:
              'assets/shop/snack.jpg'

          };

        }

        /* FASHION */
        else {

          this.shop = {

            id: 1,

            name: 'Zoya Fashion',

            avatar:
              'assets/shop/fashion.jpg'

          };

        }

      }

    }

    const productName =
      this.product?.name?.toLowerCase() || '';

    /* =========================
       BEAUTY
    ========================= */

    if (
      productName.includes('bedak') ||
      productName.includes('cushion') ||
      productName.includes('foundation') ||
      productName.includes('skintint')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'Shade';

      this.variants = [
        'Ivory',
        'Natural',
        'Beige',
        'Mocha'
      ];

      this.productDescription =
        'Bedak dengan tekstur halus dan ringan di wajah. Cocok digunakan sehari-hari untuk hasil makeup natural dan tahan lama.';

    }

    else if (
      productName.includes('lipstik') ||
      productName.includes('lip')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'Warna';

      this.variants = [
        'Cherry Red',
        'Pink Rose',
        'Nude Peach',
        'Maroon'
      ];

      this.productDescription =
        'Lipstik dengan warna intens dan tahan lama untuk menunjang penampilan sehari-hari.';

    }

    else if (
      productName.includes('face wash')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '50ml',
        '100ml',
        '150ml'
      ];

      this.productDescription =
        'Face wash lembut yang membantu membersihkan wajah dari minyak dan kotoran.';

    }

    else if (
      productName.includes('serum')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '20ml',
        '30ml',
        '50ml'
      ];

      this.productDescription =
        'Serum wajah dengan kandungan yang membantu menjaga kelembapan dan mencerahkan kulit.';

    }

    else if (
      productName.includes('parfume') ||
      productName.includes('parfum')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '30ml',
        '50ml',
        '100ml'
      ];

      this.productDescription =
        'Parfum dengan aroma elegan dan tahan lama untuk aktivitas harian.';

    }

    else if (
      productName.includes('sunscreen')
    ) {

      this.category = 'Beauty';

      this.variantTitle = 'SPF';

      this.variants = [
        'SPF 30',
        'SPF 40',
        'SPF 50'
      ];

      this.productDescription =
        'Sunscreen ringan yang membantu melindungi kulit dari paparan sinar matahari.';

    }

    /* =========================
       FASHION
    ========================= */

    else if (
      productName.includes('sepatu') ||
      productName.includes('sneakers')
    ) {

      this.category = 'Fashion';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '39',
        '40',
        '41',
        '42'
      ];

      this.productDescription =
        'Sepatu stylish dan nyaman digunakan untuk aktivitas sehari-hari maupun olahraga ringan.';

    }

    else if (
      productName.includes('hoodie') ||
      productName.includes('sweater') ||
      productName.includes('baju') ||
      productName.includes('kaos')
    ) {

      this.category = 'Fashion';

      this.variantTitle = 'Warna & Size';

      this.variants = [
        'Hitam - M',
        'Hitam - L',
        'Putih - M',
        'Putih - L'
      ];

      this.productDescription =
        'Pakaian dengan bahan nyaman dan desain modern untuk menunjang penampilan harian.';

    }

    else if (
      productName.includes('jeans') ||
      productName.includes('celana')
    ) {

      this.category = 'Fashion';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '28',
        '29',
        '30',
        '31',
        '32'
      ];

      this.productDescription =
        'Celana jeans berkualitas dengan bahan nyaman dan model kekinian.';

    }

    else if (
      productName.includes('tas') ||
      productName.includes('bag')
    ) {

      this.category = 'Fashion';

      this.variantTitle = 'Warna';

      this.variants = [
        'Hitam',
        'Cream',
        'Coklat',
        'Pink'
      ];

      this.productDescription =
        'Tas modern dengan kapasitas yang cukup untuk kebutuhan sehari-hari.';

    }

    else if (
      productName.includes('bracelet')
    ) {

      this.category = 'Fashion';

      this.variantTitle = 'Model';

      this.variants = [
        'Gold',
        'Silver',
        'Rose Gold'
      ];

      this.productDescription =
        'Bracelet elegan dengan desain minimalis untuk melengkapi penampilan.';

    }

    /* =========================
       SNACK
    ========================= */

    else if (
      productName.includes('keripik') ||
      productName.includes('snack')
    ) {

      this.category = 'Snack';

      this.variantTitle = 'Rasa';

      this.variants = [
        'Balado',
        'BBQ',
        'Jagung Bakar',
        'Keju'
      ];

      this.productDescription =
        'Snack renyah dengan rasa gurih dan cocok dinikmati kapan saja.';

    }

    /* =========================
       ELEKTRONIK
    ========================= */

    else if (
      productName.includes('watch')
    ) {

      this.category = 'Elektronik';

      this.variantTitle = 'Warna';

      this.variants = [
        'Hitam',
        'Pink',
        'Putih',
        'Cream'
      ];

      this.productDescription =
        'Smart watch modern dengan fitur kesehatan dan notifikasi pintar untuk aktivitas harian.';

    }

    else if (
      productName.includes('tv')
    ) {

      this.category = 'Elektronik';

      this.variantTitle = 'Ukuran';

      this.variants = [
        '32 Inch',
        '43 Inch',
        '55 Inch'
      ];

      this.productDescription =
        'Smart TV modern dengan kualitas gambar jernih dan fitur hiburan digital lengkap.';

    }

    else if (
      productName.includes('laptop')
    ) {

      this.category = 'Elektronik';

      this.variantTitle = 'Spesifikasi';

      this.variants = [
        '8GB / 256GB',
        '8GB / 512GB',
        '16GB / 512GB'
      ];

      this.productDescription =
        'Laptop modern dengan performa cepat untuk bekerja dan hiburan sehari-hari.';

    }

    else {

      this.category = 'Produk';

      this.variantTitle = 'Varian';

      this.variants = [
        'Default'
      ];

      this.productDescription =
        'Produk berkualitas dengan desain menarik dan cocok digunakan sehari-hari.';

    }

    // DEFAULT VARIANT PERTAMA
    this.selectedVariant =
      this.variants[0];

    // AUTO UPDATE HARGA
    if (
      this.product?.variantPrices &&
      this.product.variantPrices[this.selectedVariant]
    ) {

      this.product.price =
        this.product.variantPrices[
          this.selectedVariant
        ];

    }

    // AUTO UPDATE BERAT
    if (
      this.product?.weightByVariant &&
      this.product.weightByVariant[this.selectedVariant]
    ) {

      this.product.weight =
        this.product.weightByVariant[
          this.selectedVariant
        ];

    }

    // SHARE TITLE
    this.productName =
      this.product?.name || 'Produk';

  }

  goBack() {

    this.location.back();

  }

  goToCart() {

    this.router.navigate(['/cart']);

  }

  // GO TO SHOP
  goToShop() {

    this.router.navigate(
      ['/shop-profile'],
      {
        state: {
          shop: this.shop
        }
      }
    );

  }

  // OPEN CHAT
  openChat() {

    const shopChat = {

      id: this.shop?.id || 1,

      name: this.shop?.name || 'Shop',

      avatar:
        this.shop?.avatar ||
        'assets/icon/shop.png',

      message: 'Halo kak 👋',

      time: 'Now',

      unread: 1,

      updatedAt: new Date()

    };

    // TAMBAH CHAT KE LIST
    this.chatService.addChat(
      shopChat
    );

    // PINDAH KE CHAT DETAIL
    this.router.navigate(
      ['/chat-detail', shopChat.id],
      {
        state: {
          chatData: shopChat
        }
      }
    );

  }

  // BUKA / TUTUP MODAL VARIANT
  toggleVariants() {

    this.showVariants =
      !this.showVariants;

  }

  // PILIH VARIANT
  selectVariant(variant: string) {

    this.selectedVariant = variant;

    // UPDATE HARGA
    if (
      this.product?.variantPrices &&
      this.product.variantPrices[variant]
    ) {

      this.product.price =
        this.product.variantPrices[variant];

    }

    // UPDATE BERAT
    if (
      this.product?.weightByVariant &&
      this.product.weightByVariant[variant]
    ) {

      this.product.weight =
        this.product.weightByVariant[variant];

    }

  }

  // ADD TO CART
  addToCart() {

    const productCart = {

      id:
        (this.product.id || this.product.name)
        + '-' +
        this.selectedVariant,

      name: this.product.name,

      price: this.product.price,

      image: this.product.image,

      category: this.category,

      variant: this.selectedVariant,

      variants: this.variants,

      qty: 1,

      // BERAT
      weight:
        this.product.weight || 1,

      // SHOP
      shop: this.shop

    };

    let cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    const index = cart.findIndex(
      (item: any) =>
        item.id === productCart.id
    );

    if (index !== -1) {

      cart[index].qty += 1;

    }

    else {

      cart.push(productCart);

    }

    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

    this.goToCart();

  }

  // BUY NOW
  buyNow() {

    const productCheckout = {

      id:
        (this.product.id || this.product.name)
        + '-' +
        this.selectedVariant,

      name: this.product.name,

      price: this.product.price,

      image: this.product.image,

      category: this.category,

      variant: this.selectedVariant,

      qty: 1,

      checked: true,

      // BERAT
      weight:
        this.product.weight || 1,

      // SHOP
      shop: this.shop

    };

    localStorage.setItem(
      'checkoutItems',
      JSON.stringify([productCheckout])
    );

    localStorage.setItem(
      'checkoutTotal',
      this.product.price.toString()
    );

    this.router.navigate([
      '/checkout'
    ]);

  }

  // TOGGLE DESKRIPSI
  toggleDescription() {

    this.showFullDescription =
      !this.showFullDescription;

  }

  async shareProduct() {

    if (navigator.share) {

      await navigator.share({

        title: this.productName || 'Produk',

        text:
          'Lihat produk ini sekarang!',

        url: window.location.href

      });

    }

    else {

      await navigator.clipboard.writeText(
        window.location.href
      );

      alert(
        'Link produk berhasil disalin'
      );

    }

  }

}