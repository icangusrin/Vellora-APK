import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  trashOutline,
  closeOutline,
  bagHandleOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class SearchPage implements OnInit {

  searchText: string = '';

  // HISTORY
  histories: string[] = [];

  filteredHistories: string[] = [];

  // SUGGESTION
  suggestions: string[] = [];

  // PRODUCT RESULT
  products: any[] = [];

  // DATA SUGGESTION
  allSuggestions = [

    'sepatu wanita',
    'sepatu pria',
    'sepatu olahraga',
    'sepatu sneakers',
    'sepatu boots',
    'sepatu sekolah',

    'baju wanita',
    'baju hoodie',
    'baju aesthetic',

    'tas wanita',
    'tas selempang',

    'skincare glowing',
    'skincare korea',

    'buku belajar coding',
    'buku novel'

  ];

  // DATA PRODUK
  allProducts = [

    // SEPATU
    {
      title: 'Sepatu olahraga',

      price: 'Rp.100.000',

      sold: '102RB terjual',

      image: 'assets/products/shoe1.jpg',

      category: 'Fashion',

      weight: 3,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Hitam - 39',
        'Putih - 40',
        'Cream - 41'
      ]
    },

    {
      title: 'Sepatu pria',

      price: 'Rp.185.000',

      sold: '52RB terjual',

      image: 'assets/products/shoe2.jpg',

      category: 'Fashion',

      weight: 4,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Hitam - 40',
        'Coklat - 41',
        'Cream - 42'
      ]
    },

    {
      title: 'Sepatu hitam formal',

      price: 'Rp.150.000',

      sold: '20RB terjual',

      image: 'assets/products/shoe3.jpg',

      category: 'Fashion',

      weight: 3,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Hitam - 39',
        'Hitam - 40',
        'Hitam - 41'
      ]
    },

    {
      title: 'Sepatu flat shoes',

      price: 'Rp.70.000',

      sold: '2RB terjual',

      image: 'assets/products/shoe4.jpg',

      category: 'Fashion',

      weight: 2,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Cream - 37',
        'Pink - 38',
        'Hitam - 39'
      ]
    },

    {
      title: 'Sepatu wanita',

      price: 'Rp.550.000',

      sold: '10RB terjual',

      image: 'assets/products/shoe5.jpg',

      category: 'Fashion',

      weight: 4,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Putih - 38',
        'Pink - 39',
        'Cream - 40'
      ]
    },

    // BAJU
    {
      title: 'Baju wanita aesthetic',

      price: 'Rp.90.000',

      sold: '12RB terjual',

      image: 'assets/products/baju1.jpg',

      category: 'Fashion',

      weight: 2,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Putih - M',
        'Cream - L',
        'Pink - XL'
      ]
    },

    {
      title: 'Baju hoodie pria',

      price: 'Rp.120.000',

      sold: '44RB terjual',

      image: 'assets/products/baju2.jpg',

      category: 'Fashion',

      weight: 2,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Hitam - M',
        'Hitam - L',
        'Abu - XL'
      ]
    },

    // TAS
    {
      title: 'Tas wanita',

      price: 'Rp.200.000',

      sold: '10RB terjual',

      image: 'assets/products/tas1.jpg',

      category: 'Fashion',

      weight: 3,

      shop: {
        id: 1,
        name: 'Zoya Fashion',
        avatar: 'assets/shop/fashion.jpg'
      },

      variants: [
        'Cream',
        'Pink',
        'Black'
      ]
    },

    // SKINCARE
    {
      title: 'Sunscreen',

      price: 'Rp.80.000',

      sold: '8RB terjual',

      image: 'assets/products/skincare1.jpg',

      category: 'Beauty',

      weight: 1,

      shop: {
        id: 2,
        name: 'Glow Beauty',
        avatar: 'assets/shop/skincare.jpg'
      },

      variants: [
        'Ivory',
        'Natural',
        'Beige'
      ]
    },

    // BUKU
    {
      title: 'Buku belajar',

      price: 'Rp.75.000',

      sold: '5RB terjual',

      image: 'assets/products/buku1.jpg',

      category: 'Buku',

      weight: 2,

      shop: {
        id: 5,
        name: 'Book Store',
        avatar: 'assets/shop/book.jpg'
      },

      variants: [
        'Soft Cover',
        'Hard Cover'
      ]
    }

  ];

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      trashOutline,
      closeOutline,
      bagHandleOutline
    });

  }

  // LOAD HISTORY
  ngOnInit() {

    const savedHistory = localStorage.getItem(
      'searchHistory'
    );

    if (savedHistory) {

      this.histories = JSON.parse(savedHistory);

    } else {

      this.histories = [
        'Tas LV',
        'Blush on Hermes',
        'Lips Dior 1'
      ];

    }

    this.filteredHistories = [...this.histories];

  }

  // BACK
  goBack() {

    if (this.products.length > 0) {

      this.products = [];
      this.searchText = '';

      return;

    }

    if (this.suggestions.length > 0) {

      this.suggestions = [];
      this.searchText = '';

      return;

    }

    this.location.back();

  }

  // DETAIL PRODUCT
  openDetail(product: any) {

    this.router.navigate(['/product-detail'], {
      state: {
        product: {

          name: product.title,

          image: product.image,

          price: product.price,

          sold: product.sold,

          category: product.category,

          variants: product.variants,

          weight: product.weight,

          shop: product.shop

        }
      }
    });

  }

  // ADD TO CART
  addToCart(product: any, event: Event) {

    event.stopPropagation();

    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    const existingProduct = cart.find(
      (item: any) =>

        item.name === product.title &&

        item.variant === product.variants[0]
    );

    if (existingProduct) {

      existingProduct.qty++;

    } else {

      cart.push({

        category: product.category,

        name: product.title,

        variant: product.variants[0],

        variants: product.variants,

        price: product.price,

        qty: 1,

        checked: false,

        storeChecked: false,

        image: product.image,

        // BERAT
        weight: product.weight || 1,

        // SHOP
        shop: product.shop

      });

    }

    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  // SAAT MENGETIK
  onTyping() {

    if (this.searchText.trim() === '') {

      this.products = [];
      this.suggestions = [];

      this.filteredHistories = [...this.histories];

      return;

    }

    if (this.searchText.length < 3) {

      this.products = [];
      this.suggestions = [];

      return;

    }

    this.products = [];

    this.suggestions = this.allSuggestions.filter(item =>
      item.toLowerCase().includes(
        this.searchText.toLowerCase()
      )
    );

  }

  // SEARCH PAS ENTER
  searchProduct() {

    if (this.searchText.trim() === '') {

      this.products = [];
      return;

    }

    if (!this.histories.includes(this.searchText)) {

      this.histories.unshift(this.searchText);

    }

    localStorage.setItem(
      'searchHistory',
      JSON.stringify(this.histories)
    );

    this.filteredHistories = [...this.histories];

    this.suggestions = [];

    this.products = this.allProducts.filter(product =>
      product.title.toLowerCase().includes(
        this.searchText.toLowerCase()
      )
    );

  }

  // KLIK HISTORY
  openHistorySearch(item: string) {

    this.searchText = item;

    this.suggestions = [];

    this.products = this.allProducts.filter(product =>
      product.title.toLowerCase().includes(
        item.toLowerCase()
      )
    );

  }

  // HAPUS HISTORY
  removeItem(index: number) {

    const item = this.filteredHistories[index];

    this.histories = this.histories.filter(
      h => h !== item
    );

    this.filteredHistories = [...this.histories];

    localStorage.setItem(
      'searchHistory',
      JSON.stringify(this.histories)
    );

  }

  // HAPUS SEMUA
  clearAll() {

    this.histories = [];
    this.filteredHistories = [];

    localStorage.removeItem('searchHistory');

  }

}