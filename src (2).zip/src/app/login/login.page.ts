import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import {
  Router,
  RouterLink
} from '@angular/router';

import { addIcons } from 'ionicons';

import {
  logoGoogle,
  bagHandle,
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon,
    RouterLink
  ]
})

export class LoginPage {

  constructor(
    private router: Router
  ) {

    addIcons({
      logoGoogle,
      bagHandle,
      arrowBackOutline
    });

  }

  login() {

    console.log('Login berhasil');

  }

}