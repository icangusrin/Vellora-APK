import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  IonicModule,
} from '@ionic/angular';

import { Router } from '@angular/router';

import {
  FormsModule
} from '@angular/forms';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  storefrontOutline,
  chevronForwardOutline,
  chatbubbleOutline
} from 'ionicons/icons';

import {
  ChatService
} from '../service/chat.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})

export class ChatPage
implements OnInit{

  chats: any[] = [];

  filteredChats: any[] = [];

  searchText = '';

  constructor(
    private location: Location,
    private router: Router,
    private chatService: ChatService
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'search-outline': searchOutline,
      'storefront-outline': storefrontOutline,
      'chevron-forward-outline': chevronForwardOutline,
      'chatbubble-outline': chatbubbleOutline
    });

  }

  ngOnInit() {

    this.loadChats();

  }

  // REFRESH SAAT MASUK HALAMAN
  ionViewWillEnter() {

    this.loadChats();

  }

  loadChats() {

    // AMBIL CHAT DARI SERVICE
    this.chats = [
      ...this.chatService.getChats()
    ];

    // HAPUS DUPLIKAT BERDASARKAN ID TOKO
    this.chats = this.chats.filter(
      (chat, index, self) =>

        index === self.findIndex(
          item => item.id === chat.id
        )

    );

    // HAPUS CHAT KOSONG
    this.chats = this.chats.filter(

      chat =>

        chat.message &&
        chat.message !== 'Halo kak 👋'

    );

    // URUTKAN CHAT TERBARU
    this.chats.sort((a, b) => {

      const timeA =
        new Date(
          a.updatedAt || 0
        ).getTime();

      const timeB =
        new Date(
          b.updatedAt || 0
        ).getTime();

      return timeB - timeA;

    });

    // SIMPAN KE FILTER
    this.filteredChats = [
      ...this.chats
    ];

  }

  // SEARCH CHAT
  searchChat() {

    const keyword =
      this.searchText
        .trim()
        .toLowerCase();

    // JIKA BELUM SEARCH
    if (keyword === '') {

      this.filteredChats = [
        ...this.chats
      ];

      return;

    }

    // FILTER CHAT
    this.filteredChats =
      this.chats.filter(chat => {

        const name =
          (chat.name || '')
            .toLowerCase();

        const message =
          (chat.message || '')
            .toLowerCase();

        return (

          name.includes(keyword)

          ||

          message.includes(keyword)

        );

      });

  }

  goBack() {

    this.location.back();

  }

  openChat(chat: any) {

    // HILANGKAN UNREAD
    chat.unread = 0;

    // UPDATE LOCAL CHAT
    const chats =
      this.chatService.getChats();

    const updatedChats =
      chats.map((item: any) => {

        if (item.id === chat.id) {

          return {
            ...item,
            unread: 0
          };

        }

        return item;

      });

    // SAVE STORAGE
    localStorage.setItem(
      'chats',
      JSON.stringify(updatedChats)
    );

    // UPDATE DATA LOKAL
    this.chats = updatedChats;

    this.filteredChats = [
      ...updatedChats
    ];

    // PINDAH KE CHAT DETAIL
    this.router.navigate(
      ['/chat-detail', chat.id],
      {
        state: {
          chatData: chat
        }
      }
    );

  }

}