import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  FormsModule
} from '@angular/forms';

import {
  IonicModule
} from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-change-phone',
  templateUrl: './change-phone.page.html',
  styleUrls: ['./change-phone.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})

export class ChangePhonePage {

  oldPhone = '';

  newPhone = '';

  // POPUP
  showErrorPopup = false;

  errorMessage = '';

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({

      'arrow-back-outline':
        arrowBackOutline

    });

  }

  // LANJUT KE VERIFIKASI
  savePhone() {

    const currentPhone =
      localStorage.getItem(
        'userPhone'
      );

    // VALIDASI NOMOR LAMA
    if (
      this.oldPhone !== currentPhone
    ) {

      this.errorMessage =
        'Nomor lama tidak sesuai';

      this.showErrorPopup =
        true;

      return;

    }

    // VALIDASI NOMOR BARU
    if (!this.newPhone) {

      this.errorMessage =
        'Nomor handphone baru wajib diisi';

      this.showErrorPopup =
        true;

      return;

    }

    // SIMPAN SEMENTARA
    localStorage.setItem(
      'newPhone',
      this.newPhone
    );

    // PINDAH KE HALAMAN VERIFIKASI
    this.router.navigate([
      '/phone-verification'
    ]);

  }

  // TUTUP POPUP
  closePopup() {

    this.showErrorPopup =
      false;

  }

  // BACK
  goBack() {

    this.location.back();

  }

}