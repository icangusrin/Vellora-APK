import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  settingsOutline,
  cartOutline,
  chatbubbleOutline,
  person,
  cardOutline,
  cubeOutline,
  carOutline,
  checkmarkDoneOutline,
  starOutline,
  heartOutline,
  heartDislikeOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule
  ],
})

export class ProfilePage {

  isLoggedIn = true;

  userData = {
    name: 'User',
    email: 'Belum ada email',
    photo: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
  };

  // WISHLIST PREVIEW (maks 4 item)
  wishlistItems: any[] = [];

  constructor(private router: Router) {

    addIcons({
      'settings-outline': settingsOutline,
      'cart-outline': cartOutline,
      'chatbubble-outline': chatbubbleOutline,
      'person': person,
      'card-outline': cardOutline,
      'cube-outline': cubeOutline,
      'car-outline': carOutline,
      'checkmark-done-outline': checkmarkDoneOutline,
      'star-outline': starOutline,
      'heart-outline': heartOutline,
      'heart-dislike-outline': heartDislikeOutline
    });

  }

  ionViewWillEnter() {

    // LOAD PROFILE
    const savedProfile = localStorage.getItem('userProfile');
    const savedImage = localStorage.getItem('profileImage');

    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      this.userData = {
        name: profile.name || 'User',
        email: profile.email || 'Belum ada email',
        photo: profile.image || savedImage ||
          'https://cdn-icons-png.flaticon.com/512/149/149071.png'
      };
    } else {
      this.userData = {
        name: localStorage.getItem('userName') || 'User',
        email: localStorage.getItem('userEmail') || 'Belum ada email',
        photo: localStorage.getItem('profileImage') ||
          'https://cdn-icons-png.flaticon.com/512/149/149071.png'
      };
    }

    // LOAD WISHLIST — tampil maks 4
    const wishlist = JSON.parse(
      localStorage.getItem('wishlist') || '[]'
    );
    this.wishlistItems = wishlist.slice(0, 4);

  }

  goToCart() {
    this.router.navigate(['/cart']);
  }

  goToChat() {
    this.router.navigate(['/tabs/chat']);
  }

  goToSettings() {
    this.router.navigate(['/account-settings']);
  }

  goToEditProfile() {
    this.router.navigate(['/edit-profile']);
  }

  goToPesanan(status: string = 'semua') {
    this.router.navigate(['/pesanan'], { queryParams: { status } });
  }

  goToWishlist() {
    this.router.navigate(['/wishlist']);
  }

}