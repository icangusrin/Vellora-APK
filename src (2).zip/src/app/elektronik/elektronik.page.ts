import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  IonContent,
  IonIcon
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  searchOutline,
  bagHandleOutline,
  star
} from 'ionicons/icons';

@Component({
  selector: 'app-elektronik',
  templateUrl: './elektronik.page.html',
  styleUrls: ['./elektronik.page.scss'],
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon
  ]
})

export class ElektronikPage {

  // SEARCH
  searchText = '';

  constructor(private router: Router) {

    addIcons({
      arrowBackOutline,
      searchOutline,
      bagHandleOutline,
      star
    });

  }

  // BACK
  goBack() {

    this.router.navigate(['/tabs/home']);

  }

  // DETAIL PRODUCT
  openDetail(product: any) {

    // VARIANT
    let variants: string[] = [];

    // HARGA PER VARIANT
    let variantPrices: any = {};

    // BERAT PER VARIANT
    let weightByVariant: any = {};

    // SMART WATCH
    if (
      product.name.toLowerCase().includes('watch')
    ) {

      variants = [
        'Hitam',
        'Pink',
        'Putih',
        'Cream'
      ];

      variantPrices = {
        'Hitam': 'Rp.200.000',
        'Pink': 'Rp.210.000',
        'Putih': 'Rp.205.000',
        'Cream': 'Rp.215.000'
      };

      weightByVariant = {
        'Hitam': 1,
        'Pink': 1,
        'Putih': 1,
        'Cream': 1
      };

    }

    // LAPTOP
    else if (
      product.name.toLowerCase().includes('laptop')
    ) {

      variants = [
        '8GB / 256GB',
        '8GB / 512GB',
        '16GB / 512GB'
      ];

      variantPrices = {
        '8GB / 256GB': 'Rp.7.000.000',
        '8GB / 512GB': 'Rp.8.000.000',
        '16GB / 512GB': 'Rp.9.500.000'
      };

      weightByVariant = {
        '8GB / 256GB': 3,
        '8GB / 512GB': 3,
        '16GB / 512GB': 4
      };

    }

    // SMART TV
    else if (
      product.name.toLowerCase().includes('tv')
    ) {

      variants = [
        '32 Inch',
        '43 Inch',
        '55 Inch'
      ];

      variantPrices = {
        '32 Inch': 'Rp.3.500.000',
        '43 Inch': 'Rp.5.000.000',
        '55 Inch': 'Rp.7.500.000'
      };

      weightByVariant = {
        '32 Inch': 4,
        '43 Inch': 7,
        '55 Inch': 10
      };

    }

    // KEYBOARD
    else if (
      product.name.toLowerCase().includes('keyboard')
    ) {

      variants = [
        'White',
        'Black',
        'RGB'
      ];

      variantPrices = {
        'White': 'Rp.350.000',
        'Black': 'Rp.360.000',
        'RGB': 'Rp.400.000'
      };

      weightByVariant = {
        'White': 1,
        'Black': 1,
        'RGB': 1
      };

    }

    // HEADPHONE
    else if (
      product.name.toLowerCase().includes('headphone')
    ) {

      variants = [
        'Black',
        'White',
        'Blue'
      ];

      variantPrices = {
        'Black': 'Rp.500.000',
        'White': 'Rp.520.000',
        'Blue': 'Rp.530.000'
      };

      weightByVariant = {
        'Black': 1,
        'White': 1,
        'Blue': 1
      };

    }

    // DEFAULT
    else {

      variants = ['Default'];

      variantPrices = {
        'Default': product.price
      };

      weightByVariant = {
        'Default': product.weight || 1
      };

    }

    // KIRIM KE DETAIL
    this.router.navigate(['/product-detail'], {
      state: {
        product: {
          ...product,

          variants,

          variantPrices,

          weightByVariant,

          price:
            variantPrices[variants[0]],

          weight:
            weightByVariant[variants[0]],

          // SHOP
          shop: {
            id: 3,
            name: 'Volt Electronics',
            avatar: 'assets/shop/electronic.jpg'
          }

        }
      }
    });

  }

  // ADD TO CART
  addToCart(product: any, event: Event) {

    // BIAR TIDAK IKUT KLIK CARD
    event.stopPropagation();

    // VARIANT DEFAULT
    let defaultVariant = 'Default';

    // HARGA DEFAULT
    let price = product.price;

    // BERAT DEFAULT
    let weight = product.weight || 1;

    // SMART WATCH
    if (
      product.name.toLowerCase().includes('watch')
    ) {

      defaultVariant = 'Hitam';

      price = 'Rp.200.000';

      weight = 1;

    }

    // LAPTOP
    else if (
      product.name.toLowerCase().includes('laptop')
    ) {

      defaultVariant = '8GB / 256GB';

      price = 'Rp.7.000.000';

      weight = 3;

    }

    // SMART TV
    else if (
      product.name.toLowerCase().includes('tv')
    ) {

      defaultVariant = '32 Inch';

      price = 'Rp.3.500.000';

      weight = 4;

    }

    // KEYBOARD
    else if (
      product.name.toLowerCase().includes('keyboard')
    ) {

      defaultVariant = 'White';

      price = 'Rp.350.000';

      weight = 1;

    }

    // HEADPHONE
    else if (
      product.name.toLowerCase().includes('headphone')
    ) {

      defaultVariant = 'Black';

      price = 'Rp.500.000';

      weight = 1;

    }

    // AMBIL CART
    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // ID UNIK
    const itemId =
      product.name + '-' + defaultVariant;

    // CEK PRODUK
    const existingProduct = cart.find(
      (item: any) => item.id === itemId
    );

    // JIKA SUDAH ADA
    if (existingProduct) {

      existingProduct.qty++;

    }

    // JIKA BELUM ADA
    else {

      cart.push({

        id: itemId,

        category: 'Elektronik',

        name: product.name,

        variant: defaultVariant,

        variants:
          product.name.toLowerCase().includes('tv')
            ? [
                '32 Inch',
                '43 Inch',
                '55 Inch'
              ]
            : product.name.toLowerCase().includes('laptop')
            ? [
                '8GB / 256GB',
                '8GB / 512GB',
                '16GB / 512GB'
              ]
            : product.name.toLowerCase().includes('watch')
            ? [
                'Hitam',
                'Pink',
                'Putih',
                'Cream'
              ]
            : ['Default'],

        price,

        qty: 1,

        checked: false,

        image: product.image,

        // BERAT
        weight,

        // HARGA PER VARIANT
        variantPrices:
          product.name.toLowerCase().includes('tv')
            ? {
                '32 Inch': 'Rp.3.500.000',
                '43 Inch': 'Rp.5.000.000',
                '55 Inch': 'Rp.7.500.000'
              }
            : {},

        // BERAT PER VARIANT
        weightByVariant:
          product.name.toLowerCase().includes('tv')
            ? {
                '32 Inch': 4,
                '43 Inch': 7,
                '55 Inch': 10
              }
            : {},

        // SHOP
        shop: {
          id: 3,
          name: 'Volt Electronics',
          avatar: 'assets/shop/electronic.jpg'
        }

      });

    }

    // SIMPAN CART
    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  // ALL PRODUCTS
  allProducts = [

    {
      name: 'Laptop',

      image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500',

      price: 'Rp.7.000.000',

      sold: '1RB+ terjual',

      weight: 6
    },

    {
      name: 'Smart TV',

      image: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=500',

      price: 'Rp.3.500.000',

      sold: '500+ terjual',

      weight: 8
    },

    {
      name: 'Keyboard',

      image: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=500',

      price: 'Rp.350.000',

      sold: '2RB+ terjual',

      weight: 2
    },

    {
      name: 'Headphone',

      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500',

      price: 'Rp.500.000',

      sold: '800+ terjual',

      weight: 3
    }

  ];

  // PRODUCTS
  products = [...this.allProducts];

  // SEARCH PRODUCT
  searchProduct() {

    const keyword = this.searchText
      .toLowerCase()
      .trim();

    // JIKA INPUT KOSONG
    if (!keyword) {

      this.products = [...this.allProducts];
      return;

    }

    // FILTER PRODUK
    this.products = this.allProducts.filter(product =>
      product.name.toLowerCase().includes(keyword)
    );

  }

}