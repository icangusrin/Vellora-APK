import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ElektronikPage } from './elektronik.page';

describe('ElektronikPage', () => {
  let component: ElektronikPage;
  let fixture: ComponentFixture<ElektronikPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ElektronikPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
