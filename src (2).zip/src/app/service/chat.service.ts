import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ChatService {

  chats: any[] = [];

  constructor() {

    // JANGAN CLEAR STORAGE
    // localStorage.clear();

    // AMBIL CHAT DARI STORAGE
    const savedChats =
      localStorage.getItem('chats');

    if (savedChats) {

      this.chats =
        JSON.parse(savedChats);

    }

    else {

      this.chats = [];

    }

  }

  // GET CHAT
  getChats() {

    return this.chats;

  }

  // ADD CHAT
  addChat(chat: any) {

    const exist =
      this.chats.find(

        item => item.id === chat.id

      );

    // JIKA CHAT SUDAH ADA
    if (exist) {

      exist.message =
        chat.message || exist.message;

      exist.time =
        chat.time || 'Now';

      exist.unread =
        chat.unread ?? exist.unread;

      exist.avatar =
        chat.avatar || exist.avatar;

      exist.name =
        chat.name || exist.name;

      exist.updatedAt =
        new Date();

    }

    // CHAT BARU
    else {

      this.chats.unshift({

        ...chat,

        updatedAt: new Date()

      });

    }

    // SORT CHAT TERBARU
    this.chats.sort((a, b) => {

      return (
        new Date(b.updatedAt).getTime()
        -
        new Date(a.updatedAt).getTime()
      );

    });

    // SAVE STORAGE
    localStorage.setItem(
      'chats',
      JSON.stringify(this.chats)
    );

  }

  // UPDATE LAST MESSAGE
  updateLastMessage(
    chatId: number,
    message: string
  ) {

    const chat =
      this.chats.find(

        item => item.id == chatId

      );

    if (chat) {

      chat.message = message;

      chat.time = 'Now';

      chat.updatedAt =
        new Date();

      // SORT ULANG
      this.chats.sort((a, b) => {

        return (
          new Date(b.updatedAt).getTime()
          -
          new Date(a.updatedAt).getTime()
        );

      });

      // SAVE STORAGE
      localStorage.setItem(
        'chats',
        JSON.stringify(this.chats)
      );

    }

  }

  // GET MESSAGE
  getMessages(chatId: number) {

    return localStorage.getItem(

      'messages_' + chatId

    );

  }

  // SAVE MESSAGE
  saveMessages(
    chatId: number,
    messages: any[]
  ) {

    localStorage.setItem(

      'messages_' + chatId,

      JSON.stringify(messages)

    );

  }

  // DELETE CHAT
  deleteChat(chatId: number) {

    this.chats =
      this.chats.filter(

        item => item.id !== chatId

      );

    // HAPUS STORAGE CHAT
    localStorage.removeItem(
      'messages_' + chatId
    );

    // UPDATE STORAGE
    localStorage.setItem(
      'chats',
      JSON.stringify(this.chats)
    );

  }

}