import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

import {Router} from '@angular/router';

import { addIcons } from 'ionicons';

import {
  cartOutline,
  trashOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-notifikasi',
  templateUrl: './notifikasi.page.html',
  styleUrls: ['./notifikasi.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
  ],
})

export class NotifikasiPage {

  showPopup = false;

  constructor(
    private router: Router
  ) {

    addIcons({
      'cart-outline': cartOutline,
      'trash-outline': trashOutline
    });

  }

  goToCart() {

    this.router.navigate([
      '/cart'
  ]);

  }

}