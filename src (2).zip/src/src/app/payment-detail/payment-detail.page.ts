import { Component } from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  IonicModule
} from '@ionic/angular';

import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  copyOutline,
  checkmarkCircleOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-payment-detail',
  templateUrl: './payment-detail.page.html',
  styleUrls: ['./payment-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule
  ]
})

export class PaymentDetailPage {

  selectedBank = '';

  virtualAccount =
    '7209054362332';

  bankLogo = '';

  total = 'Rp.0';

  // COUNTDOWN
  countdown = '00:01:00';

  expiredAt = 0;

  timer: any;

  // POPUP COPY
  showCopyPopup = false;

  constructor(
    private location: Location,
    private router: Router
  ) {

    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'copy-outline': copyOutline,
      'checkmark-circle-outline': checkmarkCircleOutline
    });

  }

  ionViewWillEnter() {

    // AMBIL BANK
    this.selectedBank =
      localStorage.getItem(
        'selectedBank'
      ) || '';

    // AMBIL TOTAL
    const savedTotal =
      localStorage.getItem(
        'checkoutTotal'
      );

    if (savedTotal) {

      // FORMAT TETAP
      this.total = savedTotal;

    }

    // LOGO BANK
    if (this.selectedBank === 'BRI') {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/2/2e/BRI_2020.svg';

    }

    else if (this.selectedBank === 'BCA') {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/5/5c/Bank_Central_Asia.svg';

    }

    else {

      this.bankLogo =
        'https://upload.wikimedia.org/wikipedia/commons/a/ad/Bank_Mandiri_logo_2016.svg';

    }

    // TIMER 1 MENIT
    this.expiredAt =
      Date.now() + (1 * 60 * 1000);

    this.startCountdown();

  }

  // COUNTDOWN
  startCountdown() {

    this.timer = setInterval(() => {

      const distance =
        this.expiredAt - Date.now();

      // HABIS
      if (distance <= 0) {

        clearInterval(this.timer);

        this.countdown =
          '00:00:00';

        return;

      }

      const minutes = Math.floor(
        (distance % (1000 * 60 * 60))
        / (1000 * 60)
      );

      const seconds = Math.floor(
        (distance % (1000 * 60))
        / 1000
      );

      this.countdown =
        `00:${minutes
          .toString()
          .padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`;

    }, 1000);

  }

  // COPY VA
  async copyVa() {

    await navigator.clipboard.writeText(
      this.virtualAccount
    );

    this.showCopyPopup = true;

    setTimeout(() => {

      this.showCopyPopup = false;

    }, 1500);

  }

  // GO TO PENDING PAYMENT
  goToPendingPayment() {

    // =========================
    // SIMPAN KE PESANAN
    // =========================

    const checkoutItems = JSON.parse(
      localStorage.getItem('checkoutItems') || '[]'
    );

    const orders = JSON.parse(
      localStorage.getItem('orders') || '[]'
    );

    checkoutItems.forEach((item: any) => {

      orders.unshift({

        status: 'belum-dibayar',

        expiredAt:
          this.expiredAt,

        name: item.name,

        price: item.price,

        qty: item.qty,

        image: item.image,

        estimate: '10 Mei'

      });

    });

    localStorage.setItem(
      'orders',
      JSON.stringify(orders)
    );

    // =========================
    // AMBIL CART
    // =========================

    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // HAPUS ITEM YANG SUDAH DI CHECKOUT
    const updatedCart = cart.filter(
      (cartItem: any) => {

        return !checkoutItems.some(
          (checkoutItem: any) =>

            checkoutItem.id === cartItem.id
        );

      }
    );

    // UPDATE CART
    localStorage.setItem(
      'cart',
      JSON.stringify(updatedCart)
    );

    // HAPUS DATA CHECKOUT
    localStorage.removeItem(
      'checkoutItems'
    );

    localStorage.removeItem(
      'checkoutTotal'
    );

    // PINDAH PAGE
    this.router.navigate([
      '/checkout/pending-payment'
    ]);

  }

  goBack() {

    this.location.back();

  }

}