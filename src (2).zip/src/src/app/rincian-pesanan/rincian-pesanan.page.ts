import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule,
  Location
} from '@angular/common';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  IonContent,
  IonIcon,
  IonButton
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';

import {
  arrowBackOutline,
  chatbubbleOutline,
  locationOutline,
  chevronForwardOutline,
  copyOutline,
  walletOutline,
  cubeOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-rincian-pesanan',
  templateUrl: './rincian-pesanan.page.html',
  styleUrls: ['./rincian-pesanan.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonIcon,
    IonButton
  ]
})

export class RincianPesananPage
implements OnInit {

  order: any;

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private router: Router
  ) {

    addIcons({
      arrowBackOutline,
      chatbubbleOutline,
      locationOutline,
      chevronForwardOutline,
      copyOutline,
      walletOutline,
      cubeOutline
    });

  }

  ngOnInit() {

    // AMBIL ID
    const id = Number(
      this.route.snapshot.paramMap.get('id')
    );

    // STORAGE
    const savedOrders =
      localStorage.getItem(
        'orders'
      );

    if (savedOrders) {

      const orders =
        JSON.parse(savedOrders);

      // CARI ORDER
      const foundOrder =
        orders.find(
          (item: any) =>

            Number(item.id) === id
        );

      if (foundOrder) {

        const product =

          foundOrder.product ||

          foundOrder.items?.[0] ||

          foundOrder;

        // BERAT
        const weight =

          Number(
            product.weight
          ) || 1;

        // ONGKIR
        const shippingCost =
          weight > 5
            ? 20000
            : 10000;

        // PRICE
        const productPrice =

          this.formatPrice(

            product.price ||

            product.total ||

            product.subtotal ||

            product.amount ||

            product.productPrice

          );

        // ONGKIR FINAL
        const shipping =

          foundOrder.shipping ||

          shippingCost;

        // VOUCHER
        const voucherTitle =

          foundOrder.voucher ||

          '';

        // DISKON
        let discount = 0;

        // GRATIS ONGKIR
        let freeShipping = false;

        // DISKON RP
        if (

          voucherTitle.includes(
            'Diskon Rp'
          )

        ) {

          discount = Number(

            voucherTitle
              .replace('Diskon Rp', '')
              .replace(/\./g, '')

          ) || 0;

        }

        // CASHBACK
        else if (

          voucherTitle.includes(
            'Cashback'
          )

        ) {

          const percent = Number(

            voucherTitle
              .replace('Cashback', '')
              .replace('%', '')

          ) || 0;

          discount =

            productPrice *

            (percent / 100);

        }

        // GRATIS ONGKIR
        else if (

          voucherTitle.includes(
            'Gratis Ongkir'
          )

        ) {

          freeShipping = true;

          discount = shipping;

        }

        // TOTAL
        const finalTotal =

          productPrice +

          shipping -

          discount;

        this.order = {

          ...foundOrder,

          // STATUS
          status:
            foundOrder.status ||
            'dikemas',

          // NAMA
          productName:

            product.productName ||

            product.name ||

            product.title ||

            'Produk',

          // VARIAN
          variant:

            product.variant ||

            'Ivory',

          // HARGA BARANG
          price:
            productPrice,

          // IMAGE
          image:

            product.image ||

            product.productImage ||

            'assets/no-image.png',

          // JUMLAH
          qty:

            product.qty ||

            product.quantity ||

            1,

          // TOKO
          store:

            product.store ||

            foundOrder.store ||

            'Glow Beauty',

          // BERAT
          weight,

          // ONGKIR
          shipping,

          // DISKON
          discount,

          // GRATIS ONGKIR
          freeShipping,

          // VOUCHER
          voucher:
            voucherTitle,

          // TOTAL
          finalTotal,

          // ALAMAT
          address:

            foundOrder.address ||

            'JAWA BARAT KAB. KARAWANG CIKAMPEK 41373 dekat pohon anggur',

          // PENERIMA
          receiver:

            foundOrder.receiver ||

            'Vina (08735627811)',

          // RESI
          receiptNumber:

            foundOrder.receiptNumber ||

            'JX3483920',

          // KURIR
          courier:

            foundOrder.courier ||

            'Ninja Xpress',

          // TANGGAL
          purchaseDate:

            foundOrder.purchaseDate ||

            '08 Mei 2026 10:15 WIB',

          // ESTIMASI
          estimateDate:

            foundOrder.estimate ||

            foundOrder.estimateDate ||

            '10 Mei 2026',

          // PAYMENT
          paymentMethod:

            foundOrder.paymentMethod ||

            'COD (Bayar di Tempat)'

        };

      }

    }

  }

  // FORMAT PRICE
  formatPrice(
    value: any
  ): number {

    if (
      value === null ||
      value === undefined
    ) {

      return 0;

    }

    if (
      typeof value === 'number'
    ) {

      return value;

    }

    return Number(

      value
        .toString()
        .replace(/Rp/gi, '')
        .replace(/\./g, '')
        .replace(/,/g, '')
        .replace(/\s/g, '')

    ) || 0;

  }

  // STATUS TEXT
  getStatusText(
    status: string
  ) {

    switch (status) {

      case 'belum-dibayar':
        return 'Belum Dibayar';

      case 'dikemas':
        return 'Pesanan Dikemas';

      case 'dikirim':
        return 'Pesanan Dikirim';

      case 'selesai':
        return 'Pesanan Selesai';

      case 'dibatalkan':
        return 'Pesanan Dibatalkan';

      default:
        return 'Pesanan';

    }

  }

  // BUKA TOKO
  openShop() {

    let shopData: any = {

      name:
        this.order.store ||

        'Shop'

    };

    // GLOW BEAUTY
    if (
      this.order.store ===
      'Glow Beauty'
    ) {

      shopData.avatar =
        'assets/shop/skincare.jpg';

    }

    // VOLT ELECTRONICS
    else if (
      this.order.store ===
      'Volt Electronics'
    ) {

      shopData.avatar =
        'assets/shop/electronic.jpg';

    }

    // ZOYA FASHION
    else if (
      this.order.store ===
      'Zoya Fashion'
    ) {

      shopData.avatar =
        'assets/shop/fashion.jpg';

    }

    // CEMILKU STORE
    else if (
      this.order.store ===
      'Cemilku Store'
    ) {

      shopData.avatar =
        'assets/shop/snack.jpg';

    }

    this.router.navigate(
      ['/shop-profile'],
      {
        state: {
          shop: shopData
        }
      }
    );

  }

  // BACK
  goBack() {

    this.location.back();

  }

}