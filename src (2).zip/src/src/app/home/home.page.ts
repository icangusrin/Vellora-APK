import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';

import {
  searchOutline,
  cartOutline,
  ticketOutline,
  shirtOutline,
  sparklesOutline,
  desktopOutline,
  fastFoodOutline,
  bagAddOutline,
} from 'ionicons/icons';

import { addIcons } from 'ionicons';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,

  imports: [
    IonicModule,
    CommonModule,
    RouterLink
  ],
})

export class HomePage {

  selectedTab = 'recommended';

  constructor(private router: Router) {

    addIcons({
      searchOutline,
      cartOutline,
      ticketOutline,
      shirtOutline,
      sparklesOutline,
      desktopOutline,
      fastFoodOutline,
      bagAddOutline,
    });

  }

  // GO TO CART
  goToCart() {

    this.router.navigate(['/cart']);

  }

  // GO TO CATEGORY
  goToCategory(category: string) {

    const route = category.toLowerCase();

    this.router.navigate([
      `/${route}`
    ]);

  }

  // GO TO VOUCHER
  goToVoucher() {

    this.router.navigate([
      '/voucher'
    ]);

  }

  // DETAIL PRODUCT
  openDetail(product: any) {

    // VARIANT OTOMATIS SESUAI PRODUK
    let variants: string[] = [];

    const productName =
      product.name.toLowerCase();

    // BEDAK
    if (
      productName.includes('bedak')
    ) {

      variants = [
        'Ivory',
        'Natural',
        'Beige',
        'Mocha'
      ];

    }

    // SMART WATCH
    else if (
      productName.includes('watch')
    ) {

      variants = [
        'Hitam',
        'Pink',
        'Putih',
        'Cream'
      ];

    }

    // SNACK / COOKIES
    else if (
      productName.includes('snack') ||
      productName.includes('cookies')
    ) {

      variants = [
        'Balado',
        'BBQ',
        'Keju',
        'Jagung Bakar'
      ];

    }

    // BRACELET
    else if (
      productName.includes('bracelet')
    ) {

      variants = [
        'Gold',
        'Silver',
        'Rose Gold'
      ];

    }

    // JEANS
    else if (
      productName.includes('jeans')
    ) {

      variants = [
        '28',
        '30',
        '32',
        '34'
      ];

    }

    // KAOS
    else if (
      productName.includes('kaos')
    ) {

      variants = [
        'S',
        'M',
        'L',
        'XL'
      ];

    }

    // HANDPHONE
    else if (
      productName.includes('handphone')
    ) {

      variants = [
        '128GB',
        '256GB',
        '512GB'
      ];

    }

    // DEFAULT
    else {

      variants = ['Default'];

    }

    // KIRIM KE DETAIL
    this.router.navigate(['/product-detail'], {
      state: {
        product: {
          ...product,
          variants
        }
      }
    });

  }

  // ADD TO CART
  addToCart(product: any, event: Event) {

    // BIAR TIDAK IKUT KLIK CARD
    event.stopPropagation();

    const productName =
      product.name.toLowerCase();

    // DEFAULT VARIANT
    let defaultVariant = 'Default';

    // BEDAK
    if (
      productName.includes('bedak')
    ) {

      defaultVariant = 'Ivory';

    }

    // SMART WATCH
    else if (
      productName.includes('watch')
    ) {

      defaultVariant = 'Hitam';

    }

    // SNACK / COOKIES
    else if (
      productName.includes('snack') ||
      productName.includes('cookies')
    ) {

      defaultVariant = 'Balado';

    }

    // BRACELET
    else if (
      productName.includes('bracelet')
    ) {

      defaultVariant = 'Gold';

    }

    // JEANS
    else if (
      productName.includes('jeans')
    ) {

      defaultVariant = '28';

    }

    // KAOS
    else if (
      productName.includes('kaos')
    ) {

      defaultVariant = 'M';

    }

    // HANDPHONE
    else if (
      productName.includes('handphone')
    ) {

      defaultVariant = '128GB';

    }

    // AMBIL CART
    const cart = JSON.parse(
      localStorage.getItem('cart') || '[]'
    );

    // ID UNIK
    const itemId =
      product.name + '-' + defaultVariant;

    // CEK PRODUK
    const existingProduct = cart.find(
      (item: any) => item.id === itemId
    );

    // JIKA SUDAH ADA
    if (existingProduct) {

      existingProduct.qty++;

    }

    // JIKA BELUM ADA
    else {

      cart.push({

        id: itemId,

        category: 'Produk',

        name: product.name,

        variant: defaultVariant,

        price: product.price,

        qty: 1,

        checked: false,

        image: product.image

      });

    }

    // SIMPAN CART
    localStorage.setItem(
      'cart',
      JSON.stringify(cart)
    );

  }

  // CATEGORY
  categories = [

    {
      name: 'Voucher',
      icon: 'ticket-outline',
    },

    {
      name: 'Fashion',
      icon: 'shirt-outline',
    },

    {
      name: 'Beauty',
      icon: 'sparkles-outline',
    },

    {
      name: 'Elektronik',
      icon: 'desktop-outline',
    },

    {
      name: 'Snack',
      icon: 'fast-food-outline',
    },

  ];

  // RECOMMENDED
  recommendedProducts = [

    {
      name: 'Bedak',
      image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9',
      price: 'Rp.55.000',
      sold: '5RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },

    {
      name: 'Smart Watch',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
      price: 'Rp.200.000',
      sold: '500 terjual',
      rating: '⭐⭐⭐⭐☆',
    },

    {
      name: 'Snack',
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff',
      price: 'Rp.25.000',
      sold: '2RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },

    {
      name: 'Bracelet',
      image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638',
      price: 'Rp.75.000',
      sold: '800 terjual',
      rating: '⭐⭐⭐⭐☆',
    },

  ];

  // HOT
  hotProducts = [

    {
      name: 'Jeans',
      image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246',
      price: 'Rp.175.000',
      sold: '2RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },

    {
      name: 'Kaos',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab',
      price: 'Rp.120.000',
      sold: '1RB+ terjual',
      rating: '⭐⭐⭐⭐☆',
    },

  ];

  // TOP
  topProducts = [

    {
      name: 'Handphone',
      image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9',
      price: 'Rp.2.500.000',
      sold: '10RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },

    {
      name: 'Cookies',
      image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e',
      price: 'Rp.35.000',
      sold: '4RB+ terjual',
      rating: '⭐⭐⭐⭐⭐',
    },

  ];

  // PRODUCT LIST
  get products() {

    if (this.selectedTab === 'hot') {

      return this.hotProducts;

    }

    if (this.selectedTab === 'top') {

      return this.topProducts;

    }

    return this.recommendedProducts;

  }

}