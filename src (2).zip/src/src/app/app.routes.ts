import { Routes } from '@angular/router';

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'tabs/home',
    pathMatch: 'full',
  },

  {
    path: 'tabs',
    loadChildren: () =>
      import('./tabs/tabs.routes').then(
        (m) => m.routes
      ),
  },

  {
    path: 'chat-detail/:id',
    loadComponent: () =>
      import('./chat-detail/chat-detail.page').then(
        (m) => m.ChatDetailPage
      ),
  },

  {
    path: 'search',
    loadComponent: () =>
      import('./search/search.page').then(
        (m) => m.SearchPage
      ),
  },
  {
    path: 'cart',
    loadComponent: () => import('./cart/cart.page').then( m => m.CartPage)
  },
  {
    path: 'voucher',
    loadComponent: () => import('./voucher/voucher.page').then( m => m.VoucherPage)
  },
  {
    path: 'checkout',
    loadChildren: () =>
      import('./checkout/checkout.routes').then(
        m => m.routes
      ),
  },
  {
    path: 'payment-method',
    loadComponent: () => import('./payment-method/payment-method.page').then( m => m.PaymentMethodPage)
  },
  {
    path: 'payment-detail',
    loadComponent: () => import('./payment-detail/payment-detail.page').then( m => m.PaymentDetailPage)
  },
  {
    path: 'payment-qris',
    loadComponent: () => import('./payment-qris/payment-qris.page').then( m => m.PaymentQrisPage)
  },
  {
    path: 'pending-payment',
    loadComponent: () => import('./pending-payment/pending-payment.page').then( m => m.PendingPaymentPage)
  },
  {
    path: 'fashion',
    loadComponent: () => import('./fashion/fashion.page').then( m => m.FashionPage)
  },
  {
    path: 'beauty',
    loadComponent: () => import('./beauty/beauty.page').then( m => m.BeautyPage)
  },
  {
    path: 'elektronik',
    loadComponent: () => import('./elektronik/elektronik.page').then( m => m.ElektronikPage)
  },
  {
    path: 'snack',
    loadComponent: () => import('./snack/snack.page').then( m => m.SnackPage)
  },
  {
    path: 'elektronik',
    loadComponent: () => import('./elektronik/elektronik.page').then( m => m.ElektronikPage)
  },
  {
    path: 'product-detail',
    loadComponent: () => import('./product-detail/product-detail.page').then( m => m.ProductDetailPage)
  },
  {
    path: 'success-order',
    loadComponent: () => import('./success-order/success-order.page').then( m => m.SuccessOrderPage)
  },
  {
    path: 'account-settings',
    loadComponent: () => import('./account-settings/account-settings.page').then( m => m.AccountSettingsPage)
  },
  {
    path: 'security-account',
    loadComponent: () => import('./security-account/security-account.page').then( m => m.SecurityAccountPage)
  },
  {
    path: 'edit-profile',
    loadComponent: () => import('./edit-profile/edit-profile.page').then( m => m.EditProfilePage)
  },
  {
    path: 'change-phone',
    loadComponent: () => import('./change-phone/change-phone.page').then( m => m.ChangePhonePage)
  },
  {
    path: 'verify-phone-email',
    loadComponent: () => import('./verify-phone-email/verify-phone-email.page').then( m => m.VerifyPhoneEmailPage)
  },
  {
    path: 'verify-phone-otp',
    loadComponent: () => import('./verify-phone-otp/verify-phone-otp.page').then( m => m.VerifyPhoneOtpPage)
  },
  {
    path: 'change-email',
    loadComponent: () => import('./change-email/change-email.page').then( m => m.ChangeEmailPage)
  },
  {
    path: 'shop-profile',
    loadComponent: () => import('./shop-profile/shop-profile.page').then( m => m.ShopProfilePage)
  },
  {
    path: 'my-address',
    loadComponent: () => import('./my-address/my-address.page').then( m => m.MyAddressPage)
  },
  {
    path: 'address-picker',
    loadComponent: () => import('./address-picker/address-picker.page').then( m => m.AddressPickerPage)
  },
  {
    path: 'change-password',
    loadComponent: () => import('./change-password/change-password.page').then( m => m.ChangePasswordPage)
  },
  {
    path: 'phone-verification',
    loadComponent: () => import('./phone-verification/phone-verification.page').then( m => m.PhoneVerificationPage)
  },
  {
    path: 'phone-otp',
    loadComponent: () => import('./phone-otp/phone-otp.page').then( m => m.PhoneOtpPage)
  },
  {
    path: 'email-otp',
    loadComponent: () => import('./email-otp/email-otp.page').then( m => m.EmailOtpPage)
  },
  {
    path: 'privacy-settings',
    loadComponent: () => import('./privacy-settings/privacy-settings.page').then( m => m.PrivacySettingsPage)
  },
  {
    path: 'pesanan',
    loadComponent: () => import('./pesanan/pesanan.page').then( m => m.PesananPage)
  },
  {
    path: 'ganti-akun',
    loadComponent: () => import('./ganti-akun/ganti-akun.page').then( m => m.GantiAkunPage)
  },
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage)
  },
  {
    path: 'register',
    loadComponent: () => import('./register/register.page').then( m => m.RegisterPage)
  },
    {
      path: 'rincian-pesanan/:id',
      loadComponent: () =>
        import('./rincian-pesanan/rincian-pesanan.page').then(
          (m) => m.RincianPesananPage
        ),
    },
];