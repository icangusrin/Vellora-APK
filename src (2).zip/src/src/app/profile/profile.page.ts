import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { addIcons } from 'ionicons';

import {
  settingsOutline,
  cartOutline,
  chatbubbleOutline,
  person,
  cardOutline,
  cubeOutline,
  carOutline,
  checkmarkDoneOutline,
  starOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule
  ],
})

export class ProfilePage {

  // STATUS LOGIN
  isLoggedIn = true;

  // DATA USER
  userData = {
    name: 'User',
    email: 'wongireng@gmail.com',
    photo:
      'https://cdn-icons-png.flaticon.com/512/149/149071.png'
  };

  constructor(
    private router: Router
  ) {

    addIcons({

      // HEADER
      'settings-outline': settingsOutline,
      'cart-outline': cartOutline,
      'chatbubble-outline': chatbubbleOutline,
      'person': person,

      // TRANSAKSI
      'card-outline': cardOutline,
      'cube-outline': cubeOutline,
      'car-outline': carOutline,
      'checkmark-done-outline': checkmarkDoneOutline,
      'star-outline': starOutline

    });

  }

  // LOAD DATA
  ionViewWillEnter() {

    // AMBIL OBJECT PROFILE
    const savedProfile =
      localStorage.getItem(
        'userProfile'
      );

    // AMBIL FOTO
    const savedImage =
      localStorage.getItem(
        'profileImage'
      );

    if (savedProfile) {

      const profile =
        JSON.parse(savedProfile);

      this.userData = {

        name:
          profile.name ||
          'User',

        email:
          profile.email ||
          'Belum ada email',

        photo:

          profile.image ||

          savedImage ||

          'https://cdn-icons-png.flaticon.com/512/149/149071.png'

      };

    }

    // JIKA BELUM ADA PROFILE
    else {

      this.userData = {

        name:
          localStorage.getItem(
            'userName'
          ) || 'User',

        email:
          localStorage.getItem(
            'userEmail'
          ) || 'Belum ada email',

        photo:

          localStorage.getItem(
            'profileImage'
          ) ||

          'https://cdn-icons-png.flaticon.com/512/149/149071.png'

      };

    }

  }

  // GO TO CART
  goToCart() {

    this.router.navigate([
      '/cart'
    ]);

  }

  // GO TO CHAT
  goToChat() {

    this.router.navigate([
      '/tabs/chat'
    ]);

  }

  // GO TO SETTINGS
  goToSettings() {

    this.router.navigate([
      '/account-settings'
    ]);

  }

  // GO TO EDIT PROFILE
  goToEditProfile() {

    this.router.navigate([
      '/edit-profile'
    ]);

  }

  // GO TO PESANAN
  goToPesanan(
    status: string = 'semua'
  ) {

    this.router.navigate(
      ['/pesanan'],
      {
        queryParams: { status }
      }
    );

  }

}