import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { IonicModule, ActionSheetController, ToastController } from '@ionic/angular'; // <-- Ditambahkan ToastController
import { addIcons } from 'ionicons';
import { 
  arrowBackOutline, 
  cameraOutline, 
  warningOutline, 
  chevronDownOutline, 
  alertCircleOutline,
  checkmarkCircleOutline // <-- Opsional: Untuk ikon sukses di toast nanti
} from 'ionicons/icons';

@Component({
  selector: 'app-laporkan',
  templateUrl: './laporkan.page.html',
  styleUrls: ['./laporkan.page.scss'],
  standalone: true,
  encapsulation: ViewEncapsulation.None, 
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})
export class LaporkanPage {
  
  // Variabel penampung data
  previewImages: string[] = [];
  selectedJenis: string = ''; 
isSubmitting = false;
judulLaporan = '';
deskripsiLaporan = ''; 
  constructor(
    private location: Location,
    private actionSheetCtrl: ActionSheetController,
    private toastCtrl: ToastController // <-- Inject ToastController ke constructor
  ) {
    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'camera-outline': cameraOutline,
      'warning-outline': warningOutline,
      'chevron-down-outline': chevronDownOutline,
      'alert-circle-outline': alertCircleOutline,
      'checkmark-circle-outline': checkmarkCircleOutline
    });
  }

  // FUNGSI KEMBALI
  goBack() {
    this.location.back();
  }

  // FUNGSI MEMBUKA ACTION SHEET PILIHAN LAPORAN
  async pilihJenisLaporan() {
    const actionSheet = await this.actionSheetCtrl.create({
      cssClass: 'custom-action-sheet',
      htmlAttributes: {
        'style': 'position: absolute; z-index: 9999;'
      },
      buttons: [
        { text: 'Produk Tidak Sesuai', handler: () => { this.selectedJenis = 'Produk Tidak Sesuai'; } },
        { text: 'Produk Palsu / Melanggar Hak Cipta', handler: () => { this.selectedJenis = 'Produk Palsu / Melanggar Hak Cipta'; } },
        { text: 'Penipuan / Aktivitas Mencurigakan', handler: () => { this.selectedJenis = 'Penipuan / Aktivitas Mencurigakan'; } },
        { text: 'Toko Bermasalah', handler: () => { this.selectedJenis = 'Toko Bermasalah'; } },
        { text: 'Konten Tidak Pantas', handler: () => { this.selectedJenis = 'Konten Tidak Pantas'; } },
        { text: 'Harga / Informasi Menyesatkan', handler: () => { this.selectedJenis = 'Harga / Informasi Menyesatkan'; } },
        { text: 'Pelanggaran Kebijakan Vellora', handler: () => { this.selectedJenis = 'Pelanggaran Kebijakan Vellora'; } },
        { text: 'Masalah Pesanan / Pengiriman', handler: () => { this.selectedJenis = 'Masalah Pesanan / Pengiriman'; } },
        { text: 'Lainnya', handler: () => { this.selectedJenis = 'Lainnya'; } },
        { text: 'Batal', role: 'cancel' }
      ]
    });
    await actionSheet.present();
  }

async kirimLaporan() {

  if (this.isSubmitting) return;

  if (
    !this.selectedJenis ||
    !this.judulLaporan.trim() ||
    !this.deskripsiLaporan.trim()
  ) {

    const warningToast = await this.toastCtrl.create({
      message: 'Lengkapi seluruh laporan terlebih dahulu!',
      duration: 2200,
      position: 'middle',
      icon: 'alert-circle-outline',
      cssClass: 'custom-warning-toast'
    });

    await warningToast.present();
    return;
  }

  this.isSubmitting = true;

  const toast = await this.toastCtrl.create({
    message: 'Laporan berhasil terkirim!',
    duration: 2200,
    position: 'middle',
    icon: 'checkmark-circle-outline',
    cssClass: 'custom-success-toast'
  });

  await toast.present();

  toast.onDidDismiss().then(() => {
    this.isSubmitting = false;
  });

    await toast.present();

    // Opsional: Redirect atau kosongkan form setelah berhasil kirim
    // this.goBack(); 
  }

  // FUNGSI PILIH FOTO
  onFileSelected(event: any) {
    const files = event.target.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.previewImages.push(e.target.result);
        };
        reader.readAsDataURL(files[i]);
      }
    }
  }
}